# Premium Link Downloader (Telegram bot)

Merged build of the four prompts: modular downloader bot with engine fallback, AI assistant, YouTube search,
stock photos/videos, force-subscribe, referrals/premium, admin panel, activity forwarding and Sheets sync.

## Quick start (Windows)
1. Install Python 3.11+ and FFmpeg (`winget install Gyan.FFmpeg`).
2. Double-click `install.bat`, then edit `.env` (**BOT_TOKEN**, **ADMIN_IDS** at minimum).
3. Double-click `run.bat`. In Telegram send `/start`; admins open `/admin`.

Linux/macOS: `python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt && cp .env.example .env && python bot.py`

`python bot.py --check` validates the configuration only.

## What works, and what was verified
`python -m unittest discover -s tests -t .` runs 100 tests: config, admin authorization (commands + buttons),
URL/SSRF validation, filenames, DB migrations/persistence, engine registry + fallback/retry/timeout/cancel,
queue limits, key rotation, API client, upload retry paths, ffmpeg split/probe/thumbnail/watermark (when ffmpeg
exists), the whole download pipeline with mocked engines, AI manager, and handler flows (gate, link → menu →
queue → upload) against a stub of the Telegram API.

**Not verified here (no network in my sandbox):** real Telegram, real yt-dlp downloads, real Unsplash/Pixabay/
YouTube/Gemini/Groq/OpenAI/OpenRouter/Cobalt calls, Google Sheets. Those code paths follow each service's
documented API but need a live smoke test (see below). Test run with real `python-telegram-bot` installed too.

## First live smoke test (10 min)
1. Send a public YouTube/other link → menu appears → pick a quality → file arrives.
2. Send a >50 MB link without `LOCAL_BOT_API_URL` → file arrives split in parts.
3. `/admin` → Engines / API keys / AI → add a Pixabay or Gemini key and try the features.
4. As a second (non-admin) account, confirm `/admin` does nothing and force-subscribe prompts appear.

## Design decisions where the prompts conflicted or were unsafe
- **No secrets in code.** The Pixabay key pasted in the prompt is *not* included — rotate it, then add keys in
  `.env` or `/admin → API keys` (stored encrypted if `SECRET_KEY` + `cryptography`).
- **Engines are hidden from users** (prompt 4); admins see them. Users get plain-language errors.
- **AI persona:** acts as "{OWNER_NAME}'s official bot manager" and doesn't name the model/provider, but will
  never claim to be human; it confirms it's an AI if sincerely asked.
- **Activity forwarding** to the owner is optional and users are told in `/privacy`. Pause it in Admin → Features.
- **Large files:** cloud Bot API uploads max ≈50 MB, so bigger files are split (video by stream copy, otherwise
  raw `.001/.002` parts). For single large uploads run a local Bot API server and set `LOCAL_BOT_API_URL`.
- **YouTube "confirm you're not a bot"** and similar blocks can't be guaranteed away. The bot retries, falls
  back to other engines, and lets the admin upload a `cookies.txt` of **their own** account. No DRM or private-content bypass.
- **RapidAPI:** not included — I won't invent endpoints. Add a provider by following `api/providers/stock.py`.
- Referral rewards count only after the invited user passes force-subscribe (anti-abuse). Force-sub **fails open** if
  the bot isn't admin in the channel (logged), so a misconfiguration never locks everyone out.
- Colored buttons use the Bot API 9.4 `style` field when your `python-telegram-bot` supports it, plain otherwise.

## Layout
```
bot.py  config.py  engines/  api/  ai/  services/  handlers/  keyboards/  database/  utils/  tests/
```
Adding an engine: subclass `engines/base.py::BaseEngine`, implement 5 methods, `registry.register(...)` in `bot.py`.
Persistent queue: replace `services/queue_service.py::JobQueue` (same submit/cancel/shutdown surface).

## Admin panel (`/admin`)
Dashboard · engines (enable/disable/priority) · live limits · active jobs (cancel) · errors · block/unblock/grant
premium · broadcast with preview · API key bank · AI provider/model/persona · force-sub channels · feature
switches · CSV export · cleanup · audit log · versions · Sheets sync · cookies · maintenance mode.
Destructive actions ask for confirmation; every admin action is audit-logged.

## Security notes
Admin checks run on every command, button and text/file input; only http(s) public URLs are fetched (private IPs,
`localhost`, metadata IPs rejected, redirects re-validated); subprocesses use argument lists; logs redact tokens/keys;
captions are HTML-escaped; CSV exports neutralise formula injection. Keep `.env` and `data/cookies.txt` private.
Update yt-dlp regularly: `pip install -U yt-dlp`. Only download content you have the right to access.
