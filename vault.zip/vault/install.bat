@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul || (echo Python 3.11+ is required. Install it from python.org and tick "Add to PATH". & pause & exit /b 1)
python -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" || (echo Python 3.11 or newer is required. & pause & exit /b 1)
if not exist .venv ( python -m venv .venv )
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt || (echo Core install failed. & pause & exit /b 1)
echo Installing optional components (failures here are fine)...
for /f "usebackq tokens=1 delims= " %%p in (`findstr /r "^[a-z]" requirements-optional.txt`) do pip install "%%p"
if not exist .env ( copy .env.example .env >nul & echo Created .env - open it and set BOT_TOKEN and ADMIN_IDS. )
where ffmpeg >nul 2>nul || echo WARNING: FFmpeg not found. Install it ^(winget install Gyan.FFmpeg^) for merging, MP3 conversion and splitting.
echo Done. Edit .env, then run run.bat
pause
