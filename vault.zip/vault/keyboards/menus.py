"""Reply/inline keyboards. Coloured buttons (Bot API 9.4 `style`) degrade gracefully on older libraries."""
from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup

from services.metadata_service import AUDIO_FORMATS, quality_options
from engines.base import MediaInfo

# Button labels double as routing keys (see handlers/router.py).
B_DOWNLOAD = "📥 Download Media"
B_AUDIO = "🎵 Audio Download"
B_YOUTUBE = "🔎 YouTube Search"
B_STOCK = "🖼️ Photos & Stock"
B_AI = "🤖 AI Assistant"
B_HISTORY = "📚 Download History"
B_REFER = "👥 Refer & Premium"
B_PROFILE = "👤 My Profile"
B_STATS = "📊 My Statistics"
B_SETTINGS = "⚙️ Settings"
B_SUPPORT = "☎️ Support"

ALL_LABELS = (B_DOWNLOAD, B_AUDIO, B_YOUTUBE, B_STOCK, B_AI, B_HISTORY, B_REFER, B_PROFILE, B_STATS,
              B_SETTINGS, B_SUPPORT)


def kbtn(text: str, style: str | None = None) -> KeyboardButton:
    if style:
        try:
            return KeyboardButton(text, style=style)
        except TypeError:           # older python-telegram-bot: plain button
            pass
    return KeyboardButton(text)


def ibtn(text: str, data: str | None = None, *, url: str | None = None, style: str | None = None) -> InlineKeyboardButton:
    kwargs = {"url": url} if url else {"callback_data": data}
    if style:
        try:
            return InlineKeyboardButton(text, style=style, **kwargs)
        except TypeError:
            pass
    return InlineKeyboardButton(text, **kwargs)


def main_menu() -> ReplyKeyboardMarkup:
    rows = [
        [kbtn(B_DOWNLOAD, "success"), kbtn(B_AUDIO, "primary")],
        [kbtn(B_YOUTUBE, "primary"), kbtn(B_STOCK, "primary")],
        [kbtn(B_AI, "primary"), kbtn(B_HISTORY, "primary")],
        [kbtn(B_REFER, "success"), kbtn(B_PROFILE, "primary")],
        [kbtn(B_STATS, "primary"), kbtn(B_SETTINGS, "primary")],
        [kbtn(B_SUPPORT, "danger")],
    ]
    return ReplyKeyboardMarkup(rows, resize_keyboard=True, is_persistent=True, input_field_placeholder="Paste a link…")


def quality_keyboard(token: str, info: MediaInfo, *, audio_only: bool = False) -> InlineKeyboardMarkup:
    """Only qualities that really exist for this media."""
    rows: list[list[InlineKeyboardButton]] = []
    if not audio_only:
        opts = quality_options(info)
        row: list[InlineKeyboardButton] = []
        for height, label in opts:
            row.append(ibtn(f"🎬 {label}", f"dl:{token}:v:{height or 'best'}", style="success" if height is None else None))
            if len(row) == 2:
                rows.append(row); row = []
        if row:
            rows.append(row)
    if info.has_audio or not info.formats:
        labels = {"best": "Original audio", "m4a": "M4A", "mp3": "MP3", "opus": "OPUS"}
        rows.append([ibtn(f"🎵 {labels[f]}", f"dl:{token}:a:{f}", style="primary") for f in AUDIO_FORMATS[:2]])
        rows.append([ibtn(f"🎵 {labels[f]}", f"dl:{token}:a:{f}", style="primary") for f in AUDIO_FORMATS[2:]])
    if info.thumbnail:
        rows.append([ibtn("🖼 Thumbnail", f"dl:{token}:thumb")])
    rows.append([ibtn("✖️ Close", f"dl:{token}:x", style="danger")])
    return InlineKeyboardMarkup(rows)


def cancel_keyboard(job_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[ibtn("🛑 Cancel", f"cx:{job_id}", style="danger")]])


def join_keyboard(channels: list[dict]) -> InlineKeyboardMarkup:
    rows = [[ibtn(f"📢 Join {c.get('title') or c['chat_ref']}", url=c["url"], style="primary")]
            for c in channels if c.get("url")]
    rows.append([ibtn("✅ I've joined", "fs:check", style="success")])
    return InlineKeyboardMarkup(rows)


def settings_keyboard(prefs: dict[str, str], *, show_watermark: bool) -> InlineKeyboardMarkup:
    def on(key: str, default: str) -> str:
        return "✅" if prefs.get(key, default) == "1" else "❌"
    rows = [
        [ibtn(f"⚡ Quick mode (auto best quality) {on('quick', '0')}", "set:quick")],
        [ibtn(f"🖼 Send thumbnails {on('send_thumbnail', '1')}", "set:send_thumbnail")],
    ]
    if show_watermark:
        rows.append([ibtn(f"🏷 Add branding to videos {on('watermark', '0')}", "set:watermark")])
    rows.append([ibtn(f"🎵 Default audio: {prefs.get('audio_fmt', 'best')}", "set:audio_fmt")])
    rows.append([ibtn("🧹 Clear AI chat history", "ai:clear")])
    return InlineKeyboardMarkup(rows)
