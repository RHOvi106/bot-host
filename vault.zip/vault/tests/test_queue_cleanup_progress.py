import asyncio
import os
import tempfile
import time
import unittest
from pathlib import Path

from engines.base import EngineError, ErrorCategory
from services.progress_service import ProgressReporter, ProgressState, progress_bar, render_progress
from services.queue_service import Job, JobQueue, QueueRejected
from utils import cleanup


class QueueTests(unittest.IsolatedAsyncioTestCase):
    async def test_global_concurrency_limit(self):
        running, peak, release = 0, 0, asyncio.Event()

        async def runner(job):
            nonlocal running, peak
            running += 1; peak = max(peak, running)
            await release.wait()
            running -= 1

        q = JobQueue(runner, workers=2, per_user=5, max_size=10)
        await q.start()
        jobs = [await q.submit(Job(i, f"https://e.com/{i}", "video", "best")) for i in range(5)]
        await asyncio.sleep(0.05)
        self.assertEqual(peak, 2)
        self.assertEqual(q.snapshot(), {"running": 2, "queued": 3})
        self.assertEqual(q.position(jobs[4].job_id), 3)
        release.set()
        await asyncio.sleep(0.1)
        self.assertTrue(all(j.status == "done" for j in jobs))
        await q.shutdown()

    async def test_duplicates_and_user_limit_and_full(self):
        gate = asyncio.Event()

        async def runner(job):
            await gate.wait()

        q = JobQueue(runner, workers=1, per_user=2, max_size=1)
        await q.start()
        await q.submit(Job(1, "u1", "video", "best"))
        await asyncio.sleep(0.02)                                  # worker picks u1 up
        with self.assertRaises(QueueRejected) as cm:
            await q.submit(Job(1, "u1", "video", "best"))
        self.assertEqual(cm.exception.reason, "duplicate")
        await q.submit(Job(1, "u2", "video", "best"))
        with self.assertRaises(QueueRejected) as cm:
            await q.submit(Job(1, "u3", "video", "best"))
        self.assertEqual(cm.exception.reason, "user_limit")
        with self.assertRaises(QueueRejected) as cm:           # waiting jobs are bounded (max_size=1)
            await q.submit(Job(2, "u4", "video", "best"))
        self.assertEqual(cm.exception.reason, "full")
        gate.set()
        await q.shutdown()

    async def test_cancel_queued_and_running(self):
        started = asyncio.Event()

        async def runner(job):
            started.set()
            while not job.cancel.cancelled:
                await asyncio.sleep(0.01)
            job.status = "cancelled"

        q = JobQueue(runner, workers=1, per_user=3)
        await q.start()
        a = await q.submit(Job(1, "a", "video", "best"))
        b = await q.submit(Job(1, "b", "video", "best"))
        await started.wait()
        self.assertFalse(q.cancel(b.job_id, by_user=999))                  # not the owner
        self.assertTrue(q.cancel(b.job_id, by_user=1))                     # queued -> cancelled at once
        self.assertEqual(b.status, "cancelled")
        self.assertTrue(q.cancel(a.job_id, by_user=1))                     # running -> cooperative stop
        await asyncio.sleep(0.1)
        self.assertEqual(a.status, "cancelled")
        self.assertFalse(q.cancel("nope"))
        await q.shutdown()

    async def test_worker_survives_crash(self):
        async def runner(job):
            if job.url == "boom":
                raise RuntimeError("x")

        q = JobQueue(runner, workers=1, per_user=5)
        await q.start()
        bad = await q.submit(Job(1, "boom", "video", "best"))
        ok = await q.submit(Job(1, "fine", "video", "best"))
        await asyncio.sleep(0.1)
        self.assertEqual((bad.status, ok.status), ("failed", "done"))
        await q.shutdown()


class CleanupTests(unittest.TestCase):
    def test_sweep_old_and_clear_and_space(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            old, new = root / "old_job", root / "new_job"
            for p in (old, new):
                p.mkdir(); (p / "f.part").write_bytes(b"x")
            past = time.time() - 10 * 3600
            os.utime(old, (past, past))
            self.assertEqual(cleanup.sweep_old(root, 6), 1)
            self.assertFalse(old.exists()); self.assertTrue(new.exists())
            self.assertEqual(cleanup.clear_directory(root), 1)
            self.assertEqual(list(root.iterdir()), [])
            cleanup.ensure_free_space(root, 1024)
            with self.assertRaises(EngineError) as cm:
                cleanup.ensure_free_space(root, 10 ** 18)
            self.assertEqual(cm.exception.category, ErrorCategory.DISK_FULL)

    def test_remove_dir(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "j"; (p / "a").mkdir(parents=True); (p / "a" / "b").write_bytes(b"1")
            cleanup.remove_dir(p); self.assertFalse(p.exists())


class ProgressTests(unittest.IsolatedAsyncioTestCase):
    def test_render_does_not_invent_numbers(self):
        txt = render_progress(ProgressState(stage="downloading", percent=None, title="<T>"))
        self.assertNotIn("%", txt); self.assertIn("&lt;T&gt;", txt)
        self.assertNotIn("⏱", txt)
        full = render_progress(ProgressState(stage="downloading", percent=42.5, downloaded=5 << 20, total=10 << 20,
                                             speed=1 << 20, eta=5))
        for needle in ("42.5%", "5.0 MB / 10.0 MB", "1.0 MB/s"):
            self.assertIn(needle, full)
        self.assertEqual(progress_bar(100, 4), "████"); self.assertEqual(progress_bar(0, 4), "░░░░")

    async def test_throttle_and_force(self):
        t = [0.0]; sent = []

        async def edit(text): sent.append(text)
        rep = ProgressReporter(edit, interval=2.0, clock=lambda: t[0])
        await rep.update(stage="downloading", percent=1)
        t[0] = 0.5; await rep.update(percent=2)
        t[0] = 1.0; await rep.update(percent=3)
        self.assertEqual(len(sent), 1)
        t[0] = 2.5; await rep.update(percent=4)
        self.assertEqual(len(sent), 2)
        await rep.update(force=True, stage="done")
        self.assertEqual(len(sent), 3)

    async def test_edit_failures_never_raise(self):
        class Flood(Exception):
            retry_after = 5

        async def edit(text): raise Flood()
        rep = ProgressReporter(edit, interval=0)
        await rep.update(force=True, stage="downloading", percent=5)      # must not raise


if __name__ == "__main__":
    unittest.main()
