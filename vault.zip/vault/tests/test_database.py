import tempfile
import unittest
from pathlib import Path

from database import Database, Repository, migrate
from tests.helpers import make_repo
from utils.secrets_box import SecretBox, fingerprint, mask


class DatabaseTests(unittest.TestCase):
    def test_migrate_idempotent_and_persists_across_restart(self):
        with tempfile.TemporaryDirectory() as d:
            repo = make_repo(Path(d))
            repo.upsert_user(1, "alice", "Alice")
            repo.create_download("job1", 1, "https://example.com/v", platform="example", kind="video")
            repo.update_download("job1", status="done", engine="ytdlp", file_size=100)
            repo.log_error(1, "network", "boom")
            repo.set_setting("max", "5")
            repo.db.close()
            db2 = Database(Path(d) / "bot.db").connect()
            self.assertEqual(migrate(db2), 1)
            self.assertEqual(migrate(db2), 1)
            r2 = Repository(db2)
            self.assertEqual(r2.get_user(1)["username"], "alice")
            self.assertEqual(r2.global_stats()["done"], 1)
            self.assertEqual(r2.get_setting("max"), "5")
            self.assertEqual(len(r2.recent_errors()), 1)

    def test_users_blocking_premium_referrals(self):
        with tempfile.TemporaryDirectory() as d:
            now = [1000.0]
            repo = make_repo(Path(d)); repo._clock = lambda: now[0]
            _, new = repo.upsert_user(1, "a", "A"); self.assertTrue(new)
            _, new = repo.upsert_user(1, "a2", "A"); self.assertFalse(new)
            repo.set_blocked(1, True); self.assertTrue(repo.is_blocked(1))
            self.assertEqual(repo.all_user_ids(), [])
            repo.upsert_user(2, "b", "B")
            self.assertFalse(repo.add_referral(2, 2))                 # self-referral
            self.assertTrue(repo.add_referral(1, 2))
            self.assertFalse(repo.add_referral(1, 2))                 # duplicate
            self.assertEqual(repo.confirm_referral(2), 1)
            self.assertIsNone(repo.confirm_referral(2))               # only once
            self.assertEqual(repo.confirmed_referrals(1), 1)
            until = repo.extend_premium(2, 30)
            self.assertEqual(until, 1000 + 30 * 86400)
            self.assertTrue(repo.is_premium(2))
            now[0] += 31 * 86400
            self.assertFalse(repo.is_premium(2))

    def test_mark_abandoned_and_cache_lookup(self):
        with tempfile.TemporaryDirectory() as d:
            repo = make_repo(Path(d))
            repo.create_download("a", 1, "u", status="running")
            repo.create_download("b", 1, "u", cache_key="k")
            repo.update_download("b", status="done", tg_file_id="F", tg_file_kind="video")
            self.assertEqual(repo.mark_abandoned(), 1)
            self.assertEqual(repo.get_download("a")["status"], "abandoned")
            self.assertEqual(repo.find_cached_upload("k")["tg_file_id"], "F")

    def test_api_key_cooldown_order(self):
        with tempfile.TemporaryDirectory() as d:
            repo = make_repo(Path(d))
            repo.add_api_key("s", "plain:k1", "f1"); repo.add_api_key("s", "plain:k2", "f2")
            self.assertIsNone(repo.add_api_key("s", "plain:k1", "f1"))     # duplicate fingerprint
            ids = [r["id"] for r in repo.available_api_keys("s")]
            repo.mark_key_used(ids[0])
            self.assertEqual(repo.available_api_keys("s")[0]["id"], ids[1])   # round robin
            repo.mark_key_cooldown(ids[1], 3600, "rate")
            self.assertEqual([r["id"] for r in repo.available_api_keys("s")], [ids[0]])

    def test_group_column_whitelist(self):
        with tempfile.TemporaryDirectory() as d:
            repo = make_repo(Path(d))
            with self.assertRaises(ValueError):
                repo.counts_by("user_id; DROP TABLE users")

    def test_secret_box(self):
        box = SecretBox("")
        self.assertEqual(box.decrypt(box.encrypt("abc123456")), "abc123456")
        self.assertNotIn("abc", mask("abcdefghijkl")[4:-3])
        self.assertEqual(len(fingerprint("x")), 16)


if __name__ == "__main__":
    unittest.main()
