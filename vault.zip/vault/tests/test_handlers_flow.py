"""Handler-level tests with a stubbed Telegram API: gate, link -> menu -> queue -> upload, admin guard."""
import asyncio
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from tests import tg_stub

tg_stub.install()

import bot as botmod  # noqa: E402
from handlers import admin, download, router, start  # noqa: E402
from tests.helpers import FakeBot, FakeEngine, make_settings  # noqa: E402
from telegram.ext import ApplicationHandlerStop  # noqa: E402
from utils.validators import validate_url  # noqa: E402


class Msg:
    def __init__(self, log, text="", chat_id=42):
        self.log, self.text, self.chat_id, self.caption = log, text, chat_id, None
        self.edits, self.deleted = [], False

    async def reply_text(self, text, **kw):
        m = Msg(self.log, text, self.chat_id); m.kw = kw; self.log.append(("reply", text, kw)); return m

    async def reply_photo(self, *a, **kw): return await self.reply_text(kw.get("caption", ""), **kw)
    async def reply_document(self, *a, **kw): self.log.append(("doc", kw)); return self

    async def edit_text(self, text, **kw): self.edits.append(text); self.text = text
    async def edit_caption(self, **kw): self.edits.append(kw.get("caption"))
    async def edit_reply_markup(self, *a, **kw): pass
    async def delete(self): self.deleted = True


class Bot(FakeBot):
    def __init__(self, member_status="member", **kw):
        super().__init__(**kw); self.member_status, self.messages = member_status, []

    async def get_me(self): return SimpleNamespace(username="testbot")
    async def get_chat_member(self, chat, user): return SimpleNamespace(status=self.member_status)
    async def send_message(self, chat_id, text, **kw): self.messages.append((chat_id, text))
    async def send_chat_action(self, *a, **k): pass


async def fake_validate(url):
    return validate_url(url)          # same rules, no DNS lookup (tests run offline)


def keyboard_data(kw):
    return [b.kw.get("callback_data") for row in kw["reply_markup"].inline_keyboard for b in row]


class FlowBase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.settings = make_settings(Path(self.tmp.name))
        self.app = botmod.build_application(self.settings)
        self.bot = Bot(); self.app.bot = self.bot
        d = self.app.bot_data
        for name in list(d["registry"].names()):
            d["registry"].set_enabled(name, False)
        self.engine = FakeEngine("fake", 1, size=4096)
        d["registry"].register(self.engine)
        await d["queue"].start()
        self.addAsyncCleanup(d["queue"].shutdown)
        self.log = []

    def ctx(self):
        return SimpleNamespace(application=self.app, bot=self.bot, user_data=self._ud, bot_data=self.app.bot_data)

    _ud = None

    def update(self, uid=42, text="", callback=None):
        self._ud = self._ud if self._ud is not None else {}
        msg = Msg(self.log, text, uid)
        user = SimpleNamespace(id=uid, first_name="Tester", username="tester", is_bot=False)
        return SimpleNamespace(effective_user=user, effective_chat=SimpleNamespace(id=uid, type="private"),
                               effective_message=msg, message=msg, callback_query=callback)


class GateTests(FlowBase):
    async def test_blocked_user_is_stopped(self):
        d = self.app.bot_data
        upd = self.update(7); await d["repo"].upsert_user(7, "x", "X"); await d["repo"].set_blocked(7, True)
        with self.assertRaises(ApplicationHandlerStop):
            await start.gate(upd, self.ctx())
        self.assertIn("blocked", self.log[-1][1])

    async def test_admin_bypasses_maintenance_but_users_do_not(self):
        d = self.app.bot_data
        await d["repo"].set_setting("maintenance", "1")
        with self.assertRaises(ApplicationHandlerStop):
            await start.gate(self.update(8), self.ctx())
        await start.gate(self.update(5147383605), self.ctx())            # admin passes

    async def test_force_sub_blocks_until_joined_and_referral_rewards(self):
        d = self.app.bot_data; repo = d["repo"]
        await repo.add_channel("@chan", "Chan", "https://t.me/chan")
        d["settings"] = self.settings
        await repo.upsert_user(100, "ref", "Referrer")
        upd = self.update(200, "/start ref_100")
        self.bot.member_status = "left"
        with self.assertRaises(ApplicationHandlerStop):
            await start.gate(upd, self.ctx())
        self.assertIn("join", self.log[-1][1].lower())
        self.assertEqual(await repo.confirmed_referrals(100), 0)         # not rewarded before joining
        self.bot.member_status = "member"
        d["force_sub"]._cache.clear()
        await start.gate(self.update(200, "hello"), self.ctx())
        self.assertEqual(await repo.confirmed_referrals(100), 1)
        await start.gate(self.update(200, "again"), self.ctx())
        self.assertEqual(await repo.confirmed_referrals(100), 1)         # only once

    async def test_force_sub_misconfiguration_fails_open(self):
        d = self.app.bot_data
        await d["repo"].add_channel("@chan", "", "")
        from telegram.error import BadRequest

        async def boom(*a): raise BadRequest("chat not found")
        self.bot.get_chat_member = boom
        await start.gate(self.update(300, "hi"), self.ctx())            # must not lock users out

    async def test_rate_limit(self):
        d = self.app.bot_data
        for _ in range(self.settings.rate_limit_per_minute):
            await start.gate(self.update(400), self.ctx())
        with self.assertRaises(ApplicationHandlerStop):
            await start.gate(self.update(400), self.ctx())


class DownloadFlowTests(FlowBase):
    async def test_link_to_upload_end_to_end(self):
        d = self.app.bot_data
        with mock.patch("handlers.download.validate_url_async", new=fake_validate):
            upd = self.update(42, "https://example.com/watch?v=1")
            await start.gate(upd, self.ctx())
            await router.on_text(upd, self.ctx())
        card = [e for e in self.log if e[0] == "reply" and "Choose a format" in e[1]]
        self.assertTrue(card, self.log)
        data = keyboard_data(card[0][2])
        self.assertTrue(any(x.endswith(":v:best") for x in data))
        choose = next(x for x in data if x.endswith(":v:best"))

        answers = []

        async def answer(*a, **k): answers.append((a, k))
        cq_msg = Msg(self.log, "card", 42)
        cb = SimpleNamespace(data=choose, message=cq_msg, answer=answer, edit_message_reply_markup=cq_msg.edit_reply_markup)
        upd2 = self.update(42, callback=cb)
        await download.on_download_callback(upd2, self.ctx())

        for _ in range(100):                                              # wait for the queue worker
            await asyncio.sleep(0.05)
            if any(m[0] == "video" or m[0] == "document" for m in self.bot.sent):
                break
        await asyncio.sleep(0.2)
        self.assertTrue(self.bot.sent, "nothing was uploaded")
        rows = await d["repo"].recent_downloads(42, 5)
        self.assertEqual(rows[0]["status"], "done")
        progress = [m for m in self.log if m[0] == "reply" and "queue" in m[1].lower()]
        self.assertTrue(progress)

    async def test_invalid_url_gets_friendly_reply_and_no_job(self):
        upd = self.update(42, "http://127.0.0.1/admin")
        await start.gate(upd, self.ctx())
        with mock.patch("handlers.download.validate_url_async", new=fake_validate):
            await router.on_text(upd, self.ctx())
        self.assertEqual(await self.app.bot_data["repo"].recent_downloads(42, 5), [])

    async def test_daily_limit_for_free_users(self):
        d = self.app.bot_data; repo = d["repo"]
        await repo.upsert_user(55, "u", "U")
        await repo.set_setting("limit.free_daily", 1)
        await repo.create_download("old", 55, "https://e.com/x", status="done")
        upd = self.update(55, "https://example.com/v")
        await download.process_url(upd.message, self.ctx(), upd.effective_user, "https://example.com/v")
        self.assertIn("limit", self.log[-1][1])


class AdminGuardTests(FlowBase):
    async def test_non_admin_cannot_open_panel_or_press_buttons(self):
        upd = self.update(9, "/admin")
        await admin.admin_cmd(upd, self.ctx())
        self.assertEqual(self.log, [])
        answers = []

        async def answer(*a, **k): answers.append(k)
        cb = SimpleNamespace(data="adm:maint", message=Msg(self.log), answer=answer)
        await admin.on_admin_callback(self.update(9, callback=cb), self.ctx())
        self.assertTrue(answers[0].get("show_alert"))
        self.assertFalse(await self.app.bot_data["repo"].get_bool_setting("maintenance", False))

    async def test_admin_maintenance_toggle_is_audited(self):
        answers = []

        async def answer(*a, **k): answers.append(k)
        msg = Msg(self.log, "panel")
        cb = SimpleNamespace(data="adm:maint", message=msg, answer=answer)
        await admin.on_admin_callback(self.update(5147383605, callback=cb), self.ctx())
        d = self.app.bot_data
        self.assertTrue(await d["repo"].get_bool_setting("maintenance", False))
        self.assertEqual((await d["repo"].recent_audit(1))[0]["action"], "maintenance")

    async def test_admin_text_input_ignored_for_regular_users(self):
        ud = {"admin_wait": ("addkey", "pixabay")}
        self._ud = ud
        upd = self.update(77, "SECRET-KEY-VALUE")
        await start.gate(upd, self.ctx())
        await router.on_text(upd, self.ctx())
        self.assertEqual(await self.app.bot_data["key_bank"].count("pixabay"), 0)


if __name__ == "__main__":
    unittest.main()
