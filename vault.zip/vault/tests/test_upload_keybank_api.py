import tempfile
import unittest
from pathlib import Path

from api.base_client import ApiClient, ApiError, HttpResponse
from api.providers.cobalt import CobaltError, CobaltProvider
from api.providers.stock import PixabayProvider, UnsplashProvider
from services.key_bank import KeyBank, NoKeyAvailable
from services.upload_service import choose_method, resend_cached, send_with_retry, upload_file
from services.thumbnail_service import fetch_thumbnail
from tests.helpers import FakeBackend, FakeBot, make_repo
from utils.secrets_box import SecretBox
from utils.tg_compat import BadRequest, Forbidden, NetworkError, RetryAfter, TimedOut


async def no_sleep(_):
    return None


class UploadTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.f = Path(self.tmp.name) / "v.mp4"; self.f.write_bytes(b"x" * 10)

    def test_choose_method(self):
        self.assertEqual(choose_method(Path("a.mp4"), "video", 10), "video")
        self.assertEqual(choose_method(Path("a.mkv"), "video", 10), "document")
        self.assertEqual(choose_method(Path("a.mp3"), "audio", 10), "audio")
        self.assertEqual(choose_method(Path("a.opus"), "audio", 10), "document")
        self.assertEqual(choose_method(Path("a.jpg"), "image", 10), "photo")
        self.assertEqual(choose_method(Path("a.jpg"), "image", 50 << 20), "document")
        self.assertEqual(choose_method(Path("a.webp"), "image", 10), "document")

    async def test_success_reports_file_id(self):
        bot = FakeBot()
        up = await upload_file(bot, 1, self.f, kind="video", caption="<b>x</b>", sleep=no_sleep)
        self.assertEqual((up.file_id, up.method), ("video-id", "video"))

    async def test_retries_flood_and_timeouts_then_succeeds(self):
        bot = FakeBot(failures=[RetryAfter(1), TimedOut("t")])
        up = await upload_file(bot, 1, self.f, kind="video", caption="c", sleep=no_sleep)
        self.assertEqual(up.method, "video"); self.assertEqual(bot.failures, [])

    async def test_gives_up_after_bounded_attempts(self):
        bot = FakeBot(failures=[NetworkError("n")] * 5)
        with self.assertRaises(NetworkError):
            await upload_file(bot, 1, self.f, kind="video", caption="c", sleep=no_sleep)
        self.assertEqual(len(bot.failures), 2)                  # exactly 3 attempts were made

    async def test_permanent_errors_are_not_retried(self):
        bot = FakeBot(failures=[Forbidden("blocked by user")] * 3)
        with self.assertRaises(Forbidden):
            await upload_file(bot, 1, self.f, kind="video", caption="c", sleep=no_sleep)
        self.assertEqual(len(bot.failures), 2)

    async def test_bad_caption_markup_retries_plain(self):
        bot = FakeBot(failures=[BadRequest("Can't parse entities")])
        up = await upload_file(bot, 1, self.f, kind="video", caption="<b>broken", sleep=no_sleep)
        self.assertEqual(up.file_id, "video-id")
        self.assertIsNone(bot.sent[0][1]["caption"])

    async def test_send_with_retry_helper(self):
        calls = []

        async def f():
            calls.append(1)
            if len(calls) < 2:
                raise TimedOut("x")
            return "ok"
        self.assertEqual(await send_with_retry(f, sleep=no_sleep), "ok")

    async def test_resend_cached(self):
        up = await resend_cached(FakeBot(), 1, "FID", "document", "cap")
        self.assertEqual(up.method, "document")


class KeyBankTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.repo = make_repo(Path(self.tmp.name))
        self.bank = KeyBank(self.repo, SecretBox(""))

    async def test_rotation_on_rate_limit(self):
        await self.bank.add("svc", "key-one-aaaa"); await self.bank.add("svc", "key-two-bbbb")
        used = []

        async def call(key):
            used.append(key)
            if key == "key-one-aaaa":
                raise ApiError("rate_limit", "429", 429)
            return "ok"
        self.assertEqual(await self.bank.with_key("svc", call), "ok")
        self.assertEqual(used, ["key-one-aaaa", "key-two-bbbb"])
        used.clear()
        self.assertEqual(await self.bank.with_key("svc", call), "ok")      # first key is cooling down
        self.assertEqual(used, ["key-two-bbbb"])

    async def test_all_keys_exhausted_raises_last_error(self):
        await self.bank.add("svc", "key-one-aaaa")

        async def call(key): raise ApiError("rate_limit", "429", 429)
        with self.assertRaises(ApiError):
            await self.bank.with_key("svc", call)
        with self.assertRaises(NoKeyAvailable) as cm:
            await self.bank.with_key("svc", call)
        self.assertTrue(cm.exception.configured)

    async def test_no_keys_and_invalid_request_not_rotated(self):
        with self.assertRaises(NoKeyAvailable) as cm:
            await self.bank.with_key("none", lambda k: None)
        self.assertFalse(cm.exception.configured)
        await self.bank.add("svc", "key-one-aaaa"); await self.bank.add("svc", "key-two-bbbb")
        seen = []

        async def call(key):
            seen.append(key); raise ApiError("invalid", "bad request", 400)
        with self.assertRaises(ApiError):
            await self.bank.with_key("svc", call)
        self.assertEqual(len(seen), 1)

    async def test_auth_error_disables_key_for_a_day(self):
        await self.bank.add("svc", "key-one-aaaa")

        async def call(key): raise ApiError("auth", "401", 401)
        with self.assertRaises(ApiError):
            await self.bank.with_key("svc", call)
        self.assertEqual(self.repo.available_api_keys("svc"), [])

    async def test_seed_dedupes(self):
        self.assertEqual(await self.bank.seed({"a": ("k-aaaaaa", "k-bbbbbb")}), 2)
        self.assertEqual(await self.bank.seed({"a": ("k-aaaaaa",)}), 0)


class ApiClientTests(unittest.IsolatedAsyncioTestCase):
    async def test_rejects_unsafe_base_url(self):
        for url in ("http://127.0.0.1/", "http://localhost:8080", "file:///x", "http://10.1.1.1"):
            with self.assertRaises(ApiError, msg=url):
                ApiClient("x", url, backend=FakeBackend())

    async def test_retries_transient_but_not_rate_limit(self):
        be = FakeBackend([HttpResponse(503), ApiError("timeout"), HttpResponse(200, b'{"a":1}')])
        c = ApiClient("x", "https://api.example.com", backend=be, sleep=no_sleep)
        self.assertEqual(await c.request("GET", "/p"), {"a": 1}); self.assertEqual(len(be.requests), 3)
        be = FakeBackend([HttpResponse(429, b"", {"retry-after": "7"})])
        c = ApiClient("x", "https://api.example.com", backend=be, sleep=no_sleep)
        with self.assertRaises(ApiError) as cm:
            await c.request("GET", "/p")
        self.assertEqual((cm.exception.kind, cm.exception.retry_after, len(be.requests)), ("rate_limit", 7, 1))

    async def test_validation_and_bad_json(self):
        c = ApiClient("x", "https://api.example.com", backend=FakeBackend([HttpResponse(200, b"not json")]), sleep=no_sleep)
        with self.assertRaises(ApiError):
            await c.request("GET", "/p")
        c = ApiClient("x", "https://api.example.com", backend=FakeBackend([HttpResponse(200, b'{"a":1}')]), sleep=no_sleep)
        with self.assertRaises(ApiError):
            await c.request("GET", "/p", validator=lambda d: "results" in d)


class ProviderTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.bank = KeyBank(make_repo(Path(self.tmp.name)), SecretBox(""))

    async def test_unsplash_rotates_and_parses(self):
        await self.bank.add("unsplash", "unsplash-key-1"); await self.bank.add("unsplash", "unsplash-key-2")
        body = b'{"results":[{"id":"p1","urls":{"small":"s","full":"f"},"user":{"name":"Ann"},"links":{"html":"h"}}]}'
        be = FakeBackend([HttpResponse(403, b"Rate Limit Exceeded"), HttpResponse(200, body)])
        # 403 from Unsplash on quota => treated as auth failure for that key, next key is tried
        prov = UnsplashProvider(self.bank, backend=be); prov.client.min_interval = 0
        items = await prov.search("cats", 1)
        self.assertEqual((items[0].id, items[0].author, items[0].download_url), ("p1", "Ann", "f"))
        self.assertEqual(be.requests[0]["headers"]["Authorization"], "Client-ID unsplash-key-1")
        self.assertEqual(be.requests[1]["headers"]["Authorization"], "Client-ID unsplash-key-2")

    async def test_pixabay_photos_and_videos(self):
        await self.bank.add("pixabay", "pix-key-123456")
        photos = b'{"hits":[{"id":1,"user":"u","webformatURL":"w","largeImageURL":"l","pageURL":"p","tags":"a,b"}]}'
        videos = b'{"hits":[{"id":2,"user":"v","pageURL":"p","tags":"t","duration":9,"videos":{"medium":{"url":"https://v/m.mp4","width":1280,"height":720}}}]}'
        be = FakeBackend([HttpResponse(200, photos), HttpResponse(200, videos)])
        prov = PixabayProvider(self.bank, backend=be); prov.client.min_interval = 0
        p = await prov.search_images("sea", 1)
        v = await prov.search_videos("sea", 1)
        self.assertEqual((p[0].download_url, v[0].download_url, v[0].kind), ("l", "https://v/m.mp4", "video"))
        self.assertEqual(be.requests[0]["params"]["key"], "pix-key-123456")

    async def test_cobalt_mapping(self):
        be = FakeBackend([HttpResponse(200, b'{"status":"tunnel","url":"https://x/y.mp4","filename":"y.mp4"}'),
                          HttpResponse(200, b'{"status":"error","error":{"code":"error.api.link.unsupported"}}')])
        prov = CobaltProvider("http://127.0.0.1:9000", "k", backend=be)     # operator-configured local instance
        res = await prov.resolve("https://example.com/v", "video", 720, "best")
        self.assertEqual(res.url, "https://x/y.mp4")
        self.assertEqual(be.requests[0]["json"]["videoQuality"], "720")
        self.assertEqual(be.requests[0]["headers"]["Authorization"], "Api-Key k")
        with self.assertRaises(CobaltError) as cm:
            await prov.resolve("https://example.com/v", "video", None, "best")
        self.assertEqual(cm.exception.category.value, "unsupported")
        self.assertFalse(CobaltProvider("").configured())

    async def test_thumbnail_rejects_private_urls(self):
        be = FakeBackend()
        out = await fetch_thumbnail("http://169.254.169.254/x.jpg", Path(self.tmp.name), be)
        self.assertIsNone(out); self.assertEqual(be.downloads, [])


if __name__ == "__main__":
    unittest.main()
