"""Shared fakes: mocked engines, bot and HTTP backend (no real downloads or network)."""
from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path
from types import SimpleNamespace
from typing import Any

from api.base_client import ApiError, HttpResponse
from config import load_settings
from database import Database, Repository, migrate
from engines.base import (BaseEngine, DownloadResult, EngineError, FormatOption, MediaInfo, ProgressEvent)

TOKEN = "123456789:" + "A" * 35


def make_settings(tmp: Path, **extra):
    env = {"BOT_TOKEN": TOKEN, "ADMIN_IDS": "5147383605", "DATABASE_URL": f"sqlite:///{tmp / 'bot.db'}",
           "DOWNLOAD_DIR": str(tmp / "dl"), "TEMP_DIR": str(tmp / "temp"), "LOG_DIR": str(tmp / "logs"),
           "MAX_FILE_SIZE_MB": "1900", **{k: str(v) for k, v in extra.items()}}
    s = load_settings(env, base_dir=tmp)
    s.ensure_dirs()
    return s


def make_repo(tmp: Path) -> Repository:
    db = Database(tmp / "bot.db").connect()
    migrate(db)
    return Repository(db)


class FakeEngine(BaseEngine):
    def __init__(self, name="fake", priority=10, script=None, available=True, handles=True,
                 audio=True, size=2048):
        super().__init__({})
        self.name, self.display_name, self.default_priority = name, name, priority
        self.supports_audio = audio
        self._available, self._handles = available, handles
        self.script: list[Any] = list(script or [])
        self.calls = 0
        self.size = size

    def is_available(self): return self._available
    def version(self): return "test"
    def can_handle(self, url): return self._handles

    async def extract_info(self, url, *, cookies_file=None):
        self.calls += 1
        if self.script and isinstance(self.script[0], EngineError):
            raise self.script.pop(0)
        return MediaInfo(url=url, title="Test <video>", uploader="Chan", duration=65, engine=self.name,
                         thumbnail=None, formats=[FormatOption("1", "video", "mp4", 720, None, 1000)])

    async def download(self, req, progress, cancel):
        self.calls += 1
        outcome = self.script.pop(0) if self.script else "ok"
        if isinstance(outcome, Exception):
            raise outcome
        if outcome == "slow":
            await asyncio.sleep(5)
        req.out_dir.mkdir(parents=True, exist_ok=True)
        path = req.out_dir / ("audio.mp3" if req.kind == "audio" else "video.mp4")
        path.write_bytes(b"x" * self.size)
        progress(ProgressEvent("downloading", 50.0, 1, 2))
        return DownloadResult(path, path.suffix[1:], self.size, self.name)


class FakeBot:
    """Records calls; `failures` is a list of exceptions raised before success."""

    def __init__(self, failures=None):
        self.failures = list(failures or [])
        self.sent: list[tuple[str, dict]] = []

    def _go(self, method, attr, **kw):
        async def run():
            if self.failures:
                raise self.failures.pop(0)
            self.sent.append((method, {k: v for k, v in kw.items() if k != "video" and k != "audio" and k != "document" and k != "photo"}))
            payload = SimpleNamespace(file_id=f"{method}-id")
            msg = SimpleNamespace(message_id=len(self.sent))
            if method == "photo":
                msg.photo = [payload]
            else:
                setattr(msg, method, payload)
            return msg
        return run()

    def send_video(self, **kw): return self._go("video", "video", **kw)
    def send_audio(self, **kw): return self._go("audio", "audio", **kw)
    def send_photo(self, **kw): return self._go("photo", "photo", **kw)
    def send_document(self, **kw): return self._go("document", "document", **kw)


class FakeBackend:
    """HTTP backend returning scripted responses; records requests."""

    def __init__(self, responses=None):
        self.responses = list(responses or [])
        self.requests: list[dict] = []
        self.downloads: list[str] = []

    async def request(self, method, url, *, headers=None, params=None, json_body=None, timeout=15.0):
        self.requests.append({"method": method, "url": url, "headers": headers or {}, "params": params,
                              "json": json_body})
        item = self.responses.pop(0) if self.responses else HttpResponse(200, b"{}")
        if isinstance(item, Exception):
            raise item
        return item

    async def download(self, url, path, **kw):
        self.downloads.append(url)
        Path(path).write_bytes(b"img")
        return 3


def tmpdir() -> tempfile.TemporaryDirectory:
    return tempfile.TemporaryDirectory()
