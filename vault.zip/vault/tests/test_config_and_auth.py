import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from config import ConfigError, load_settings
from utils.auth import admin_only, is_admin_update
from tests.helpers import TOKEN, make_settings

ADMIN = 5147383605


class ConfigTests(unittest.TestCase):
    def base(self, **kw):
        env = {"BOT_TOKEN": TOKEN, "ADMIN_IDS": str(ADMIN)}
        env.update(kw)
        return env

    def test_valid(self):
        s = load_settings(self.base(), base_dir=Path("/tmp/x"))
        self.assertEqual(s.admin_ids, frozenset({ADMIN}))
        self.assertEqual(s.database_path, Path("/tmp/x/data/bot.db"))
        self.assertEqual(s.max_concurrent_downloads, 3)

    def test_missing_token(self):
        with self.assertRaises(ConfigError):
            load_settings({"ADMIN_IDS": "1"})

    def test_garbage_token_and_backslash_artifacts(self):
        with self.assertRaises(ConfigError):
            load_settings({"BOT_TOKEN": "\\", "ADMIN_IDS": "1"})
        s = load_settings(self.base(ADMIN_IDS=f"{ADMIN}\\"))
        self.assertIn(ADMIN, s.admin_ids)

    def test_non_numeric_admin(self):
        with self.assertRaises(ConfigError):
            load_settings(self.base(ADMIN_IDS="@someone"))

    def test_requires_admin(self):
        with self.assertRaises(ConfigError):
            load_settings({"BOT_TOKEN": TOKEN, "ADMIN_IDS": ""})

    def test_bad_numbers_and_db(self):
        with self.assertRaises(ConfigError):
            load_settings(self.base(MAX_CONCURRENT_DOWNLOADS="0"))
        with self.assertRaises(ConfigError):
            load_settings(self.base(MAX_FILE_SIZE_MB="abc"))
        with self.assertRaises(ConfigError):
            load_settings(self.base(DATABASE_URL="postgresql://x"))
        with self.assertRaises(ConfigError):
            load_settings(self.base(LOG_LEVEL="LOUD"))

    def test_upload_limit_is_conservative(self):
        s = load_settings(self.base(MAX_FILE_SIZE_MB="1900"))
        self.assertEqual(s.upload_limit_mb, 49)           # cloud Bot API
        s = load_settings(self.base(MAX_FILE_SIZE_MB="1900", LOCAL_BOT_API_URL="http://127.0.0.1:8081"))
        self.assertEqual(s.upload_limit_mb, 1900)
        s = load_settings(self.base(MAX_FILE_SIZE_MB="3000", LOCAL_BOT_API_URL="http://127.0.0.1:8081"))
        self.assertEqual(s.upload_limit_mb, 1990)

    def test_seed_keys(self):
        s = load_settings(self.base(PIXABAY_API_KEY="abc123", UNSPLASH_ACCESS_KEYS="k1, k2"))
        self.assertEqual(s.seed_keys["pixabay"], ("abc123",))
        self.assertEqual(s.seed_keys["unsplash"], ("k1", "k2"))


class AuthTests(unittest.IsolatedAsyncioTestCase):
    def make_update(self, uid, callback=False):
        answers = []

        async def answer(*a, **k):
            answers.append((a, k))
        upd = SimpleNamespace(effective_user=SimpleNamespace(id=uid) if uid is not None else None,
                              callback_query=SimpleNamespace(answer=answer) if callback else None)
        return upd, answers

    def ctx(self):
        with tempfile.TemporaryDirectory() as d:
            settings = make_settings(Path(d))
        return SimpleNamespace(application=SimpleNamespace(bot_data={"settings": settings}))

    def test_is_admin_update(self):
        ids = frozenset({ADMIN})
        self.assertTrue(is_admin_update(SimpleNamespace(effective_user=SimpleNamespace(id=ADMIN)), ids))
        self.assertFalse(is_admin_update(SimpleNamespace(effective_user=SimpleNamespace(id=1)), ids))
        self.assertFalse(is_admin_update(SimpleNamespace(effective_user=None), ids))
        self.assertFalse(is_admin_update(SimpleNamespace(effective_user=SimpleNamespace(id="5147383605")), ids))

    async def test_admin_allowed_and_user_blocked(self):
        calls = []

        @admin_only
        async def handler(update, context):
            calls.append(update.effective_user.id)
            return "ok"

        ctx = self.ctx()
        upd, _ = self.make_update(ADMIN)
        self.assertEqual(await handler(upd, ctx), "ok")
        upd, _ = self.make_update(999)
        self.assertIsNone(await handler(upd, ctx))
        upd, answers = self.make_update(999, callback=True)
        self.assertIsNone(await handler(upd, ctx))
        self.assertTrue(answers and answers[0][1].get("show_alert"))
        upd, _ = self.make_update(None)
        self.assertIsNone(await handler(upd, ctx))
        self.assertEqual(calls, [ADMIN])


if __name__ == "__main__":
    unittest.main()
