import asyncio
import tempfile
import unittest
from pathlib import Path

from engines.base import (CancelToken, DownloadRequest, EngineError, ErrorCategory, classify_message)
from engines.registry import EngineRegistry
from engines.ytdlp_engine import build_audio_postprocessors, build_format_selector, YtDlpEngine
from engines.gallery_engine import GalleryDlEngine
from engines.streamlink_engine import StreamlinkEngine
from services.fallback_service import AllEnginesFailed, FallbackService
from tests.helpers import FakeEngine, make_repo


async def no_sleep(_):
    return None


def req(tmp, kind="video", url="https://example.com/v"):
    return DownloadRequest(job_id="j1", url=url, kind=kind, out_dir=Path(tmp) / "j1")


class ClassificationTests(unittest.TestCase):
    def test_messages(self):
        c = classify_message
        self.assertEqual(c("ERROR: Sign in to confirm you’re not a bot"), ErrorCategory.AUTH_REQUIRED)
        self.assertEqual(c("Private video. Sign in if you've been granted access"), ErrorCategory.PRIVATE)
        self.assertEqual(c("This video is DRM protected"), ErrorCategory.DRM)
        self.assertEqual(c("Unsupported URL: https://x.y"), ErrorCategory.UNSUPPORTED)
        self.assertEqual(c("HTTP Error 429: Too Many Requests"), ErrorCategory.RATE_LIMIT)
        self.assertEqual(c("Requested format is not available"), ErrorCategory.FORMAT_UNAVAILABLE)
        self.assertEqual(c("weird"), ErrorCategory.UNKNOWN)

    def test_policy(self):
        self.assertTrue(ErrorCategory.NETWORK.retryable)
        for cat in (ErrorCategory.DRM, ErrorCategory.PRIVATE, ErrorCategory.INVALID_URL, ErrorCategory.CANCELLED,
                    ErrorCategory.TOO_LARGE):
            self.assertFalse(cat.retryable); self.assertFalse(cat.fallbackable)
        self.assertFalse(ErrorCategory.UNSUPPORTED.retryable)
        self.assertTrue(ErrorCategory.UNSUPPORTED.fallbackable)

    def test_format_selectors(self):
        self.assertEqual(build_format_selector("video", None), "bv*+ba/b")
        self.assertIn("height<=720", build_format_selector("video", 720))
        self.assertEqual(build_format_selector("audio", None), "bestaudio/best")
        self.assertEqual(build_audio_postprocessors("best"), [])
        self.assertEqual(build_audio_postprocessors("mp3")[0]["preferredcodec"], "mp3")


class RegistryTests(unittest.TestCase):
    def test_priority_enable_and_capabilities(self):
        with tempfile.TemporaryDirectory() as d:
            repo = make_repo(Path(d))
            reg = EngineRegistry(repo)
            a = FakeEngine("a", 20); b = FakeEngine("b", 10); c = FakeEngine("c", 5, available=False)
            e = FakeEngine("e", 1, handles=False); f = FakeEngine("f", 30, audio=False)
            for x in (a, b, c, e, f):
                reg.register(x)
            self.assertEqual([x.name for x in reg.compatible("https://x.com/y", "video")], ["b", "a", "f"])
            self.assertEqual([x.name for x in reg.compatible("https://x.com/y", "audio")], ["b", "a"])
            reg.set_enabled("b", False)
            self.assertEqual([x.name for x in reg.compatible("https://x.com/y", "video")], ["a", "f"])
            reg.set_priority("f", 1)
            self.assertEqual(reg.compatible("https://x.com/y", "video")[0].name, "f")
            # persisted
            reg2 = EngineRegistry(repo)
            for x in (a, b, f):
                reg2.register(x)
            self.assertFalse(reg2.is_enabled("b")); self.assertEqual(reg2.priority("f"), 1)

    def test_missing_optional_dependencies_do_not_crash(self):
        reg = EngineRegistry()
        reg.register(YtDlpEngine()); reg.register(GalleryDlEngine()); reg.register(StreamlinkEngine())
        rows = reg.describe()                                       # must not raise whatever is installed
        self.assertEqual({r["name"] for r in rows}, {"ytdlp", "gallerydl", "streamlink"})
        # engines whose tools are absent are simply skipped
        names = [e.name for e in reg.usable()]
        for r in rows:
            self.assertEqual(r["name"] in names, r["available"] and r["enabled"])

        class Broken(FakeEngine):
            def is_available(self): raise RuntimeError("import exploded")
        reg.register(Broken("broken"))
        self.assertNotIn("broken", [e.name for e in reg.usable()])


class FallbackTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.repo = make_repo(Path(self.tmp.name))

    def service(self, *engines, **kw):
        reg = EngineRegistry(self.repo)
        for e in engines:
            reg.register(e)
        return FallbackService(reg, self.repo, sleep=no_sleep, **kw), reg

    async def test_first_engine_success(self):
        a, b = FakeEngine("a", 1), FakeEngine("b", 2)
        svc, _ = self.service(a, b)
        res = await svc.download(req(self.tmp.name), lambda e: None, CancelToken())
        self.assertEqual(res.engine, "a"); self.assertEqual(b.calls, 0)

    async def test_falls_back_on_unsupported(self):
        a = FakeEngine("a", 1, script=[EngineError(ErrorCategory.UNSUPPORTED, "no")])
        b = FakeEngine("b", 2)
        svc, _ = self.service(a, b)
        res = await svc.download(req(self.tmp.name), lambda e: None, CancelToken())
        self.assertEqual(res.engine, "b")
        self.assertEqual(len(self.repo.attempts_for("j1")), 2)

    async def test_retries_network_then_succeeds_without_fallback(self):
        a = FakeEngine("a", 1, script=[EngineError(ErrorCategory.NETWORK, "x"), EngineError(ErrorCategory.TIMEOUT, "y")])
        b = FakeEngine("b", 2)
        svc, _ = self.service(a, b, max_retries=2)
        res = await svc.download(req(self.tmp.name), lambda e: None, CancelToken())
        self.assertEqual((res.engine, a.calls, b.calls), ("a", 3, 0))

    async def test_retries_are_bounded_then_falls_back(self):
        a = FakeEngine("a", 1, script=[EngineError(ErrorCategory.NETWORK, "x")] * 10)
        b = FakeEngine("b", 2)
        svc, _ = self.service(a, b, max_retries=2)
        res = await svc.download(req(self.tmp.name), lambda e: None, CancelToken())
        self.assertEqual((res.engine, a.calls), ("b", 3))

    async def test_permanent_failures_are_not_retried_or_forwarded(self):
        for cat in (ErrorCategory.PRIVATE, ErrorCategory.DRM, ErrorCategory.TOO_LARGE):
            a = FakeEngine("a", 1, script=[EngineError(cat, "no")] * 5)
            b = FakeEngine("b", 2)
            svc, _ = self.service(a, b)
            with self.assertRaises(AllEnginesFailed) as cm:
                await svc.download(req(self.tmp.name), lambda e: None, CancelToken())
            self.assertEqual((a.calls, b.calls, cm.exception.category), (1, 0, cat))

    async def test_all_fail_returns_last_error(self):
        a = FakeEngine("a", 1, script=[EngineError(ErrorCategory.UNSUPPORTED, "a")])
        b = FakeEngine("b", 2, script=[EngineError(ErrorCategory.UNKNOWN, "b")])
        svc, _ = self.service(a, b)
        with self.assertRaises(AllEnginesFailed) as cm:
            await svc.download(req(self.tmp.name), lambda e: None, CancelToken())
        self.assertEqual(cm.exception.category, ErrorCategory.UNKNOWN)
        self.assertEqual([n for n, _ in cm.exception.attempts], ["a", "b"])

    async def test_timeout_cancels_and_falls_back(self):
        a = FakeEngine("a", 1, script=["slow"] * 5); a.settings["timeout"] = 0.05
        b = FakeEngine("b", 2)
        svc, _ = self.service(a, b, max_retries=0)
        res = await svc.download(req(self.tmp.name), lambda e: None, CancelToken())
        self.assertEqual(res.engine, "b")

    async def test_cancel_stops_everything(self):
        a = FakeEngine("a", 1, script=[EngineError(ErrorCategory.CANCELLED, "c")]); b = FakeEngine("b", 2)
        svc, _ = self.service(a, b)
        with self.assertRaises(EngineError) as cm:
            await svc.download(req(self.tmp.name), lambda e: None, CancelToken())
        self.assertEqual(cm.exception.category, ErrorCategory.CANCELLED); self.assertEqual(b.calls, 0)
        tok = CancelToken(); tok.cancel()
        with self.assertRaises(EngineError):
            await svc.download(req(self.tmp.name), lambda e: None, tok)

    async def test_no_compatible_engine(self):
        svc, _ = self.service(FakeEngine("a", 1, handles=False))
        with self.assertRaises(AllEnginesFailed):
            await svc.download(req(self.tmp.name), lambda e: None, CancelToken())

    async def test_info_cached_and_health_recorded(self):
        a = FakeEngine("a", 1)
        svc, reg = self.service(a)
        await svc.get_info("https://example.com/v"); await svc.get_info("https://example.com/v")
        self.assertEqual(a.calls, 1)
        await svc.download(req(self.tmp.name), lambda e: None, CancelToken())
        self.assertEqual(self.repo.get_engine("a")["success_count"], 1)

    async def test_crashing_engine_is_contained(self):
        class Crash(FakeEngine):
            async def download(self, *a, **k): raise ZeroDivisionError("bug")
        svc, _ = self.service(Crash("a", 1), FakeEngine("b", 2))
        res = await svc.download(req(self.tmp.name), lambda e: None, CancelToken())
        self.assertEqual(res.engine, "b")


if __name__ == "__main__":
    unittest.main()
