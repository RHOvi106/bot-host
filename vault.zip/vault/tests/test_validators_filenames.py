import tempfile
import unittest
from pathlib import Path

from utils.filenames import ensure_within, safe_filename, unique_path
from utils.logging_setup import SecretFilter
from utils.ratelimit import RateLimiter
from utils.validators import InvalidUrl, extract_urls, platform_of, validate_url


class UrlTests(unittest.TestCase):
    def test_accepts_public(self):
        self.assertEqual(validate_url("https://www.youtube.com/watch?v=abc#t=5"), "https://www.youtube.com/watch?v=abc")
        self.assertEqual(platform_of("https://m.youtube.com/x"), "youtube")
        self.assertEqual(platform_of("https://www.bbc.co.uk/x"), "bbc")

    def test_rejects_bad_schemes(self):
        for u in ["file:///etc/passwd", "ftp://example.com/x", "javascript:alert(1)", "", "   ", "example.com",
                  "http://", "https://user:pw@example.com/"]:
            with self.assertRaises(InvalidUrl, msg=u):
                validate_url(u)

    def test_rejects_private_and_local(self):
        for u in ["http://localhost/x", "http://127.0.0.1/", "http://10.0.0.5/", "http://192.168.1.1/",
                  "http://169.254.169.254/latest/meta-data", "http://[::1]/", "http://[::ffff:127.0.0.1]/",
                  "http://2130706433/", "http://0x7f.0.0.1/", "http://printer.local/", "http://intranet/",
                  "http://metadata.google.internal/", "http://0.0.0.0/"]:
            with self.assertRaises(InvalidUrl, msg=u):
                validate_url(u)

    def test_rejects_whitespace_and_long(self):
        with self.assertRaises(InvalidUrl):
            validate_url("https://example.com/a b")
        with self.assertRaises(InvalidUrl):
            validate_url("https://example.com/" + "a" * 3000)

    def test_extract(self):
        self.assertEqual(extract_urls("look (https://a.com/x), and http://b.org/y."), ["https://a.com/x", "http://b.org/y"])


class FilenameTests(unittest.TestCase):
    def test_sanitizes(self):
        self.assertEqual(safe_filename('a<b>:c"/d\\e|f?g*.mp4'), "a_b__c__d_e_f_g_.mp4")
        self.assertEqual(safe_filename("CON.mp4"), "_CON.mp4")
        self.assertEqual(safe_filename("..."), "media")
        r = safe_filename("../../etc/passwd")
        self.assertNotIn("/", r); self.assertFalse(r.startswith("."))
        self.assertEqual(safe_filename("name. "), "name")

    def test_truncates_keeping_extension(self):
        n = safe_filename("x" * 300 + ".mp4", max_len=50)
        self.assertEqual(len(n), 50)
        self.assertTrue(n.endswith(".mp4"))

    def test_path_traversal(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d)
            ensure_within(base, base / "a" / "b.txt")
            with self.assertRaises(ValueError):
                ensure_within(base, base / ".." / "evil.txt")

    def test_unique_path(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / "a.mp4").write_bytes(b"1")
            self.assertEqual(unique_path(Path(d), "a.mp4").name, "a (1).mp4")


class MiscTests(unittest.TestCase):
    def test_log_redaction(self):
        f = SecretFilter(["supersecretvalue"])
        txt = f.redact("url https://api.telegram.org/bot123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdef/getMe key=AIzaSyD-abcdefghijklmnopqrstuv "
                       "x supersecretvalue Authorization: Bearer abcdefgh12345678 sk-abcdefghijklmnopqrst")
        for leaked in ("123456789:ABC", "AIzaSyD", "supersecretvalue", "abcdefgh12345678", "sk-abcdef"):
            self.assertNotIn(leaked, txt)

    def test_rate_limiter(self):
        t = [0.0]
        rl = RateLimiter(2, 10, clock=lambda: t[0])
        self.assertTrue(rl.allow("u")); self.assertTrue(rl.allow("u")); self.assertFalse(rl.allow("u"))
        self.assertTrue(rl.allow("other"))
        t[0] = 11
        self.assertTrue(rl.allow("u"))


if __name__ == "__main__":
    unittest.main()
