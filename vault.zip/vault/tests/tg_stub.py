"""Minimal stand-in for python-telegram-bot, installed ONLY when the real package is missing.
It lets handler logic be exercised offline; real-Telegram behaviour still needs a live smoke test."""
from __future__ import annotations

import sys
import types


def install() -> bool:
    try:
        import telegram  # noqa: F401
        return False
    except ImportError:
        pass

    tg = types.ModuleType("telegram"); tg.__version__ = "stub"
    ext = types.ModuleType("telegram.ext"); err = types.ModuleType("telegram.error")

    class Rec:
        def __init__(self, *a, **kw):
            self.args, self.kw = a, kw
            for k, v in kw.items():
                setattr(self, k, v)
            if a:
                self.text = a[0]

    class InlineKeyboardButton(Rec): pass
    class KeyboardButton(Rec): pass

    class InlineKeyboardMarkup(Rec):
        def __init__(self, rows): super().__init__(); self.inline_keyboard = rows

    class ReplyKeyboardMarkup(Rec):
        def __init__(self, rows, **kw): super().__init__(**kw); self.keyboard = rows

    class Update: pass
    for n, c in dict(Update=Update, InlineKeyboardButton=InlineKeyboardButton, KeyboardButton=KeyboardButton,
                     InlineKeyboardMarkup=InlineKeyboardMarkup, ReplyKeyboardMarkup=ReplyKeyboardMarkup).items():
        setattr(tg, n, c)

    class TelegramError(Exception): pass
    class NetworkError(TelegramError): pass
    class TimedOut(NetworkError): pass
    class BadRequest(TelegramError): pass
    class Forbidden(TelegramError): pass

    class RetryAfter(TelegramError):
        def __init__(self, retry_after): super().__init__("flood"); self.retry_after = retry_after
    for n, c in dict(TelegramError=TelegramError, NetworkError=NetworkError, TimedOut=TimedOut, BadRequest=BadRequest,
                     Forbidden=Forbidden, RetryAfter=RetryAfter).items():
        setattr(err, n, c)

    class ApplicationHandlerStop(Exception): pass

    class F:
        def __and__(self, o): return F()
        def __invert__(self): return F()
        def __getattr__(self, n): return F()

    class FakeJobQueue:
        def run_repeating(self, *a, **k): pass

    class FakeApp:
        def __init__(self):
            self.bot_data, self.handlers, self.bot = {}, [], None
            self.job_queue = FakeJobQueue()
            self.post_init = self.post_shutdown = None

        def add_handler(self, h, group=0): self.handlers.append((group, h))
        def add_error_handler(self, h): self.error_handler = h

    class Builder:
        def __getattr__(self, name):
            if name == "build":
                return lambda: FakeApp()
            return lambda *a, **k: self

    class Handler(Rec): pass
    ext.ApplicationBuilder = Builder
    ext.Application = FakeApp
    ext.CallbackQueryHandler = ext.CommandHandler = ext.MessageHandler = ext.TypeHandler = Handler
    ext.filters = F()
    ext.ApplicationHandlerStop = ApplicationHandlerStop
    ext.ContextTypes = types.SimpleNamespace(DEFAULT_TYPE=object)
    tg.ext, tg.error = ext, err
    sys.modules.update({"telegram": tg, "telegram.ext": ext, "telegram.error": err})
    return True
