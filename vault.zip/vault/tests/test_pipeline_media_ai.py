import asyncio
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from ai.ai_manager import AIManager, AIUnavailable, build_system_prompt
from api.base_client import HttpResponse
from database import AsyncProxy
from engines.base import CancelToken, EngineError, ErrorCategory, MediaInfo
from engines.registry import EngineRegistry
from services import media_service
from services.download_service import DownloadService
from services.fallback_service import FallbackService
from services.key_bank import KeyBank
from services.metadata_service import build_caption, from_ytdlp, quality_options
from services.progress_service import ProgressReporter
from services.queue_service import Job
from services.upload_service import UploadedFile
from tests.helpers import FakeBackend, FakeEngine, make_repo, make_settings
from utils.secrets_box import SecretBox

HAS_FFMPEG = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


async def no_sleep(_):
    return None


class FakeUploader:
    def __init__(self, fail=None):
        self.uploaded, self.resent, self.fail = [], [], fail

    async def upload(self, path, **kw):
        if self.fail:
            raise self.fail
        self.uploaded.append((path.name, path.stat().st_size, kw["caption"]))
        return UploadedFile(f"fid{len(self.uploaded)}", "video" if kw["kind"] == "video" else "audio", 1)

    async def resend(self, file_id, method, caption):
        self.resent.append(file_id)
        return UploadedFile(file_id, method, 2)


class PipelineTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.sync_repo = make_repo(self.root)
        self.repo = AsyncProxy(self.sync_repo)

    def build(self, *engines, **settings_kw):
        self.settings = make_settings(self.root, **settings_kw)
        reg = EngineRegistry(self.sync_repo)
        for e in engines:
            reg.register(e)
        fb = FallbackService(reg, self.sync_repo, sleep=no_sleep, max_retries=1)
        alerts = []

        async def notify(t): alerts.append(t)
        self.alerts = alerts
        return DownloadService(settings=self.settings, repo=self.repo, fallback=fb, http_backend=FakeBackend(),
                               cookies_path=lambda: None, notify_admin=notify)

    async def run_job(self, svc, uploader, kind="video", url="https://example.com/v"):
        info = MediaInfo(url=url, title="T", duration=10, engine="")
        job = Job(1, url, kind, "best", payload={"info": info, "prefs": {"send_thumbnail": False}})
        self.sync_repo.upsert_user(1, "u", "U")
        self.sync_repo.create_download(job.job_id, 1, url, kind=kind, quality="best")
        shown = []

        async def edit(t): shown.append(t)
        out = await svc.run_job(job, ProgressReporter(edit, interval=0), uploader)
        return job, out, shown

    async def test_success_records_and_cleans_up(self):
        svc = self.build(FakeEngine("a", 1))
        up = FakeUploader()
        job, out, shown = await self.run_job(svc, up)
        self.assertEqual(out.status, "done")
        row = self.sync_repo.get_download(job.job_id)
        self.assertEqual((row["status"], row["engine"], row["tg_file_id"]), ("done", "a", "fid1"))
        self.assertFalse((self.settings.temp_dir / job.job_id).exists())       # temp files removed
        self.assertTrue(any("Completed" in s for s in shown))

    async def test_cached_upload_is_resent_without_download(self):
        eng = FakeEngine("a", 1)
        svc = self.build(eng)
        await self.run_job(svc, FakeUploader())
        up2 = FakeUploader()
        job, out, _ = await self.run_job(svc, up2)
        self.assertEqual(up2.resent, ["fid1"]); self.assertEqual(eng.calls, 1)

    async def test_failure_is_friendly_and_logged(self):
        svc = self.build(FakeEngine("a", 1, script=[EngineError(ErrorCategory.PRIVATE, "secret trace /home/x")]))
        job, out, _ = await self.run_job(svc, FakeUploader())
        self.assertEqual((out.status, out.category), ("failed", ErrorCategory.PRIVATE))
        self.assertNotIn("trace", out.message)
        self.assertEqual(self.sync_repo.get_download(job.job_id)["error_category"], "private")
        self.assertEqual(len(self.sync_repo.recent_errors()), 1)

    async def test_unexpected_crash_alerts_admin_without_traceback_for_user(self):
        class Boom(FakeUploader):
            async def upload(self, *a, **k): raise KeyError("internal")
        svc = self.build(FakeEngine("a", 1))
        job, out, _ = await self.run_job(svc, Boom())
        self.assertEqual(out.status, "failed"); self.assertNotIn("KeyError", out.message)
        self.assertTrue(self.alerts)
        self.assertFalse((self.settings.temp_dir / job.job_id).exists())

    async def test_cancel_mid_download(self):
        class Slow(FakeEngine):
            async def download(self, req, progress, cancel):
                for _ in range(100):
                    cancel.raise_if_cancelled(self.name)
                    await asyncio.sleep(0.01)
        svc = self.build(Slow("a", 1))
        info = MediaInfo(url="https://e.com/v", title="T")
        job = Job(1, "https://e.com/v", "video", "best", payload={"info": info})
        self.sync_repo.create_download(job.job_id, 1, job.url)
        task = asyncio.create_task(svc.run_job(job, ProgressReporter(lambda t: asyncio.sleep(0), interval=0), FakeUploader()))
        await asyncio.sleep(0.05); job.cancel.cancel()
        out = await task
        self.assertEqual(out.status, "cancelled")
        self.assertEqual(self.sync_repo.get_download(job.job_id)["status"], "cancelled")

    async def test_oversized_file_is_split_and_every_part_uploaded(self):
        svc = self.build(FakeEngine("a", 1, size=3 * 1024 * 1024 + 5), MAX_FILE_SIZE_MB=1900, UPLOAD_LIMIT_MB=1)
        self.settings = self.settings  # upload limit 1 MB
        up = FakeUploader()
        job, out, _ = await self.run_job(svc, up, kind="audio")
        self.assertEqual(out.status, "done")
        self.assertEqual(len(up.uploaded), 4)
        self.assertTrue(all(size <= 1024 * 1024 for _, size, _ in up.uploaded))
        self.assertEqual(sum(s for _, s, _ in up.uploaded), 3 * 1024 * 1024 + 5)
        self.assertIsNone(self.sync_repo.get_download(job.job_id)["tg_file_id"])   # multipart not cached

    async def test_too_many_parts_rejected(self):
        svc = self.build(FakeEngine("a", 1, size=3 * 1024 * 1024), UPLOAD_LIMIT_MB=1, MAX_SPLIT_PARTS=2)
        job, out, _ = await self.run_job(svc, FakeUploader(), kind="audio")
        self.assertEqual((out.status, out.category), ("failed", ErrorCategory.TOO_LARGE))

    async def test_quality_menu_only_offers_real_options(self):
        info = from_ytdlp({"title": "x", "id": "1", "formats": [
            {"format_id": "a", "vcodec": "avc1", "acodec": "none", "height": 1080, "ext": "mp4", "filesize": 1000},
            {"format_id": "b", "vcodec": "avc1", "acodec": "none", "height": 360, "ext": "mp4"},
            {"format_id": "c", "vcodec": "none", "acodec": "mp4a", "abr": 128, "ext": "m4a", "filesize": 100}]},
            "https://example.com/v")
        labels = [l for _, l in quality_options(info)]
        self.assertEqual(labels[0], "Best Available")
        self.assertTrue(labels[1].startswith("1080p")); self.assertTrue(labels[2].startswith("360p"))
        self.assertEqual(len(labels), 3)                      # no 4K / 720p invented
        self.assertEqual(quality_options(MediaInfo(url="u")), [(None, "Best Available")])
        self.assertEqual(from_ytdlp({"title": "t"}, "https://e.com/x").title, "t")   # missing fields tolerated

    def test_caption_escapes_html(self):
        cap = build_caption("<script>&", "720p", "mp4", 5, "A<b>")
        self.assertNotIn("<script>", cap); self.assertIn("&lt;script&gt;&amp;", cap)


@unittest.skipUnless(HAS_FFMPEG, "ffmpeg not installed")
class MediaTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.video = self.root / "clip.mp4"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=size=320x240:rate=25",
                        "-f", "lavfi", "-i", "sine=frequency=440", "-t", "12", "-g", "25", "-c:v", "libx264",
                        "-b:v", "400k", "-c:a", "aac", "-shortest", str(self.video)], check=True)

    async def test_probe_and_thumbnail(self):
        info = await media_service.probe(self.video)
        self.assertEqual((info["width"], info["height"], info["has_audio"]), (320, 240, True))
        self.assertAlmostEqual(info["duration"], 12, delta=1)
        thumb = await media_service.make_thumbnail(self.video, self.root / "t.jpg")
        self.assertTrue(thumb and thumb.stat().st_size < 200 * 1024)

    async def test_split_video_parts_fit_and_play(self):
        limit = self.video.stat().st_size // 3
        parts = await media_service.split_video(self.video, limit, self.root / "parts", 30)
        self.assertGreaterEqual(len(parts), 3)
        self.assertTrue(all(p.stat().st_size <= limit for p in parts))
        for p in parts:
            self.assertTrue((await media_service.probe(p)).get("has_video"))

    async def test_watermark_args_and_run(self):
        png = self.root / "wm.png"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=red:s=64x64", "-frames:v", "1",
                        str(png)], check=True)
        out = await media_service.apply_watermark(self.video, text="", image=str(png), font="")
        self.assertTrue(out.exists() and not self.video.exists())
        with self.assertRaises(ValueError):
            media_service.build_watermark_args(out, out, text="", image="")

    def test_raw_split_roundtrip(self):
        data = Path(self.root / "f.bin"); data.write_bytes(bytes(range(256)) * 100)
        parts = media_service.split_bytes(data, 10000, self.root / "p", 10)
        self.assertEqual(b"".join(p.read_bytes() for p in parts), data.read_bytes())
        with self.assertRaises(EngineError):
            media_service.split_bytes(data, 10, self.root / "p2", 10)


class AITests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.repo = make_repo(Path(self.tmp.name))
        self.settings = make_settings(Path(self.tmp.name))
        self.bank = KeyBank(self.repo, SecretBox(""))

    def test_persona_never_denies_being_ai_and_hides_provider(self):
        p = build_system_prompt("Ovi", "RH_Ovi_106", "Bot")
        self.assertIn("Ovi", p); self.assertIn("automated AI assistant", p)
        self.assertIn("do not discuss which AI model", p)

    async def test_gemini_call_shape_and_history(self):
        await self.bank.add("gemini", "gem-key-123456")
        be = FakeBackend([HttpResponse(200, b'{"candidates":[{"content":{"parts":[{"text":"\xe0\xa6\xb9\xe0\xa7\x8d\xe0\xa6\xaf\xe0\xa6\xbe\xe0\xa6\xb2\xe0\xa7\x8b"}]}}]}')])
        ai = AIManager(self.repo, self.bank, self.settings, backend=be)
        ans = await ai.chat(7, "hi")
        self.assertTrue(ans)
        req = be.requests[0]
        self.assertIn(":generateContent", req["url"]); self.assertEqual(req["headers"]["x-goog-api-key"], "gem-key-123456")
        self.assertIn("system_instruction", req["json"])
        self.assertEqual([m["role"] for m in self.repo.recent_chat(7)], ["user", "assistant"])

    async def test_falls_back_to_other_provider_and_reports_unavailable(self):
        await self.bank.add("gemini", "gem-key-123456"); await self.bank.add("groq", "groq-key-123456")
        be = FakeBackend([HttpResponse(500), HttpResponse(500), HttpResponse(500),
                          HttpResponse(200, b'{"choices":[{"message":{"content":"hello"}}]}')])
        ai = AIManager(self.repo, self.bank, self.settings, backend=be)
        for c in ai._clients.values():
            c._sleep = no_sleep
        self.assertEqual(await ai.chat(1, "hi"), "hello")
        fresh = tempfile.TemporaryDirectory(); self.addCleanup(fresh.cleanup)
        fresh_repo = make_repo(Path(fresh.name))
        empty = AIManager(fresh_repo, KeyBank(fresh_repo, SecretBox("")), self.settings)
        with self.assertRaises(AIUnavailable):
            await empty.chat(1, "hi")

    async def test_admin_can_switch_provider_and_model(self):
        ai = AIManager(self.repo, self.bank, self.settings, backend=FakeBackend())
        await ai.set_provider("groq"); await ai.set_model("groq", "llama-3.1-8b-instant")
        self.assertEqual((await ai.active_provider(), await ai.model_for("groq")), ("groq", "llama-3.1-8b-instant"))
        with self.assertRaises(ValueError):
            await ai.set_provider("evil")
        with self.assertRaises(ValueError):
            await ai.set_model("groq", "bad model name")


if __name__ == "__main__":
    unittest.main()
