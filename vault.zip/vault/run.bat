@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\activate.bat ( echo Run install.bat first. & pause & exit /b 1 )
call .venv\Scripts\activate.bat
:loop
python bot.py
if errorlevel 2 ( echo Fix the configuration error above and run again. & pause & exit /b 2 )
echo Bot stopped. Restarting in 5 seconds... (close this window to stop)
timeout /t 5 >nul
goto loop
