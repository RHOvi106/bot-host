"""Progress rendering and throttled Telegram message editing."""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Awaitable, Callable

from .metadata_service import human_eta, human_size, human_speed, escape

STAGES = {
    "validating": "🔎 Validating URL",
    "extracting": "📋 Reading media info",
    "queued": "⏳ Waiting in queue",
    "downloading": "⬇️ Downloading",
    "merging": "🧩 Merging streams",
    "converting": "🎛 Converting media",
    "watermark": "🏷 Adding branding",
    "thumbnail": "🖼 Preparing thumbnail",
    "splitting": "✂️ Splitting large file",
    "uploading": "📤 Uploading to Telegram",
    "done": "✅ Completed",
    "failed": "❌ Failed",
    "cancelled": "🛑 Cancelled",
}


def progress_bar(percent: float | None, width: int = 12) -> str:
    if percent is None:
        return "▒" * width
    filled = max(0, min(width, int(round(width * percent / 100))))
    return "█" * filled + "░" * (width - filled)


@dataclass
class ProgressState:
    stage: str = "queued"
    percent: float | None = None
    downloaded: int | None = None
    total: int | None = None
    speed: float | None = None
    eta: float | None = None
    title: str = ""
    note: str = ""
    queue_position: int | None = None


def render_progress(state: ProgressState, *, show_engine: str | None = None) -> str:
    """Only shows numbers the engine really reported (no invented percentages/ETAs)."""
    lines = []
    if state.title:
        lines.append(f"<b>{escape(state.title[:80])}</b>")
    lines.append(STAGES.get(state.stage, escape(state.stage)))
    if state.stage == "queued" and state.queue_position:
        lines.append(f"Position in queue: {state.queue_position}")
    if state.stage == "downloading":
        if state.percent is not None:
            lines.append(f"{progress_bar(state.percent)} {state.percent:.1f}%")
        else:
            lines.append(f"{progress_bar(None)} working…")
        if state.downloaded:
            size = f"{human_size(state.downloaded)}" + (f" / {human_size(state.total)}" if state.total else "")
            lines.append(f"📦 {size}")
        if state.speed:
            lines.append(f"⚡ {human_speed(state.speed)}" + (f" · ⏱ {human_eta(state.eta)}" if state.eta else ""))
    if state.note:
        lines.append(escape(state.note))
    if show_engine:
        lines.append(f"<i>engine: {escape(show_engine)}</i>")
    return "\n".join(lines)


class ProgressReporter:
    """Edits one Telegram message, at most once per `interval` seconds."""

    def __init__(self, edit: Callable[[str], Awaitable[None]], interval: float = 2.5,
                 clock: Callable[[], float] = time.monotonic):
        self._edit, self.interval, self._clock = edit, interval, clock
        self.state = ProgressState()
        self._last_sent = float("-inf")
        self._last_text = ""
        self.edits = 0
        self._blocked_until = 0.0

    async def update(self, force: bool = False, **fields) -> None:
        for k, v in fields.items():
            setattr(self.state, k, v)
        now = self._clock()
        if not force and (now - self._last_sent < self.interval or now < self._blocked_until):
            return
        text = render_progress(self.state)
        if text == self._last_text:
            return
        self._last_sent = now
        try:
            await self._edit(text)
            self._last_text = text
            self.edits += 1
        except Exception as exc:  # noqa: BLE001 - never let a cosmetic edit break a download
            retry = getattr(exc, "retry_after", None)
            if retry:
                self._blocked_until = now + float(getattr(retry, "total_seconds", lambda: retry)())
