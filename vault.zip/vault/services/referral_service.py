"""Referral links and premium rewards (rewarded only after the invited user passes the gate)."""
from __future__ import annotations

import asyncio
from typing import Any


def parse_start_payload(args: list[str] | None) -> int | None:
    if not args:
        return None
    p = args[0]
    if p.startswith("ref_") and p[4:].isdigit():
        return int(p[4:])
    return None


def referral_link(bot_username: str, user_id: int) -> str:
    return f"https://t.me/{bot_username}?start=ref_{user_id}"


class ReferralService:
    def __init__(self, repo: Any, settings: Any):
        self.repo, self.settings = repo, settings

    async def register(self, referred_id: int, referrer_id: int | None) -> bool:
        if not referrer_id or referrer_id == referred_id:
            return False
        if not await asyncio.to_thread(self.repo.get_user, referrer_id):
            return False
        ok = await asyncio.to_thread(self.repo.add_referral, referrer_id, referred_id)
        if ok:
            await asyncio.to_thread(self.repo.set_referred_by, referred_id, referrer_id)
        return ok

    async def confirm(self, referred_id: int) -> tuple[int, bool] | None:
        """Returns (referrer_id, premium_granted) the first time the referred user is confirmed."""
        referrer = await asyncio.to_thread(self.repo.confirm_referral, referred_id)
        if referrer is None:
            return None
        await asyncio.to_thread(self.repo.add_points, referrer, 1)
        count = await asyncio.to_thread(self.repo.confirmed_referrals, referrer)
        threshold = await asyncio.to_thread(self.repo.get_int_setting, "referral.threshold", self.settings.referral_threshold)
        days = await asyncio.to_thread(self.repo.get_int_setting, "referral.days", self.settings.premium_days)
        granted = count > 0 and count % threshold == 0
        if granted:
            await asyncio.to_thread(self.repo.extend_premium, referrer, days)
        return referrer, granted
