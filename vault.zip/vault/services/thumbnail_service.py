"""Thumbnail fetching (validated sources, size-capped) and generation."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from api.base_client import ApiError
from utils.validators import InvalidUrl, validate_url_async
from . import media_service

log = logging.getLogger(__name__)
MAX_THUMB_BYTES = 2 * 1024 * 1024


async def fetch_thumbnail(url: str | None, work_dir: Path, backend: Any) -> Path | None:
    """Download `url` only if it passes SSRF validation and is small; return a <=320px JPEG or None."""
    if not url:
        return None
    try:
        await validate_url_async(url)
    except InvalidUrl as exc:
        log.info("thumbnail URL rejected: %s", exc)
        return None
    work_dir.mkdir(parents=True, exist_ok=True)
    raw = work_dir / "thumb_src"
    try:
        await backend.download(url, raw, headers=None, timeout=20.0, max_bytes=MAX_THUMB_BYTES,
                               on_progress=None, cancel=None)
    except (ApiError, OSError) as exc:
        log.info("thumbnail download failed: %s", exc)
        raw.unlink(missing_ok=True)
        return None
    out = work_dir / "thumb.jpg"
    result = await media_service.shrink_image_to_thumbnail(raw, out)
    raw.unlink(missing_ok=True)
    return result


async def thumbnail_for(video_or_audio: Path, remote_url: str | None, work_dir: Path, backend: Any,
                        kind: str) -> Path | None:
    thumb = await fetch_thumbnail(remote_url, work_dir, backend)
    if thumb is None and kind == "video":
        thumb = await media_service.make_thumbnail(video_or_audio, work_dir / "thumb_gen.jpg")
    return thumb
