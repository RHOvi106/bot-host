"""Bounded async job queue: global + per-user concurrency, de-duplication, cancellation."""
from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

from engines.base import CancelToken

log = logging.getLogger(__name__)


class QueueRejected(Exception):
    def __init__(self, reason: str, message: str):
        super().__init__(message)
        self.reason, self.message = reason, message


@dataclass
class Job:
    user_id: int
    url: str
    kind: str
    quality: str
    payload: dict[str, Any] = field(default_factory=dict)
    job_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    status: str = "queued"          # queued | running | done | failed | cancelled
    cancel: CancelToken = field(default_factory=CancelToken)
    created: float = field(default_factory=time.time)
    engine: str = ""

    @property
    def dedupe_key(self) -> tuple:
        return (self.user_id, self.url, self.kind, self.quality)


Runner = Callable[[Job], Awaitable[None]]


class JobQueue:
    """Swap this class for a persistent implementation later; keep submit/cancel/shutdown."""

    def __init__(self, runner: Runner, *, workers: int = 3, per_user: int = 2, max_size: int = 50):
        self._runner, self._workers_n, self.per_user, self.max_size = runner, workers, per_user, max_size
        self._queue: asyncio.Queue[Job] = asyncio.Queue()
        self._jobs: dict[str, Job] = {}
        self._tasks: list[asyncio.Task] = []
        self._started = False

    async def start(self) -> None:
        if self._started:
            return
        self._started = True
        self._tasks = [asyncio.create_task(self._worker(i), name=f"dl-worker-{i}") for i in range(self._workers_n)]

    def _active(self) -> list[Job]:
        return [j for j in self._jobs.values() if j.status in ("queued", "running")]

    async def submit(self, job: Job) -> Job:
        active = self._active()
        if any(j.dedupe_key == job.dedupe_key for j in active):
            raise QueueRejected("duplicate", "This download is already in progress.")
        if sum(1 for j in active if j.user_id == job.user_id) >= self.per_user:
            raise QueueRejected("user_limit", f"You can run {self.per_user} downloads at the same time. "
                                              f"Please wait for one to finish or cancel it.")
        if sum(1 for j in active if j.status == "queued") >= self.max_size:
            raise QueueRejected("full", "The queue is full right now. Please try again in a minute.")
        self._jobs[job.job_id] = job
        await self._queue.put(job)
        return job

    def position(self, job_id: str) -> int:
        """1-based position among queued jobs; 0 when running/unknown."""
        queued = sorted((j for j in self._jobs.values() if j.status == "queued"), key=lambda j: j.created)
        for i, j in enumerate(queued, 1):
            if j.job_id == job_id:
                return i
        return 0

    def get(self, job_id: str) -> Job | None:
        return self._jobs.get(job_id)

    def cancel(self, job_id: str, by_user: int | None = None, is_admin: bool = False) -> bool:
        job = self._jobs.get(job_id)
        if not job or job.status not in ("queued", "running"):
            return False
        if by_user is not None and not is_admin and job.user_id != by_user:
            return False
        job.cancel.cancel()
        if job.status == "queued":
            job.status = "cancelled"
        return True

    def running(self) -> list[Job]:
        return [j for j in self._jobs.values() if j.status == "running"]

    def snapshot(self) -> dict[str, int]:
        return {"running": len(self.running()),
                "queued": sum(1 for j in self._jobs.values() if j.status == "queued")}

    async def _worker(self, idx: int) -> None:
        while True:
            job = await self._queue.get()
            try:
                if job.status == "cancelled" or job.cancel.cancelled:
                    job.status = "cancelled"
                    continue
                job.status = "running"
                await self._runner(job)
                if job.status == "running":
                    job.status = "done"
            except asyncio.CancelledError:
                job.status = "cancelled"
                raise
            except Exception:  # noqa: BLE001 - the worker must survive any job failure
                log.exception("Job %s crashed", job.job_id)
                job.status = "failed"
            finally:
                self._queue.task_done()
                self._gc()

    def _gc(self, keep: int = 200) -> None:
        finished = [j for j in self._jobs.values() if j.status not in ("queued", "running")]
        if len(finished) > keep:
            for j in sorted(finished, key=lambda j: j.created)[: len(finished) - keep]:
                self._jobs.pop(j.job_id, None)

    async def shutdown(self) -> None:
        for job in self._jobs.values():
            if job.status in ("queued", "running"):
                job.cancel.cancel()
        for t in self._tasks:
            t.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()
        self._started = False
