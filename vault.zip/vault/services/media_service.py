"""FFmpeg/FFprobe helpers: probing, splitting, watermarking, thumbnails, file selection."""
from __future__ import annotations

import asyncio
import json
import logging
import shutil
from pathlib import Path

from engines.base import CancelToken, EngineError, ErrorCategory
from utils.proc import run_process

log = logging.getLogger(__name__)

VIDEO_EXT = {".mp4", ".mkv", ".webm", ".mov", ".avi", ".flv", ".m4v", ".ts"}
AUDIO_EXT = {".mp3", ".m4a", ".opus", ".ogg", ".aac", ".wav", ".flac", ".webm_audio"}
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif"}
_JUNK_EXT = {".part", ".ytdl", ".json", ".txt", ".temp", ".tmp", ".vtt", ".srt", ".description"}


def ffmpeg_available() -> bool:
    return bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


async def tool_version(tool: str) -> str:
    exe = shutil.which(tool)
    if not exe:
        return "not installed"
    try:
        rc, out, _ = await run_process([exe, "-version"], timeout=10)
        return out.splitlines()[0] if out else "unknown"
    except Exception:  # noqa: BLE001
        return "unknown"


def media_kind(path: Path, requested: str = "video") -> str:
    ext = path.suffix.lower()
    if ext in IMAGE_EXT:
        return "image"
    if requested == "audio" or ext in AUDIO_EXT - {".webm_audio"}:
        return "audio"
    return "video"


def pick_output_file(directory: Path, prefer: str = "video") -> Path | None:
    """Largest real media file in a job directory (ignores partials and sidecars)."""
    files = [p for p in Path(directory).rglob("*")
             if p.is_file() and p.suffix.lower() not in _JUNK_EXT
             and not p.name.endswith((".part", ".ytdl"))]
    non_images = [p for p in files if p.suffix.lower() not in IMAGE_EXT]
    if prefer in ("video", "audio") and non_images:
        files = non_images          # drop leftover thumbnails
    return max(files, key=lambda p: p.stat().st_size) if files else None


async def probe(path: Path, timeout: float = 30) -> dict:
    """ffprobe summary: duration, width, height, has_video, has_audio. {} if unavailable."""
    exe = shutil.which("ffprobe")
    if not exe:
        return {}
    try:
        rc, out, _ = await run_process(
            [exe, "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)],
            timeout=timeout)
        if rc != 0:
            return {}
        data = json.loads(out)
    except (EngineError, json.JSONDecodeError, OSError):
        return {}
    streams = data.get("streams", [])
    v = next((s for s in streams if s.get("codec_type") == "video"), None)
    a = next((s for s in streams if s.get("codec_type") == "audio"), None)
    try:
        duration = float(data.get("format", {}).get("duration"))
    except (TypeError, ValueError):
        duration = None
    return {"duration": duration, "width": v.get("width") if v else None,
            "height": v.get("height") if v else None, "has_video": v is not None,
            "has_audio": a is not None}


def _escape_drawtext(s: str) -> str:
    return (s.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\u2019")
             .replace("%", "\\%").replace(",", "\\,"))


def build_watermark_args(src: Path, dst: Path, *, text: str = "", image: str = "",
                         font: str = "") -> list[str]:
    """Return an ffmpeg argv that stamps an image or text watermark (bottom-right)."""
    exe = shutil.which("ffmpeg") or "ffmpeg"
    base = [exe, "-y", "-hide_banner", "-loglevel", "error", "-i", str(src)]
    tail = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-c:a", "copy",
            "-movflags", "+faststart", str(dst)]
    if image and Path(image).is_file():
        return (base + ["-i", image, "-filter_complex",
                        "[1:v][0:v]scale2ref=w=iw*0.15:h=ow/mdar[wm][bg];[bg][wm]overlay=W-w-16:H-h-16",
                        ] + tail)
    if text:
        fontpart = ""
        if font:
            fontpart = f":fontfile='{_escape_drawtext(font.replace(chr(92), '/'))}'"
        flt = (f"drawtext=text='{_escape_drawtext(text)}'{fontpart}:fontcolor=white@0.8:fontsize=h/24:"
               f"box=1:boxcolor=black@0.35:boxborderw=6:x=w-tw-16:y=h-th-16")
        return base + ["-vf", flt] + tail
    raise ValueError("no watermark text or image configured")


async def apply_watermark(src: Path, *, text: str, image: str, font: str,
                          cancel: CancelToken | None = None, timeout: float = 1800) -> Path:
    """Re-encode `src` with a watermark. Returns the new path (original is removed)."""
    if not ffmpeg_available():
        raise EngineError(ErrorCategory.FFMPEG_MISSING, "ffmpeg is not installed")
    dst = src.with_name(src.stem + ".wm.mp4")
    args = build_watermark_args(src, dst, text=text, image=image, font=font)
    rc, _, err = await run_process(args, timeout=timeout, cancel=cancel, engine="ffmpeg")
    if rc != 0 or not dst.exists():
        dst.unlink(missing_ok=True)
        raise EngineError(ErrorCategory.FFMPEG_MISSING, f"watermark failed: {err[-200:]}", "ffmpeg")
    src.unlink(missing_ok=True)
    return dst


async def make_thumbnail(video: Path, dst: Path, at_seconds: float = 1.0) -> Path | None:
    """Create a Telegram-compatible JPEG thumbnail (<=320px) from a video frame."""
    exe = shutil.which("ffmpeg")
    if not exe:
        return None
    try:
        rc, _, _ = await run_process(
            [exe, "-y", "-hide_banner", "-loglevel", "error", "-ss", str(at_seconds), "-i", str(video),
             "-frames:v", "1", "-vf", "scale='min(320,iw)':-2", "-q:v", "5", str(dst)], timeout=60)
    except EngineError:
        return None
    return dst if rc == 0 and dst.exists() and dst.stat().st_size > 0 else None


async def shrink_image_to_thumbnail(src: Path, dst: Path) -> Path | None:
    """Convert any image to <=320px JPEG for Telegram thumbnails."""
    exe = shutil.which("ffmpeg")
    if not exe:
        return None
    try:
        rc, _, _ = await run_process(
            [exe, "-y", "-hide_banner", "-loglevel", "error", "-i", str(src), "-frames:v", "1",
             "-vf", "scale='min(320,iw)':-2", "-q:v", "5", str(dst)], timeout=30)
    except EngineError:
        return None
    ok = rc == 0 and dst.exists() and 0 < dst.stat().st_size <= 200 * 1024
    return dst if ok else None


def split_bytes(path: Path, max_bytes: int, out_dir: Path, max_parts: int) -> list[Path]:
    """Raw binary split (`name.ext.001`, `.002` ...). Reassemble with `copy /b` or `cat`."""
    size = path.stat().st_size
    parts_needed = -(-size // max_bytes)
    if parts_needed > max_parts:
        raise EngineError(ErrorCategory.TOO_LARGE,
                          f"file would need {parts_needed} parts (limit {max_parts})")
    out_dir.mkdir(parents=True, exist_ok=True)
    parts: list[Path] = []
    with open(path, "rb") as src:
        for i in range(1, parts_needed + 1):
            part = out_dir / f"{path.name}.{i:03d}"
            remaining = max_bytes
            with open(part, "wb") as dst:
                while remaining > 0:
                    chunk = src.read(min(8 * 1024 * 1024, remaining))
                    if not chunk:
                        break
                    dst.write(chunk)
                    remaining -= len(chunk)
            parts.append(part)
    return parts


async def split_video(path: Path, max_bytes: int, out_dir: Path, max_parts: int,
                      cancel: CancelToken | None = None) -> list[Path]:
    """Split a playable video into <= max_bytes pieces using stream copy (no re-encode).
    Cut points land on keyframes, so we iterate with a smaller segment time until every
    part fits. Falls back to a raw binary split when ffmpeg cannot do it."""
    info = await probe(path)
    duration = info.get("duration")
    exe = shutil.which("ffmpeg")
    size = path.stat().st_size
    if not exe or not duration or not info.get("has_video"):
        return split_bytes(path, max_bytes, out_dir, max_parts)
    out_dir.mkdir(parents=True, exist_ok=True)
    factor = 0.85
    for _ in range(4):
        seg = max(2.0, duration * (max_bytes / size) * factor)
        for old in out_dir.glob(f"{path.stem}.part*{path.suffix}"):
            old.unlink(missing_ok=True)
        pattern = out_dir / f"{path.stem}.part%03d{path.suffix}"
        rc, _, _ = await run_process(
            [exe, "-y", "-hide_banner", "-loglevel", "error", "-i", str(path), "-map", "0", "-c", "copy",
             "-f", "segment", "-segment_time", f"{seg:.2f}", "-reset_timestamps", "1", str(pattern)],
            timeout=1800, cancel=cancel, engine="ffmpeg")
        parts = sorted(out_dir.glob(f"{path.stem}.part*{path.suffix}"))
        if rc == 0 and parts and all(p.stat().st_size <= max_bytes for p in parts):
            if len(parts) > max_parts:
                raise EngineError(ErrorCategory.TOO_LARGE, f"would need {len(parts)} parts (limit {max_parts})")
            return parts
        factor *= 0.6
    for p in out_dir.glob(f"{path.stem}.part*{path.suffix}"):
        p.unlink(missing_ok=True)
    return split_bytes(path, max_bytes, out_dir, max_parts)
