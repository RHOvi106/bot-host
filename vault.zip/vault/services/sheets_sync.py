"""Optional Google Sheets sync (service account). Disabled unless configured; needs `gspread`."""
from __future__ import annotations

import asyncio
import importlib.util
import logging
import time
from typing import Any

log = logging.getLogger(__name__)


def _fmt(ts: Any) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(ts)) if isinstance(ts, (int, float)) and ts else ""


def build_tables(repo: Any) -> dict[str, list[list[Any]]]:
    stats = repo.global_stats()
    summary = [["Metric", "Value"], *[[k, v] for k, v in stats.items()], ["synced_at_utc", _fmt(time.time())]]
    users = [["user_id", "username", "name", "joined", "last_seen", "blocked", "premium_until", "points"]]
    for u in repo.export_users(5000):
        users.append([u["user_id"], u["username"] or "", u["first_name"] or "", _fmt(u["joined_at"]),
                      _fmt(u["last_seen"]), u["is_blocked"], _fmt(u["premium_until"]), u["points"]])
    dls = [["job_id", "user_id", "platform", "title", "kind", "quality", "ext", "size", "engine", "status", "error", "created", "seconds"]]
    for d in repo.export_downloads(2000):
        dls.append([d["job_id"], d["user_id"], d["platform"] or "", (d["title"] or "")[:80], d["kind"] or "",
                    d["quality"] or "", d["ext"] or "", d["file_size"] or 0, d["engine"] or "", d["status"],
                    d["error_category"] or "", _fmt(d["created_at"]), round(d["processing_seconds"] or 0, 1)])
    errs = [["time", "user_id", "category", "message"]]
    for e in repo.recent_errors(500):
        errs.append([_fmt(e["ts"]), e["user_id"] or "", e["category"] or "", (e["message"] or "")[:200]])
    return {"Summary": summary, "Users": users, "Downloads": dls, "Errors": errs}


class SheetsSync:
    def __init__(self, settings: Any, repo: Any):
        self.s, self.repo = settings, repo

    @property
    def configured(self) -> bool:
        return bool(self.s.google_sheets_id and self.s.google_service_account_file)

    def available(self) -> bool:
        return self.configured and importlib.util.find_spec("gspread") is not None

    def _sync(self) -> int:
        import gspread  # type: ignore
        gc = gspread.service_account(filename=self.s.google_service_account_file)
        sh = gc.open_by_key(self.s.google_sheets_id)
        tables = build_tables(self.repo)
        for title, rows in tables.items():
            try:
                ws = sh.worksheet(title)
            except gspread.WorksheetNotFound:
                ws = sh.add_worksheet(title=title, rows=max(len(rows) + 10, 100), cols=max(len(rows[0]), 8))
            ws.clear()
            ws.update(values=rows, range_name="A1")
        return sum(len(r) - 1 for r in tables.values())

    async def sync_now(self) -> str:
        if not self.configured:
            return "Google Sheets is not configured (set GOOGLE_SHEETS_ID and GOOGLE_SERVICE_ACCOUNT_FILE)."
        if not self.available():
            return "The 'gspread' package is not installed (pip install gspread)."
        try:
            n = await asyncio.to_thread(self._sync)
            return f"Synced {n} rows to Google Sheets."
        except Exception as exc:  # noqa: BLE001
            log.exception("sheets sync failed")
            return f"Sync failed: {type(exc).__name__}"
