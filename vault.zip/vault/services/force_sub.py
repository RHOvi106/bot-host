"""Force-subscribe checks (channels managed by the admin; membership cached briefly)."""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from utils.tg_compat import BadRequest, Forbidden, TelegramError

log = logging.getLogger(__name__)
_OK_STATUSES = {"member", "administrator", "creator", "owner"}


def channel_url(chat_ref: str, url: str = "") -> str:
    if url:
        return url
    return f"https://t.me/{chat_ref.lstrip('@')}" if chat_ref.startswith("@") else ""


class ForceSubService:
    def __init__(self, repo: Any, settings: Any, ttl: float = 60.0):
        self.repo, self.settings, self.ttl = repo, settings, ttl
        self._cache: dict[tuple[int, str], tuple[float, bool]] = {}
        self._warned: set[str] = set()

    async def seed(self) -> None:
        for ref in self.settings.force_sub_channels:
            ref = ref if ref.startswith(("@", "-")) else f"@{ref}"
            await asyncio.to_thread(self.repo.add_channel, ref, "", channel_url(ref))

    async def channels(self) -> list[dict]:
        return await asyncio.to_thread(self.repo.list_channels, True)

    async def missing(self, bot: Any, user_id: int, *, use_cache: bool = True) -> list[dict]:
        """Channels the user has NOT joined. Misconfiguration fails OPEN (never locks everyone out)."""
        missing = []
        for ch in await self.channels():
            ref = ch["chat_ref"]
            key = (user_id, ref)
            hit = self._cache.get(key)
            if use_cache and hit and time.monotonic() - hit[0] < self.ttl and hit[1]:
                continue
            try:
                chat_id = int(ref) if ref.lstrip("-").isdigit() else ref
                member = await bot.get_chat_member(chat_id, user_id)
                joined = getattr(member, "status", "") in _OK_STATUSES or bool(getattr(member, "is_member", False))
            except (BadRequest, Forbidden, TelegramError) as exc:
                if ref not in self._warned:
                    self._warned.add(ref)
                    log.warning("Force-sub check for %s failed (%s). Is the bot an admin of that channel? "
                                "Skipping this channel.", ref, exc)
                continue
            self._cache[key] = (time.monotonic(), joined)
            if not joined:
                missing.append(ch)
        return missing
