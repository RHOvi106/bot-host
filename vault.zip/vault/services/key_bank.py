"""API key bank: several keys per service, automatic rotation and cooldown on failure."""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Awaitable, Callable, TypeVar

from api.base_client import ApiError
from utils.secrets_box import SecretBox, fingerprint

log = logging.getLogger(__name__)
T = TypeVar("T")

COOLDOWN_RATE_LIMIT = 3600      # hourly quotas (e.g. Unsplash demo: 50/hour)
COOLDOWN_AUTH = 24 * 3600
COOLDOWN_TRANSIENT = 60


class NoKeyAvailable(Exception):
    def __init__(self, service: str, configured: bool):
        super().__init__(f"no usable API key for {service}")
        self.service, self.configured = service, configured


class KeyBank:
    def __init__(self, repo: Any, box: SecretBox):
        self.repo, self.box = repo, box

    async def add(self, service: str, key: str, label: str | None = None) -> bool:
        key = key.strip()
        if not key:
            return False
        rid = await asyncio.to_thread(self.repo.add_api_key, service, self.box.encrypt(key), fingerprint(key), label)
        return rid is not None

    async def seed(self, seed_keys: dict[str, tuple[str, ...]]) -> int:
        added = 0
        for service, keys in seed_keys.items():
            for k in keys:
                if await self.add(service, k, "env"):
                    added += 1
        return added

    async def count(self, service: str) -> int:
        rows = await asyncio.to_thread(self.repo.list_api_keys, service)
        return sum(1 for r in rows if r["enabled"])

    async def has_keys(self, service: str) -> bool:
        return await self.count(service) > 0

    async def with_key(self, service: str, fn: Callable[[str], Awaitable[T]]) -> T:
        """Call fn(key) with rotating keys. Rate-limit/auth errors cool the key down and try the next."""
        tried: set[int] = set()
        last_error: ApiError | None = None
        configured = False
        while True:
            rows = await asyncio.to_thread(self.repo.available_api_keys, service)
            rows = [r for r in rows if r["id"] not in tried]
            if not rows:
                if last_error is not None:
                    raise last_error
                total = await asyncio.to_thread(self.repo.list_api_keys, service)
                configured = bool(total)
                raise NoKeyAvailable(service, configured)
            row = rows[0]
            tried.add(row["id"])
            try:
                key = self.box.decrypt(row["key_enc"])
            except Exception:  # noqa: BLE001
                await asyncio.to_thread(self.repo.mark_key_cooldown, row["id"], COOLDOWN_AUTH, "cannot decrypt")
                continue
            try:
                result = await fn(key)
            except ApiError as exc:
                last_error = exc
                if exc.kind == "rate_limit":
                    cool = max(exc.retry_after or 0, 60) if exc.retry_after else COOLDOWN_RATE_LIMIT
                elif exc.kind == "auth":
                    cool = COOLDOWN_AUTH
                elif exc.kind in {"network", "timeout", "server"}:
                    cool = COOLDOWN_TRANSIENT
                else:
                    raise                     # invalid request: another key will not help
                await asyncio.to_thread(self.repo.mark_key_cooldown, row["id"], cool, f"{exc.kind}")
                log.warning("API key #%s for %s cooled down (%s)", row["id"], service, exc.kind)
                continue
            await asyncio.to_thread(self.repo.mark_key_used, row["id"])
            return result
