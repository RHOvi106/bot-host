"""End-to-end download pipeline: validate -> download -> process -> split -> upload -> record."""
from __future__ import annotations

import asyncio
import hashlib
import logging
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable, Protocol

from engines.base import CancelToken, DownloadRequest, EngineError, ErrorCategory, MediaInfo, ProgressEvent
from utils import cleanup
from utils.filenames import safe_filename
from utils.messages import friendly
from . import media_service, thumbnail_service
from .fallback_service import AllEnginesFailed, FallbackService
from .metadata_service import build_caption
from .queue_service import Job
from .progress_service import ProgressReporter
from .upload_service import UploadedFile

log = logging.getLogger(__name__)


class Uploader(Protocol):
    async def upload(self, path: Path, *, kind: str, caption: str, duration: float | None, width: int | None,
                     height: int | None, thumb: Path | None, title: str | None, performer: str | None) -> UploadedFile: ...
    async def resend(self, file_id: str, method: str, caption: str) -> UploadedFile: ...


@dataclass
class Outcome:
    status: str                       # done | failed | cancelled
    message: str
    category: ErrorCategory | None = None
    files: list[UploadedFile] = field(default_factory=list)


def cache_key(url: str, kind: str, quality: str) -> str:
    return hashlib.sha1(f"{url}|{kind}|{quality}".encode()).hexdigest()


class DownloadService:
    def __init__(self, *, settings: Any, repo: Any, fallback: FallbackService, http_backend: Any,
                 cookies_path: Callable[[], str | None], notify_admin: Callable[[str], Awaitable[None]] | None = None):
        self.settings, self.repo, self.fallback, self.http = settings, repo, fallback, http_backend
        self._cookies, self._notify = cookies_path, notify_admin

    async def run_job(self, job: Job, reporter: ProgressReporter, uploader: Uploader) -> Outcome:
        started = time.monotonic()
        info: MediaInfo = job.payload["info"]
        prefs: dict = job.payload.get("prefs", {})
        job_dir = Path(self.settings.temp_dir) / job.job_id
        ckey = cache_key(job.url, job.kind, job.quality)
        loop = asyncio.get_running_loop()
        await self.repo.update_download(job.job_id, status="running")
        try:
            # 1. Same media already uploaded before? Re-send by file_id.
            cached = await self.repo.find_cached_upload(ckey)
            if cached and cached.get("tg_file_kind"):
                await reporter.update(force=True, stage="uploading")
                caption = build_caption(info.title, job.quality, cached.get("ext") or "", info.duration, info.uploader)
                try:
                    up = await uploader.resend(cached["tg_file_id"], cached["tg_file_kind"], caption)
                    await self._finish(job, started, ckey, [up], cached.get("engine") or "cache", cached.get("ext"),
                                       cached.get("file_size"))
                    await reporter.update(force=True, stage="done")
                    return Outcome("done", "Sent from cache.", files=[up])
                except Exception:  # noqa: BLE001 - stale file_id: fall through to a real download
                    log.info("cached file_id rejected for %s, downloading again", job.job_id)

            # 2. Disk space & request
            estimate = info.filesize_by_height.get(job.payload.get("height") or 0) or info.audio_filesize or 300 * 1024 * 1024
            cleanup.ensure_free_space(self.settings.temp_dir, min(estimate, self.settings.max_file_size_bytes))
            req = DownloadRequest(
                job_id=job.job_id, url=job.url, kind=job.kind, out_dir=job_dir,
                height=job.payload.get("height"), audio_format=job.payload.get("audio_format", "best"),
                cookies_file=self._cookies(), max_filesize=self.settings.max_file_size_bytes)

            def on_event(ev: ProgressEvent) -> None:
                loop.call_soon_threadsafe(lambda: asyncio.ensure_future(reporter.update(
                    stage=ev.stage, percent=ev.percent, downloaded=ev.downloaded, total=ev.total,
                    speed=ev.speed, eta=ev.eta)))

            await reporter.update(force=True, stage="downloading", percent=None)
            result = await self.fallback.download(req, on_event, job.cancel, preferred=info.engine or None)
            job.engine = result.engine
            path = result.path
            media_kind = media_service.media_kind(path, job.kind)

            # 3. Optional branding
            if (media_kind == "video" and prefs.get("watermark") and (self.settings.watermark_text or self.settings.watermark_image)
                    and media_service.ffmpeg_available()):
                await reporter.update(force=True, stage="watermark")
                try:
                    path = await media_service.apply_watermark(
                        path, text=self.settings.watermark_text, image=self.settings.watermark_image,
                        font=self.settings.watermark_font, cancel=job.cancel)
                except EngineError as exc:
                    if exc.category == ErrorCategory.CANCELLED:
                        raise
                    log.warning("watermark skipped: %s", exc.message)

            # 4. Probe + thumbnail
            meta = await media_service.probe(path) if media_kind in ("video", "audio") else {}
            thumb = None
            if prefs.get("send_thumbnail", True) and media_kind in ("video", "audio"):
                await reporter.update(force=True, stage="thumbnail")
                thumb = await thumbnail_service.thumbnail_for(path, info.thumbnail, job_dir, self.http, media_kind)
            job.cancel.raise_if_cancelled()

            # 5. Split when above the upload limit
            parts = [path]
            size = path.stat().st_size
            if size > self.settings.upload_limit_bytes:
                await reporter.update(force=True, stage="splitting")
                out = job_dir / "parts"
                if media_kind == "video":
                    parts = await media_service.split_video(path, self.settings.upload_limit_bytes, out,
                                                            self.settings.max_split_parts, job.cancel)
                else:
                    parts = await asyncio.to_thread(media_service.split_bytes, path, self.settings.upload_limit_bytes,
                                                    out, self.settings.max_split_parts)

            # 6. Upload every part; only count success after Telegram confirms
            uploaded: list[UploadedFile] = []
            title = result.info.title if result.info else info.title
            for i, part in enumerate(parts, 1):
                job.cancel.raise_if_cancelled()
                await reporter.update(force=True, stage="uploading",
                                      note=f"Part {i}/{len(parts)}" if len(parts) > 1 else "")
                pmeta = meta if len(parts) == 1 else (await media_service.probe(part) if part.suffix.lower() in
                                                      media_service.VIDEO_EXT else {})
                caption = build_caption(title, job.quality, part.suffix, pmeta.get("duration") or info.duration,
                                        info.uploader, (i, len(parts)) if len(parts) > 1 else None)
                if len(parts) > 1 and part.suffix and part.suffix.lstrip(".").isdigit():
                    caption += "\n💾 Join parts: <code>copy /b *.001+*.002 file</code> (Windows) or <code>cat</code> (Linux)"
                up = await uploader.upload(part, kind=media_kind, caption=caption, duration=pmeta.get("duration"),
                                           width=pmeta.get("width"), height=pmeta.get("height"), thumb=thumb,
                                           title=title, performer=info.uploader)
                uploaded.append(up)

            if await self.repo.get_bool_setting("storage.keep_files", False) and len(parts) == 1:
                dest = Path(self.settings.download_dir) / f"{job.job_id}_{safe_filename(path.name)}"
                dest.parent.mkdir(parents=True, exist_ok=True)
                await asyncio.to_thread(shutil.copy2, path, dest)

            await self._finish(job, started, ckey, uploaded, result.engine, path.suffix.lstrip("."), size,
                               title=title, meta=info)
            await reporter.update(force=True, stage="done")
            return Outcome("done", "Done!", files=uploaded)

        except AllEnginesFailed as exc:
            cat = exc.category
            if cat == ErrorCategory.CANCELLED:
                return await self._cancelled(job, reporter)
            await self._fail(job, started, cat, str(exc), reporter)
            if cat == ErrorCategory.DISK_FULL:
                await self._alert(f"⚠️ Disk space problem while processing job {job.job_id}")
            return Outcome("failed", friendly(cat), cat)
        except EngineError as exc:
            if exc.category == ErrorCategory.CANCELLED or job.cancel.cancelled:
                return await self._cancelled(job, reporter)
            await self._fail(job, started, exc.category, exc.message, reporter)
            if exc.category == ErrorCategory.DISK_FULL:
                await self._alert(f"⚠️ Disk space problem while processing job {job.job_id}")
            return Outcome("failed", friendly(exc.category), exc.category)
        except asyncio.CancelledError:
            await asyncio.shield(self.repo.update_download(job.job_id, status="cancelled", finished_at=int(time.time())))
            raise
        except Exception as exc:  # noqa: BLE001 - nothing may escape to the user as a traceback
            log.exception("Job %s failed unexpectedly", job.job_id)
            await self.repo.log_error(job.user_id, "job_crash", f"{type(exc).__name__}: {exc}", job.url)
            await self._fail(job, started, ErrorCategory.UNKNOWN, f"{type(exc).__name__}: {exc}", reporter)
            await self._alert(f"🚨 Job {job.job_id} crashed: {type(exc).__name__}: {str(exc)[:200]}")
            return Outcome("failed", friendly(ErrorCategory.UNKNOWN), ErrorCategory.UNKNOWN)
        finally:
            await asyncio.to_thread(cleanup.remove_dir, job_dir)

    # ---- helpers ----
    async def _finish(self, job: Job, started: float, ckey: str, files: list[UploadedFile], engine: str | None,
                      ext: str | None, size: int | None, title: str | None = None, meta: MediaInfo | None = None):
        fields: dict[str, Any] = dict(status="done", engine=engine, ext=ext, file_size=size, cache_key=ckey,
                                      finished_at=int(time.time()), processing_seconds=time.monotonic() - started)
        if len(files) == 1:
            fields.update(tg_file_id=files[0].file_id, tg_file_kind=files[0].method)
        if title:
            fields["title"] = title
        job.status = "done"
        await self.repo.update_download(job.job_id, **fields)

    async def _fail(self, job: Job, started: float, cat: ErrorCategory, message: str, reporter: ProgressReporter):
        job.status = "failed"
        await self.repo.update_download(job.job_id, status="failed", error_category=cat.value,
                                        error_message=message[:500], finished_at=int(time.time()),
                                        processing_seconds=time.monotonic() - started)
        await self.repo.log_error(job.user_id, cat.value, message[:500], job.url)
        await reporter.update(force=True, stage="failed")

    async def _cancelled(self, job: Job, reporter: ProgressReporter) -> Outcome:
        job.status = "cancelled"
        await self.repo.update_download(job.job_id, status="cancelled", finished_at=int(time.time()))
        await reporter.update(force=True, stage="cancelled")
        return Outcome("cancelled", friendly(ErrorCategory.CANCELLED), ErrorCategory.CANCELLED)

    async def _alert(self, text: str) -> None:
        if self._notify:
            try:
                await self._notify(text)
            except Exception:  # noqa: BLE001
                log.exception("admin alert failed")
