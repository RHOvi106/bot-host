"""Centralised engine selection, bounded retries, timeouts and fallback."""
from __future__ import annotations

import asyncio
import logging
import time
from collections import OrderedDict
from typing import Any, Awaitable, Callable

from engines.base import (CancelToken, DownloadRequest, DownloadResult, EngineError, ErrorCategory, MediaInfo,
                          ProgressCallback)
from engines.registry import EngineRegistry

log = logging.getLogger(__name__)


class AllEnginesFailed(Exception):
    def __init__(self, last: EngineError | None, attempts: list[tuple[str, ErrorCategory]]):
        super().__init__(last.message if last else "no compatible engine")
        self.last = last
        self.attempts = attempts

    @property
    def category(self) -> ErrorCategory:
        return self.last.category if self.last else ErrorCategory.UNSUPPORTED


class InfoCache:
    def __init__(self, ttl: float = 600, size: int = 128, clock: Callable[[], float] = time.monotonic):
        self.ttl, self.size, self._clock = ttl, size, clock
        self._d: OrderedDict[str, tuple[float, MediaInfo]] = OrderedDict()

    def get(self, key: str) -> MediaInfo | None:
        item = self._d.get(key)
        if not item or self._clock() - item[0] > self.ttl:
            self._d.pop(key, None)
            return None
        self._d.move_to_end(key)
        return item[1]

    def put(self, key: str, info: MediaInfo) -> None:
        self._d[key] = (self._clock(), info)
        self._d.move_to_end(key)
        while len(self._d) > self.size:
            self._d.popitem(last=False)


class FallbackService:
    def __init__(self, registry: EngineRegistry, repo: Any | None = None, *, max_retries: int = 2,
                 metadata_timeout: float = 60, engine_timeout: float = 1800, backoff: float = 2.0,
                 sleep: Callable[[float], Awaitable[None]] = asyncio.sleep):
        self.registry, self.repo = registry, repo
        self.max_retries, self.metadata_timeout, self.engine_timeout = max_retries, metadata_timeout, engine_timeout
        self.backoff, self._sleep = backoff, sleep
        self.cache = InfoCache()

    async def _record(self, name: str, ok: bool, err: str | None = None) -> None:
        await asyncio.to_thread(self.registry.record, name, ok, err)

    async def get_info(self, url: str, cookies_file: str | None = None, kind: str = "video") -> MediaInfo:
        cached = self.cache.get(url)
        if cached:
            return cached
        engines = await asyncio.to_thread(self.registry.compatible, url, "video")   # may spawn tools; keep off the loop
        last: EngineError | None = None
        attempts: list[tuple[str, ErrorCategory]] = []
        for engine in engines:
            try:
                info = await asyncio.wait_for(engine.extract_info(url, cookies_file=cookies_file),
                                              self.metadata_timeout)
            except asyncio.TimeoutError:
                last = EngineError(ErrorCategory.TIMEOUT, "metadata timed out", engine.name)
            except EngineError as exc:
                last = exc
                last.engine = last.engine or engine.name
            except Exception as exc:  # noqa: BLE001
                log.exception("Engine %s crashed in extract_info", engine.name)
                last = EngineError(ErrorCategory.UNKNOWN, str(exc)[:200], engine.name)
            else:
                info.engine = info.engine or engine.name
                self.cache.put(url, info)
                return info
            attempts.append((engine.name, last.category))
            if not last.category.fallbackable:
                break
        raise AllEnginesFailed(last, attempts)

    async def download(self, req: DownloadRequest, progress: ProgressCallback, cancel: CancelToken,
                       preferred: str | None = None) -> DownloadResult:
        engines = await asyncio.to_thread(self.registry.compatible, req.url, req.kind)
        if preferred:
            engines.sort(key=lambda e: 0 if e.name == preferred else 1)
        if not engines:
            raise AllEnginesFailed(EngineError(ErrorCategory.UNSUPPORTED, "no compatible engine"), [])
        last: EngineError | None = None
        attempts: list[tuple[str, ErrorCategory]] = []
        for engine in engines:
            attempt = 0
            while True:
                cancel.raise_if_cancelled(engine.name)
                token = CancelToken(parent=cancel)
                started = int(time.time())
                timeout = float(engine.settings.get("timeout", self.engine_timeout))
                try:
                    result = await asyncio.wait_for(engine.download(req, progress, token), timeout)
                except asyncio.TimeoutError:
                    token.cancel()          # ask the worker thread / subprocess to stop
                    last = EngineError(ErrorCategory.TIMEOUT, f"timed out after {int(timeout)}s", engine.name)
                except EngineError as exc:
                    last = exc
                    last.engine = last.engine or engine.name
                except asyncio.CancelledError:
                    token.cancel()
                    raise
                except Exception as exc:  # noqa: BLE001
                    log.exception("Engine %s crashed", engine.name)
                    last = EngineError(ErrorCategory.UNKNOWN, str(exc)[:200], engine.name)
                else:
                    await self._attempt(req.job_id, engine.name, started, True)
                    await self._record(engine.name, True)
                    return result
                await self._attempt(req.job_id, engine.name, started, False, last)
                if last.category == ErrorCategory.CANCELLED:
                    raise last
                await self._record(engine.name, False, f"{last.category.value}: {last.message}")
                attempts.append((engine.name, last.category))
                if last.category.retryable and attempt < self.max_retries:
                    attempt += 1
                    await self._sleep(self.backoff * attempt)
                    continue
                break
            if not last.category.fallbackable:
                break
        raise AllEnginesFailed(last, attempts)

    async def _attempt(self, job_id: str, engine: str, started: int, ok: bool, err: EngineError | None = None) -> None:
        if self.repo is None:
            return
        await asyncio.to_thread(self.repo.add_attempt, job_id, engine, started, int(time.time()), ok,
                                err.category.value if err else None, err.message if err else None)
