"""Telegram uploads with retries. Success is only reported after Telegram returns a Message."""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Awaitable, Callable

from utils.tg_compat import BadRequest, NetworkError, RetryAfter, TelegramError, TimedOut, retry_seconds
from .media_service import IMAGE_EXT

log = logging.getLogger(__name__)

TG_VIDEO_EXT = {".mp4", ".m4v", ".mov"}
TG_AUDIO_EXT = {".mp3", ".m4a"}


@dataclass
class UploadedFile:
    file_id: str
    method: str            # video | audio | photo | document
    message_id: int | None = None


def choose_method(path: Path, kind: str, size: int) -> str:
    ext = path.suffix.lower()
    if kind == "image" or ext in IMAGE_EXT:
        return "photo" if ext in {".jpg", ".jpeg", ".png"} and size <= 9 * 1024 * 1024 else "document"
    if kind == "audio":
        return "audio" if ext in TG_AUDIO_EXT else "document"
    return "video" if ext in TG_VIDEO_EXT else "document"


async def send_with_retry(factory: Callable[[], Awaitable[Any]], *, attempts: int = 3,
                          sleep: Callable[[float], Awaitable[None]] = asyncio.sleep) -> Any:
    """Retry flood-waits and transient network errors; re-raise permanent Telegram errors."""
    for i in range(attempts):
        last = i == attempts - 1
        try:
            return await factory()
        except RetryAfter as exc:
            if last:
                raise
            await sleep(min(retry_seconds(exc) + 1, 60))
        except (TimedOut, NetworkError):
            if last:
                raise
            await sleep(2 * (i + 1))


def _file_id(message: Any, method: str) -> str:
    if method == "photo":
        return message.photo[-1].file_id
    return getattr(message, method).file_id


async def upload_file(bot: Any, chat_id: int, path: Path, *, kind: str, caption: str, duration: float | None = None,
                      width: int | None = None, height: int | None = None, thumb: Path | None = None,
                      title: str | None = None, performer: str | None = None,
                      sleep: Callable[[float], Awaitable[None]] = asyncio.sleep) -> UploadedFile:
    size = path.stat().st_size
    method = choose_method(path, kind, size)
    timeouts = dict(read_timeout=180, write_timeout=900, connect_timeout=30, pool_timeout=30)

    async def attempt(cap: str | None, parse_mode: str | None):
        with open(path, "rb") as fh:
            thumb_fh = open(thumb, "rb") if thumb and thumb.exists() and method in ("video", "audio", "document") else None
            try:
                common = dict(chat_id=chat_id, caption=cap, parse_mode=parse_mode, **timeouts)
                if method == "video":
                    return await bot.send_video(video=fh, duration=int(duration) if duration else None, width=width,
                                                height=height, thumbnail=thumb_fh, supports_streaming=True,
                                                filename=path.name, **common)
                if method == "audio":
                    return await bot.send_audio(audio=fh, duration=int(duration) if duration else None, title=title,
                                                performer=performer, thumbnail=thumb_fh, filename=path.name, **common)
                if method == "photo":
                    return await bot.send_photo(photo=fh, **common)
                return await bot.send_document(document=fh, thumbnail=thumb_fh, filename=path.name, **common)
            finally:
                if thumb_fh:
                    thumb_fh.close()

    try:
        msg = await send_with_retry(lambda: attempt(caption, "HTML"), sleep=sleep)
    except BadRequest as exc:
        if "parse" in str(exc).lower() or "entities" in str(exc).lower():
            msg = await send_with_retry(lambda: attempt(None, None), sleep=sleep)   # caption markup rejected
        else:
            raise
    return UploadedFile(_file_id(msg, method), method, getattr(msg, "message_id", None))


async def resend_cached(bot: Any, chat_id: int, file_id: str, method: str, caption: str) -> UploadedFile:
    """Re-send an earlier upload by Telegram file_id (instant, no re-download)."""
    send = {"video": bot.send_video, "audio": bot.send_audio, "photo": bot.send_photo,
            "document": bot.send_document}[method]
    arg = {"video": "video", "audio": "audio", "photo": "photo", "document": "document"}[method]
    msg = await send_with_retry(lambda: send(chat_id=chat_id, caption=caption, parse_mode="HTML", **{arg: file_id}))
    return UploadedFile(_file_id(msg, method), method, getattr(msg, "message_id", None))
