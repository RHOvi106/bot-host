"""Background forwarding of user activity to the owner's log chat (optional).

Messages are grouped per user: with ACTIVITY_USE_TOPICS=true and a forum-enabled supergroup each user
gets their own topic; otherwise every line carries a #U<id> hashtag so it can be searched/filtered.
"""
from __future__ import annotations

import asyncio
import html
import logging
from typing import Any

from api.base_client import ApiClient, ApiError, HttpBackend

log = logging.getLogger(__name__)


def format_line(user: dict, event: str, detail: str) -> str:
    name = html.escape(user.get("first_name") or "user")
    uname = f"@{html.escape(user['username'])}" if user.get("username") else "no username"
    d = html.escape((detail or "")[:600])
    return f"#U{user['user_id']} 👤 {name} ({uname}) <code>{user['user_id']}</code>\n<b>{html.escape(event)}</b>" + (f"\n{d}" if d else "")


class ActivityForwarder:
    def __init__(self, settings: Any, repo: Any, backend: HttpBackend | None = None):
        self.s, self.repo = settings, repo
        self.enabled = bool(settings.activity_bot_token and settings.activity_chat_id)
        self._q: asyncio.Queue = asyncio.Queue(maxsize=500)
        self._task: asyncio.Task | None = None
        self.client = (ApiClient("activity", f"https://api.telegram.org/bot{settings.activity_bot_token}",
                                 backend=backend, timeout=15, min_interval=0.05) if self.enabled else None)

    async def start(self) -> None:
        if self.enabled and self._task is None:
            self._task = asyncio.create_task(self._worker(), name="activity-forwarder")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
            self._task = None

    async def record(self, user: dict, event: str, detail: str = "") -> None:
        """Never blocks or raises: logging activity must not slow users down."""
        try:
            await asyncio.to_thread(self.repo.log_activity, user["user_id"], event, detail)
            if self.enabled and not await asyncio.to_thread(self.repo.get_bool_setting, "activity.paused", False):
                self._q.put_nowait((user, event, detail))
        except asyncio.QueueFull:
            log.debug("activity queue full; dropping event")
        except Exception:  # noqa: BLE001
            log.exception("activity record failed")

    async def _topic_for(self, user: dict) -> int | None:
        if not self.s.activity_use_topics:
            return None
        existing = await asyncio.to_thread(self.repo.get_topic, user["user_id"])
        if existing:
            return existing
        try:
            res = await self.client.request("POST", "/createForumTopic", json_body={
                "chat_id": self.s.activity_chat_id,
                "name": f"{user.get('first_name') or 'user'} · {user['user_id']}"[:128]})
            thread = res["result"]["message_thread_id"]
            await asyncio.to_thread(self.repo.set_topic, user["user_id"], thread)
            return thread
        except (ApiError, KeyError, TypeError):
            log.warning("could not create forum topic; falling back to hashtags")
            return None

    async def _worker(self) -> None:
        while True:
            user, event, detail = await self._q.get()
            try:
                body: dict = {"chat_id": self.s.activity_chat_id, "text": format_line(user, event, detail),
                              "parse_mode": "HTML", "disable_notification": True}
                thread = await self._topic_for(user)
                if thread:
                    body["message_thread_id"] = thread
                await self.client.request("POST", "/sendMessage", json_body=body)
            except ApiError as exc:
                if exc.kind == "rate_limit":
                    await asyncio.sleep(exc.retry_after or 5)
                log.warning("activity forward failed: %s", exc)
            except Exception:  # noqa: BLE001
                log.exception("activity worker error")
