"""Metadata normalisation, human-readable formatting and safe captions."""
from __future__ import annotations

import html
import re
from typing import Any

from engines.base import FormatOption, MediaInfo
from utils.validators import platform_of

STANDARD_HEIGHTS = (2160, 1440, 1080, 720, 480, 360, 240, 144)
AUDIO_FORMATS = ("best", "m4a", "mp3", "opus")


def human_size(n: float | int | None) -> str:
    if not n or n < 0:
        return "unknown"
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return "unknown"


def human_duration(seconds: float | int | None) -> str:
    if not seconds or seconds < 0:
        return "unknown"
    s = int(seconds)
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    return f"{h}:{m:02d}:{sec:02d}" if h else f"{m}:{sec:02d}"


def human_speed(bps: float | None) -> str:
    return f"{human_size(bps)}/s" if bps else "—"


def human_eta(seconds: float | None) -> str:
    return human_duration(seconds) if seconds else "—"


def escape(text: Any) -> str:
    """Escape for Telegram HTML parse mode."""
    return html.escape(str(text if text is not None else ""), quote=False)


def clip(text: str, n: int) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    return text if len(text) <= n else text[: n - 1].rstrip() + "…"


def _num(v: Any) -> float | None:
    return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def from_ytdlp(info: dict, url: str, engine: str = "ytdlp") -> MediaInfo:
    """Convert a yt-dlp info dict. Tolerates missing fields."""
    if info.get("_type") == "playlist":
        entries = [e for e in (info.get("entries") or []) if e]
        if not entries:
            raise ValueError("playlist is empty")
        info = entries[0]
    formats: list[FormatOption] = []
    size_by_height: dict[int, int] = {}
    audio_size = None
    for f in info.get("formats") or []:
        vcodec, acodec = f.get("vcodec"), f.get("acodec")
        size = _num(f.get("filesize")) or _num(f.get("filesize_approx"))
        size = int(size) if size else None
        if vcodec and vcodec != "none":
            h = f.get("height")
            h = int(h) if isinstance(h, (int, float)) else None
            formats.append(FormatOption(str(f.get("format_id")), "video", f.get("ext") or "", h, None, size,
                                        has_audio=bool(acodec and acodec != "none")))
            if h and size:
                size_by_height[h] = max(size_by_height.get(h, 0), size)
        elif acodec and acodec != "none":
            abr = _num(f.get("abr"))
            formats.append(FormatOption(str(f.get("format_id")), "audio", f.get("ext") or "", None, abr, size))
            if size:
                audio_size = max(audio_size or 0, size)
    # Estimated size of video+audio when both are known.
    if audio_size:
        size_by_height = {h: s + audio_size for h, s in size_by_height.items()}
    webpage = info.get("webpage_url") or url
    return MediaInfo(
        url=url, title=info.get("title") or "Untitled", uploader=info.get("uploader") or info.get("channel"),
        duration=_num(info.get("duration")), thumbnail=info.get("thumbnail"),
        description=(info.get("description") or "")[:2000] or None, upload_date=info.get("upload_date"),
        webpage_url=webpage, platform=platform_of(webpage), is_live=bool(info.get("is_live")),
        formats=formats, filesize_by_height=size_by_height, audio_filesize=audio_size,
        engine=engine, media_id=str(info.get("id")) if info.get("id") else None)


def quality_options(info: MediaInfo) -> list[tuple[int | None, str]]:
    """[(height or None for best, label)] containing ONLY qualities that exist."""
    heights = info.heights()
    out: list[tuple[int | None, str]] = []
    if heights:
        out.append((None, "Best Available"))
        chosen = [h for h in STANDARD_HEIGHTS if any(abs(h - x) <= 8 or (h == x) for x in heights)]
        # Include non-standard heights (e.g. 1920x800 -> 800) that match no standard bucket.
        extra = [h for h in heights if not any(abs(h - s) <= 8 for s in STANDARD_HEIGHTS)]
        for h in sorted(set(chosen) | set(extra), reverse=True)[:8]:
            real = next((x for x in heights if abs(h - x) <= 8), h)
            label = {2160: "2160p / 4K", 1440: "1440p"}.get(h, f"{h}p")
            size = info.filesize_by_height.get(real)
            out.append((real, f"{label} · ~{human_size(size)}" if size else label))
    elif not info.formats:
        out.append((None, "Best Available"))     # engine could not list formats
    return out


def build_caption(title: str, quality: str, ext: str, duration: float | None,
                  uploader: str | None = None, part: tuple[int, int] | None = None) -> str:
    """HTML caption (<= 1024 chars). All dynamic parts are escaped."""
    lines = [f"<b>{escape(clip(title, 150))}</b>"]
    if uploader:
        lines.append(f"👤 {escape(clip(uploader, 60))}")
    meta = [quality, ext.upper().lstrip(".")]
    if duration:
        meta.append(human_duration(duration))
    lines.append("🎞 " + " · ".join(escape(m) for m in meta if m))
    if part:
        lines.append(f"📦 Part {part[0]}/{part[1]}")
    return "\n".join(lines)[:1000]
