"""Entry point: wires configuration, database, engines, services and Telegram handlers."""
from __future__ import annotations

import asyncio
import logging
import sys
import time
from pathlib import Path

from config import BASE_DIR, ConfigError, load_settings

try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass


def build_application(settings):
    """Create the PTB Application and all services. Imports are local so `python bot.py --check` is cheap."""
    from telegram import Update
    from telegram.ext import (Application, ApplicationBuilder, CallbackQueryHandler, CommandHandler, MessageHandler,
                              TypeHandler, filters)

    from ai.ai_manager import AIManager
    from api.base_client import HttpxBackend
    from api.providers.cobalt import CobaltProvider
    from api.providers.stock import PixabayProvider, UnsplashProvider
    from api.providers.youtube import YouTubeSearch
    from database import AsyncProxy, Database, Repository, migrate
    from engines.cobalt_engine import CobaltEngine
    from engines.gallery_engine import GalleryDlEngine
    from engines.registry import EngineRegistry
    from engines.streamlink_engine import StreamlinkEngine
    from engines.ytdlp_engine import YtDlpEngine
    from handlers import admin, common, download, features, router, start, user
    from services.activity_forwarder import ActivityForwarder
    from services.download_service import DownloadService
    from services.fallback_service import FallbackService
    from services.force_sub import ForceSubService
    from services.key_bank import KeyBank
    from services.queue_service import JobQueue
    from services.referral_service import ReferralService
    from services.sheets_sync import SheetsSync
    from utils import cleanup
    from utils.pending import PendingStore
    from utils.ratelimit import RateLimiter
    from utils.secrets_box import SecretBox

    db = Database(settings.database_path).connect()
    migrate(db)
    sync_repo = Repository(db)
    repo = AsyncProxy(sync_repo)

    http = HttpxBackend()
    box = SecretBox(settings.secret_key)
    bank = KeyBank(sync_repo, box)

    registry = EngineRegistry(sync_repo)
    registry.register(YtDlpEngine({"timeout": settings.engine_timeout_s}))
    cobalt = CobaltProvider(settings.cobalt_api_url, settings.cobalt_api_key)
    registry.register(CobaltEngine(cobalt, {"timeout": settings.engine_timeout_s}))
    registry.register(StreamlinkEngine({"max_seconds": settings.streamlink_max_seconds}))
    registry.register(GalleryDlEngine({"timeout": settings.engine_timeout_s}))

    cookies_file = settings.database_path.parent / "cookies.txt"
    cookies_path = lambda: str(cookies_file) if cookies_file.is_file() else None  # noqa: E731

    fallback = FallbackService(registry, sync_repo, max_retries=settings.max_retries,
                               metadata_timeout=settings.metadata_timeout_s, engine_timeout=settings.engine_timeout_s)

    builder = ApplicationBuilder().token(settings.bot_token).concurrent_updates(True)
    if settings.local_bot_api_url:
        builder = (builder.base_url(f"{settings.local_bot_api_url}/bot").base_file_url(f"{settings.local_bot_api_url}/file/bot")
                   .local_mode(True))
    app = builder.build()

    async def notify(text: str) -> None:
        await common.notify_admins(app, text)

    dl_service = DownloadService(settings=settings, repo=repo, fallback=fallback, http_backend=http,
                                 cookies_path=cookies_path, notify_admin=notify)
    queue = JobQueue(download.make_runner(app), workers=settings.max_concurrent_downloads,
                     per_user=settings.per_user_concurrency, max_size=settings.max_queue_size)

    bd = app.bot_data
    bd.update(
        settings=settings, repo=repo, sync_repo=sync_repo, db=db, registry=registry, fallback=fallback,
        download_service=dl_service, queue=queue, key_bank=bank, http=http, pending=PendingStore(),
        rate_limiter=RateLimiter(settings.rate_limit_per_minute), ai_limiter=RateLimiter(8, 60),
        admin_limiter=RateLimiter(40, 60), cookies_file=cookies_file, cookies_path=cookies_path,
        force_sub=ForceSubService(sync_repo, settings), referrals=ReferralService(sync_repo, settings),
        activity=ActivityForwarder(settings, sync_repo), sheets=SheetsSync(settings, sync_repo),
        ai=AIManager(sync_repo, bank, settings), unsplash=UnsplashProvider(bank), pixabay=PixabayProvider(bank),
        youtube=YouTubeSearch(bank, cookies_getter=cookies_path), started_at=time.time(),
    )

    async def post_init(application) -> None:
        d = application.bot_data
        abandoned = await asyncio.to_thread(sync_repo.mark_abandoned)
        removed = await asyncio.to_thread(cleanup.clear_directory, settings.temp_dir)   # leftovers of a previous run
        if abandoned or removed:
            logging.getLogger("bot").info("startup cleanup: %s abandoned jobs, %s temp items", abandoned, removed)
        added = await bank.seed(settings.seed_keys)
        if added:
            logging.getLogger("bot").info("seeded %s API key(s) from environment", added)
        await d["force_sub"].seed()
        await admin.apply_runtime(application)
        await queue.start()
        await d["activity"].start()
        application.job_queue.run_repeating(_sweep, interval=3600, first=600)
        if settings.google_sheets_id:
            application.job_queue.run_repeating(_sheets_job, interval=settings.sheets_sync_minutes * 60, first=120)
        me = await application.bot.get_me()
        logging.getLogger("bot").info("Started as @%s | engines: %s", me.username,
                                      ", ".join(f"{e['name']}={'on' if e['available'] and e['enabled'] else 'off'}"
                                                for e in registry.describe()))

    async def _sweep(context) -> None:
        n = await asyncio.to_thread(cleanup.sweep_old, settings.temp_dir, settings.cleanup_hours)
        if n:
            logging.getLogger("bot").info("swept %s stale temp item(s)", n)

    async def _sheets_job(context) -> None:
        await bd["sheets"].sync_now()

    async def post_shutdown(application) -> None:
        await queue.shutdown()
        await bd["activity"].stop()
        await http.aclose()
        db.close()

    app.post_init, app.post_shutdown = post_init, post_shutdown

    app.add_handler(TypeHandler(Update, start.gate), group=-1)
    app.add_handler(CommandHandler("start", start.start))
    app.add_handler(CommandHandler("help", start.help_cmd))
    app.add_handler(CommandHandler("privacy", start.privacy))
    app.add_handler(CommandHandler("cancel", start.cancel_mode))
    app.add_handler(CommandHandler("admin", admin.admin_cmd))
    app.add_handler(CallbackQueryHandler(admin.on_admin_callback, pattern=r"^adm:"))
    app.add_handler(CallbackQueryHandler(download.on_download_callback, pattern=r"^dl:"))
    app.add_handler(CallbackQueryHandler(download.on_cancel_callback, pattern=r"^cx:"))
    app.add_handler(CallbackQueryHandler(user.on_settings_callback, pattern=r"^set:"))
    app.add_handler(CallbackQueryHandler(features.on_ai_callback, pattern=r"^ai:"))
    app.add_handler(CallbackQueryHandler(features.on_youtube_callback, pattern=r"^yt:"))
    app.add_handler(CallbackQueryHandler(features.on_stock_source, pattern=r"^st:"))
    app.add_handler(CallbackQueryHandler(features.on_stock_download, pattern=r"^sk:"))
    app.add_handler(MessageHandler(filters.Document.ALL, admin.on_document))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, router.on_text))
    app.add_error_handler(common.error_handler)
    return app


def main() -> int:
    try:
        settings = load_settings()
    except ConfigError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2
    settings.ensure_dirs()
    from utils.logging_setup import setup_logging
    flt = setup_logging(settings.log_dir, settings.log_level,
                        [settings.bot_token, settings.activity_bot_token, settings.cobalt_api_key, settings.secret_key]
                        + [k for keys in settings.seed_keys.values() for k in keys])
    log = logging.getLogger("bot")
    if "--check" in sys.argv:
        print("Configuration OK")
        return 0
    app = build_application(settings)
    log.info("Starting %s …", settings.bot_name)
    app.run_polling(allowed_updates=["message", "callback_query"], drop_pending_updates=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
