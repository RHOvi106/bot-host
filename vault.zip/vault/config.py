"""Configuration loading and validation.

All secrets come from environment variables (.env). Nothing secret is hardcoded.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Mapping

BASE_DIR = Path(__file__).resolve().parent

# Cloud Bot API: bots can upload ~50 MB. Local Bot API server: up to 2000 MB.
CLOUD_UPLOAD_LIMIT_MB = 49
LOCAL_UPLOAD_LIMIT_MB = 1990

TOKEN_RE = re.compile(r"^\d{5,}:[A-Za-z0-9_-]{30,}$")


class ConfigError(ValueError):
    """Raised when the configuration is missing or invalid."""


def _clean(value: str | None) -> str:
    return (value or "").strip().strip('"').strip("'").rstrip("\\").strip()


def _int(env: Mapping[str, str], name: str, default: int, minimum: int | None = None) -> int:
    raw = _clean(env.get(name))
    if raw == "":
        return default
    try:
        value = int(raw)
    except ValueError:
        raise ConfigError(f"{name} must be an integer, got {raw!r}") from None
    if minimum is not None and value < minimum:
        raise ConfigError(f"{name} must be >= {minimum}, got {value}")
    return value


def _bool(env: Mapping[str, str], name: str, default: bool) -> bool:
    raw = _clean(env.get(name)).lower()
    if raw == "":
        return default
    if raw in {"1", "true", "yes", "on"}:
        return True
    if raw in {"0", "false", "no", "off"}:
        return False
    raise ConfigError(f"{name} must be true/false, got {raw!r}")


def _csv(env: Mapping[str, str], name: str) -> list[str]:
    raw = _clean(env.get(name))
    return [p.strip() for p in re.split(r"[,\s]+", raw) if p.strip()]


def parse_admin_ids(raw: str) -> frozenset[int]:
    ids: set[int] = set()
    for part in re.split(r"[,\s]+", _clean(raw)):
        if not part:
            continue
        if not part.isdigit():
            raise ConfigError(f"ADMIN_IDS must contain numeric Telegram IDs, got {part!r}")
        ids.add(int(part))
    return frozenset(ids)


def parse_sqlite_url(url: str, base_dir: Path) -> Path:
    url = _clean(url) or "sqlite:///data/bot.db"
    if not url.startswith("sqlite:///"):
        raise ConfigError("DATABASE_URL must be a sqlite:/// URL (this build is SQLite-only)")
    raw = url[len("sqlite:///"):]
    if not raw:
        raise ConfigError("DATABASE_URL has an empty path")
    path = Path(raw)
    return path if path.is_absolute() else base_dir / path


def _path(env: Mapping[str, str], name: str, default: str, base_dir: Path) -> Path:
    p = Path(_clean(env.get(name)) or default)
    return p if p.is_absolute() else base_dir / p


@dataclass(frozen=True)
class Settings:
    bot_token: str
    admin_ids: frozenset[int]
    database_path: Path
    download_dir: Path
    temp_dir: Path
    log_dir: Path
    log_level: str = "INFO"
    max_file_size_mb: int = 1900
    max_concurrent_downloads: int = 3
    per_user_concurrency: int = 2
    max_queue_size: int = 50
    upload_limit_override_mb: int = 0
    local_bot_api_url: str = ""
    max_split_parts: int = 30
    engine_timeout_s: int = 1800
    metadata_timeout_s: int = 60
    max_retries: int = 2
    cleanup_hours: int = 6
    rate_limit_per_minute: int = 12
    free_daily_downloads: int = 10
    referral_threshold: int = 3
    premium_days: int = 30
    force_sub_channels: tuple[str, ...] = ()
    owner_name: str = "Ovi"
    owner_username: str = "RH_Ovi_106"
    bot_name: str = "Premium Link Downloader"
    activity_bot_token: str = ""
    activity_chat_id: int | None = None
    activity_use_topics: bool = False
    google_sheets_id: str = ""
    google_service_account_file: str = ""
    sheets_sync_minutes: int = 30
    secret_key: str = ""
    cobalt_api_url: str = ""
    cobalt_api_key: str = ""
    streamlink_max_seconds: int = 600
    watermark_text: str = ""
    watermark_image: str = ""
    watermark_font: str = r"C:/Windows/Fonts/arial.ttf"
    seed_keys: Mapping[str, tuple[str, ...]] = field(default_factory=dict)

    @property
    def upload_limit_mb(self) -> int:
        """Largest single file we try to upload, conservative on purpose."""
        ceiling = LOCAL_UPLOAD_LIMIT_MB if self.local_bot_api_url else CLOUD_UPLOAD_LIMIT_MB
        wanted = self.upload_limit_override_mb or ceiling
        return max(1, min(wanted, ceiling, self.max_file_size_mb))

    @property
    def upload_limit_bytes(self) -> int:
        return self.upload_limit_mb * 1024 * 1024

    @property
    def max_file_size_bytes(self) -> int:
        return self.max_file_size_mb * 1024 * 1024

    def is_admin(self, user_id: int | None) -> bool:
        return user_id is not None and user_id in self.admin_ids

    def ensure_dirs(self) -> None:
        for p in (self.download_dir, self.temp_dir, self.log_dir, self.database_path.parent):
            p.mkdir(parents=True, exist_ok=True)


_SEED_ENV = {
    "pixabay": ("PIXABAY_API_KEYS", "PIXABAY_API_KEY"),
    "unsplash": ("UNSPLASH_ACCESS_KEYS", "UNSPLASH_ACCESS_KEY"),
    "youtube": ("YOUTUBE_API_KEYS", "YOUTUBE_API_KEY"),
    "gemini": ("GEMINI_API_KEYS", "GEMINI_API_KEY"),
    "groq": ("GROQ_API_KEYS", "GROQ_API_KEY"),
    "openai": ("OPENAI_API_KEYS", "OPENAI_API_KEY"),
    "openrouter": ("OPENROUTER_API_KEYS", "OPENROUTER_API_KEY"),
}


def load_settings(
    env: Mapping[str, str] | None = None,
    *,
    require_token: bool = True,
    base_dir: Path | None = None,
) -> Settings:
    """Build Settings from a mapping (defaults to os.environ)."""
    if env is None:
        env = os.environ
    base = base_dir or BASE_DIR

    token = _clean(env.get("BOT_TOKEN"))
    if require_token:
        if not token:
            raise ConfigError("BOT_TOKEN is not set. Copy .env.example to .env and fill it in.")
        if not TOKEN_RE.match(token):
            raise ConfigError("BOT_TOKEN does not look like a valid Telegram bot token.")

    admin_ids = parse_admin_ids(env.get("ADMIN_IDS", ""))
    if require_token and not admin_ids:
        raise ConfigError("ADMIN_IDS must contain at least one numeric Telegram user ID.")

    level = (_clean(env.get("LOG_LEVEL")) or "INFO").upper()
    if level not in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}:
        raise ConfigError(f"LOG_LEVEL invalid: {level}")

    local_url = _clean(env.get("LOCAL_BOT_API_URL")).rstrip("/")
    if local_url and not re.match(r"^https?://", local_url):
        raise ConfigError("LOCAL_BOT_API_URL must start with http:// or https://")

    chat_raw = _clean(env.get("ACTIVITY_CHAT_ID"))
    try:
        activity_chat = int(chat_raw) if chat_raw else None
    except ValueError:
        raise ConfigError("ACTIVITY_CHAT_ID must be a numeric chat id") from None

    seed: dict[str, tuple[str, ...]] = {}
    for service, names in _SEED_ENV.items():
        keys: list[str] = []
        for n in names:
            keys.extend(_csv(env, n))
        if keys:
            seed[service] = tuple(dict.fromkeys(keys))

    return Settings(
        bot_token=token,
        admin_ids=admin_ids,
        database_path=parse_sqlite_url(env.get("DATABASE_URL", ""), base),
        download_dir=_path(env, "DOWNLOAD_DIR", "downloads", base),
        temp_dir=_path(env, "TEMP_DIR", "temp", base),
        log_dir=_path(env, "LOG_DIR", "logs", base),
        log_level=level,
        max_file_size_mb=_int(env, "MAX_FILE_SIZE_MB", 1900, 1),
        max_concurrent_downloads=_int(env, "MAX_CONCURRENT_DOWNLOADS", 3, 1),
        per_user_concurrency=_int(env, "PER_USER_CONCURRENCY", 2, 1),
        max_queue_size=_int(env, "MAX_QUEUE_SIZE", 50, 1),
        upload_limit_override_mb=_int(env, "UPLOAD_LIMIT_MB", 0, 0),
        local_bot_api_url=local_url,
        max_split_parts=_int(env, "MAX_SPLIT_PARTS", 30, 1),
        engine_timeout_s=_int(env, "ENGINE_TIMEOUT_SECONDS", 1800, 10),
        metadata_timeout_s=_int(env, "METADATA_TIMEOUT_SECONDS", 60, 5),
        max_retries=_int(env, "MAX_RETRIES", 2, 0),
        cleanup_hours=_int(env, "CLEANUP_HOURS", 6, 1),
        rate_limit_per_minute=_int(env, "RATE_LIMIT_PER_MINUTE", 12, 1),
        free_daily_downloads=_int(env, "FREE_DAILY_DOWNLOADS", 10, 1),
        referral_threshold=_int(env, "REFERRAL_THRESHOLD", 3, 1),
        premium_days=_int(env, "PREMIUM_DAYS", 30, 1),
        force_sub_channels=tuple(_csv(env, "FORCE_SUB_CHANNELS")),
        owner_name=_clean(env.get("OWNER_NAME")) or "Ovi",
        owner_username=_clean(env.get("OWNER_USERNAME")).lstrip("@") or "RH_Ovi_106",
        bot_name=_clean(env.get("BOT_NAME")) or "Premium Link Downloader",
        activity_bot_token=_clean(env.get("ACTIVITY_BOT_TOKEN")),
        activity_chat_id=activity_chat,
        activity_use_topics=_bool(env, "ACTIVITY_USE_TOPICS", False),
        google_sheets_id=_clean(env.get("GOOGLE_SHEETS_ID")),
        google_service_account_file=_clean(env.get("GOOGLE_SERVICE_ACCOUNT_FILE")),
        sheets_sync_minutes=_int(env, "SHEETS_SYNC_MINUTES", 30, 5),
        secret_key=_clean(env.get("SECRET_KEY")),
        cobalt_api_url=_clean(env.get("COBALT_API_URL")).rstrip("/"),
        cobalt_api_key=_clean(env.get("COBALT_API_KEY")),
        streamlink_max_seconds=_int(env, "STREAMLINK_MAX_SECONDS", 600, 10),
        watermark_text=_clean(env.get("WATERMARK_TEXT")),
        watermark_image=_clean(env.get("WATERMARK_IMAGE")),
        watermark_font=_clean(env.get("WATERMARK_FONT")) or r"C:/Windows/Fonts/arial.ttf",
        seed_keys=seed,
    )
