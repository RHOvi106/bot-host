"""Provider health tracking."""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Awaitable, Callable


@dataclass
class HealthRecord:
    name: str
    ok: bool | None = None
    latency_ms: float | None = None
    checked_at: float | None = None
    detail: str = ""


class HealthMonitor:
    def __init__(self):
        self.records: dict[str, HealthRecord] = {}

    async def check(self, name: str, probe: Callable[[], Awaitable[object]]) -> HealthRecord:
        start = time.monotonic()
        rec = HealthRecord(name, checked_at=time.time())
        try:
            await probe()
            rec.ok = True
        except Exception as exc:  # noqa: BLE001 - any failure means unhealthy
            rec.ok, rec.detail = False, f"{type(exc).__name__}: {str(exc)[:120]}"
        rec.latency_ms = (time.monotonic() - start) * 1000
        self.records[name] = rec
        return rec
