"""Unsplash and Pixabay providers (documented public APIs, keys come from the key bank)."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from urllib.parse import urlsplit

from api.base_client import ApiClient, ApiError, HttpBackend
from services.key_bank import KeyBank


@dataclass
class StockItem:
    id: str
    source: str                 # unsplash | pixabay
    kind: str                   # photo | vector | video
    author: str
    preview_url: str
    download_url: str
    page_url: str = ""
    description: str = ""
    width: int | None = None
    height: int | None = None
    duration: int | None = None
    track_url: str | None = None    # Unsplash download-tracking endpoint


class UnsplashProvider:
    name, service = "unsplash", "unsplash"
    HOST = "api.unsplash.com"

    def __init__(self, bank: KeyBank, backend: HttpBackend | None = None):
        self.bank = bank
        self.client = ApiClient("unsplash", f"https://{self.HOST}", backend=backend,
                                default_headers={"Accept-Version": "v1"}, min_interval=0.25)

    @staticmethod
    def _item(p: dict) -> StockItem:
        urls, links = p.get("urls") or {}, p.get("links") or {}
        return StockItem(
            id=str(p.get("id")), source="unsplash", kind="photo",
            author=(p.get("user") or {}).get("name") or "Unknown",
            preview_url=urls.get("small") or urls.get("regular") or "",
            download_url=urls.get("full") or urls.get("regular") or "",
            page_url=links.get("html", ""), description=p.get("description") or p.get("alt_description") or "",
            width=p.get("width"), height=p.get("height"), track_url=links.get("download_location"))

    async def search(self, query: str, per_page: int = 5, page: int = 1) -> list[StockItem]:
        async def call(key: str):
            return await self.client.request(
                "GET", "/search/photos", params={"query": query, "per_page": per_page, "page": page},
                headers={"Authorization": f"Client-ID {key}"},
                validator=lambda d: isinstance(d, dict) and isinstance(d.get("results"), list))
        data = await self.bank.with_key("unsplash", call)
        return [self._item(p) for p in data["results"]]

    async def random(self, query: str | None = None, count: int = 1) -> list[StockItem]:
        params: dict[str, Any] = {"count": count}
        if query:
            params["query"] = query

        async def call(key: str):
            return await self.client.request("GET", "/photos/random", params=params,
                                             headers={"Authorization": f"Client-ID {key}"})
        data = await self.bank.with_key("unsplash", call)
        items = data if isinstance(data, list) else [data]
        return [self._item(p) for p in items if isinstance(p, dict)]

    async def track_download(self, item: StockItem) -> None:
        """Unsplash API guidelines require pinging the download endpoint when a photo is downloaded."""
        if not item.track_url or urlsplit(item.track_url).hostname != self.HOST:
            return

        async def call(key: str):
            return await self.client.request("GET", item.track_url, headers={"Authorization": f"Client-ID {key}"})
        try:
            await self.bank.with_key("unsplash", call)
        except Exception:  # noqa: BLE001 - tracking is best effort
            pass


class PixabayProvider:
    name, service = "pixabay", "pixabay"

    def __init__(self, bank: KeyBank, backend: HttpBackend | None = None):
        self.bank = bank
        self.client = ApiClient("pixabay", "https://pixabay.com", backend=backend, min_interval=0.7)

    async def search_images(self, query: str, per_page: int = 5, image_type: str = "photo") -> list[StockItem]:
        async def call(key: str):
            return await self.client.request(
                "GET", "/api/", params={"key": key, "q": query, "image_type": image_type,
                                        "per_page": max(3, per_page), "safesearch": "true"},
                validator=lambda d: isinstance(d, dict) and isinstance(d.get("hits"), list))
        data = await self.bank.with_key("pixabay", call)
        out = []
        for h in data["hits"][:per_page]:
            out.append(StockItem(
                id=str(h.get("id")), source="pixabay", kind="vector" if image_type == "vector" else "photo",
                author=h.get("user") or "Unknown", preview_url=h.get("webformatURL") or h.get("previewURL") or "",
                download_url=h.get("largeImageURL") or h.get("webformatURL") or "",
                page_url=h.get("pageURL", ""), description=h.get("tags", ""),
                width=h.get("imageWidth"), height=h.get("imageHeight")))
        return out

    async def search_videos(self, query: str, per_page: int = 5) -> list[StockItem]:
        async def call(key: str):
            return await self.client.request(
                "GET", "/api/videos/", params={"key": key, "q": query, "per_page": max(3, per_page),
                                               "safesearch": "true"},
                validator=lambda d: isinstance(d, dict) and isinstance(d.get("hits"), list))
        data = await self.bank.with_key("pixabay", call)
        out = []
        for h in data["hits"][:per_page]:
            vids = h.get("videos") or {}
            pick = vids.get("medium") or vids.get("small") or vids.get("tiny") or vids.get("large") or {}
            if not pick.get("url"):
                continue
            out.append(StockItem(
                id=str(h.get("id")), source="pixabay", kind="video", author=h.get("user") or "Unknown",
                preview_url="", download_url=pick["url"], page_url=h.get("pageURL", ""),
                description=h.get("tags", ""), width=pick.get("width"), height=pick.get("height"),
                duration=h.get("duration")))
        return out
