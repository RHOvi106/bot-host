"""Cobalt API client (self-hosted or authorised instance). Configured via COBALT_API_URL.

Request/response shape follows Cobalt's published API (POST / with JSON). Verify it against
YOUR instance's version before relying on it; the engine is disabled unless a URL is configured.
"""
from __future__ import annotations

from dataclasses import dataclass

from api.base_client import ApiClient, ApiError, HttpBackend
from engines.base import ErrorCategory


@dataclass
class CobaltResult:
    url: str
    filename: str | None = None


_ERROR_MAP = (("unsupported", ErrorCategory.UNSUPPORTED), ("login", ErrorCategory.AUTH_REQUIRED),
              ("age", ErrorCategory.AUTH_REQUIRED), ("private", ErrorCategory.PRIVATE),
              ("rate", ErrorCategory.RATE_LIMIT), ("unavailable", ErrorCategory.UNAVAILABLE),
              ("not_found", ErrorCategory.UNAVAILABLE))


def map_cobalt_error(code: str) -> ErrorCategory:
    code = (code or "").lower()
    for needle, cat in _ERROR_MAP:
        if needle in code:
            return cat
    return ErrorCategory.UNKNOWN


class CobaltError(Exception):
    def __init__(self, category: ErrorCategory, message: str):
        super().__init__(message)
        self.category, self.message = category, message


class CobaltProvider:
    name, service = "cobalt", "cobalt"

    def __init__(self, base_url: str, api_key: str = "", backend: HttpBackend | None = None):
        self.base_url = base_url
        headers = {"Accept": "application/json", "Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Api-Key {api_key}"
        self.client = ApiClient("cobalt", base_url, backend=backend, default_headers=headers, timeout=30,
                                allow_private=True) if base_url else None   # operator-configured target

    def configured(self) -> bool:
        return self.client is not None

    async def resolve(self, url: str, kind: str, height: int | None, audio_format: str) -> CobaltResult:
        if not self.client:
            raise CobaltError(ErrorCategory.UNSUPPORTED, "Cobalt is not configured")
        body = {"url": url, "filenameStyle": "basic",
                "downloadMode": "audio" if kind == "audio" else "auto",
                "videoQuality": str(height) if height else "max",
                "audioFormat": audio_format if audio_format in {"mp3", "ogg", "wav", "opus"} else "best"}
        try:
            data = await self.client.request("POST", "/", json_body=body,
                                             validator=lambda d: isinstance(d, dict) and "status" in d)
        except ApiError as exc:
            cat = {"rate_limit": ErrorCategory.RATE_LIMIT, "timeout": ErrorCategory.TIMEOUT,
                   "network": ErrorCategory.NETWORK, "auth": ErrorCategory.AUTH_REQUIRED}.get(exc.kind, ErrorCategory.UNKNOWN)
            raise CobaltError(cat, str(exc)) from None
        status = data.get("status")
        if status in ("tunnel", "redirect", "stream") and data.get("url"):
            return CobaltResult(data["url"], data.get("filename"))
        if status == "picker":
            for item in data.get("picker") or []:
                if item.get("url") and item.get("type", "video") in ("video", "photo", "gif"):
                    return CobaltResult(item["url"], None)
        if status == "error":
            err = data.get("error")
            code = err.get("code", "") if isinstance(err, dict) else str(err)
            raise CobaltError(map_cobalt_error(code), code)
        raise CobaltError(ErrorCategory.UNKNOWN, f"unexpected Cobalt status: {status}")
