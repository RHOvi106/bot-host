"""YouTube search: official Data API v3 when keys exist, else key-less yt-dlp search."""
from __future__ import annotations

import re

from api.base_client import ApiClient, ApiError, HttpBackend
from engines.ytdlp_engine import search_youtube_flat
from services.key_bank import KeyBank, NoKeyAvailable

_ISO = re.compile(r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?")


def parse_iso_duration(value: str) -> int | None:
    m = _ISO.fullmatch(value or "")
    if not m:
        return None
    h, mi, s = (int(x or 0) for x in m.groups())
    return h * 3600 + mi * 60 + s


class YouTubeSearch:
    name, service = "youtube", "youtube"

    def __init__(self, bank: KeyBank, backend: HttpBackend | None = None, cookies_getter=None):
        self.bank = bank
        self.client = ApiClient("youtube", "https://www.googleapis.com", backend=backend, min_interval=0.2)
        self._cookies = cookies_getter or (lambda: None)

    async def _api_search(self, query: str, limit: int) -> list[dict]:
        async def search_call(key: str):
            return await self.client.request(
                "GET", "/youtube/v3/search",
                params={"part": "snippet", "type": "video", "maxResults": limit, "q": query,
                        "safeSearch": "moderate", "key": key},
                validator=lambda d: isinstance(d, dict) and isinstance(d.get("items"), list))
        data = await self.bank.with_key("youtube", search_call)
        items = [i for i in data["items"] if (i.get("id") or {}).get("videoId")]
        ids = [i["id"]["videoId"] for i in items]
        durations: dict[str, int | None] = {}
        if ids:
            async def detail_call(key: str):
                return await self.client.request(
                    "GET", "/youtube/v3/videos",
                    params={"part": "contentDetails", "id": ",".join(ids), "key": key},
                    validator=lambda d: isinstance(d, dict) and isinstance(d.get("items"), list))
            try:
                det = await self.bank.with_key("youtube", detail_call)
                for d in det["items"]:
                    durations[d["id"]] = parse_iso_duration(d.get("contentDetails", {}).get("duration", ""))
            except (ApiError, NoKeyAvailable):
                pass
        return [{"id": i["id"]["videoId"], "title": i["snippet"].get("title", "Untitled"),
                 "channel": i["snippet"].get("channelTitle"), "duration": durations.get(i["id"]["videoId"]),
                 "url": f"https://www.youtube.com/watch?v={i['id']['videoId']}"} for i in items]

    async def search(self, query: str, limit: int = 5) -> list[dict]:
        if await self.bank.has_keys("youtube"):
            try:
                return await self._api_search(query, limit)
            except (ApiError, NoKeyAvailable):
                pass        # quota exhausted etc. -> key-less fallback
        return await search_youtube_flat(query, limit, self._cookies())
