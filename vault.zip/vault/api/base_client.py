"""HTTP client for documented APIs: timeouts, bounded retries, rate limit, SSRF guard.

The transport is pluggable (`HttpBackend`) so tests run without network or httpx.
"""
from __future__ import annotations

import asyncio
import json as jsonlib
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Protocol
from urllib.parse import urljoin

from engines.base import CancelToken
from utils.validators import InvalidUrl, validate_url_async

log = logging.getLogger(__name__)


class ApiError(Exception):
    """kind: rate_limit | auth | server | network | timeout | invalid | not_found | config"""

    def __init__(self, kind: str, message: str = "", status: int | None = None, retry_after: int | None = None):
        super().__init__(message or kind)
        self.kind, self.status, self.retry_after = kind, status, retry_after


@dataclass
class HttpResponse:
    status: int
    body: bytes = b""
    headers: dict[str, str] = field(default_factory=dict)

    def json(self) -> Any:
        try:
            return jsonlib.loads(self.body.decode("utf-8"))
        except (UnicodeDecodeError, jsonlib.JSONDecodeError):
            raise ApiError("invalid", "response was not valid JSON", self.status) from None


class HttpBackend(Protocol):
    async def request(self, method: str, url: str, *, headers: dict[str, str] | None,
                      params: dict[str, Any] | None, json_body: Any, timeout: float) -> HttpResponse: ...

    async def download(self, url: str, path: Path, *, headers: dict[str, str] | None, timeout: float,
                       max_bytes: int | None, on_progress: Callable[[int, int | None], None] | None,
                       cancel: CancelToken | None) -> int: ...


class HttpxBackend:
    """Default backend (httpx imported lazily). Redirects are followed manually and each hop is re-validated."""

    def __init__(self, allow_private: bool = False):
        self._client = None
        self.allow_private = allow_private

    def _get(self):
        if self._client is None:
            import httpx  # type: ignore
            self._client = httpx.AsyncClient(follow_redirects=False, headers={"User-Agent": "PremiumLinkDownloader/1.0"})
        return self._client

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def request(self, method, url, *, headers=None, params=None, json_body=None, timeout=15.0) -> HttpResponse:
        import httpx  # type: ignore
        try:
            r = await self._get().request(method, url, headers=headers, params=params, json=json_body, timeout=timeout)
        except httpx.TimeoutException:
            raise ApiError("timeout", "request timed out") from None
        except httpx.HTTPError as exc:
            raise ApiError("network", type(exc).__name__) from None
        return HttpResponse(r.status_code, r.content, {k.lower(): v for k, v in r.headers.items()})

    async def download(self, url, path, *, headers=None, timeout=60.0, max_bytes=None, on_progress=None, cancel=None) -> int:
        import httpx  # type: ignore
        client = self._get()
        current = url
        for _hop in range(5):
            if not self.allow_private:
                try:
                    await validate_url_async(current)
                except InvalidUrl as exc:
                    raise ApiError("invalid", f"blocked URL: {exc}") from None
            try:
                async with client.stream("GET", current, headers=headers, timeout=timeout) as r:
                    if r.status_code in (301, 302, 303, 307, 308) and r.headers.get("location"):
                        current = urljoin(current, r.headers["location"])
                        continue
                    if r.status_code >= 400:
                        raise ApiError("server" if r.status_code >= 500 else "invalid", f"HTTP {r.status_code}", r.status_code)
                    total = int(r.headers.get("content-length") or 0) or None
                    if max_bytes and total and total > max_bytes:
                        raise ApiError("invalid", "file too large")
                    written = 0
                    with open(path, "wb") as fh:
                        async for chunk in r.aiter_bytes(64 * 1024):
                            if cancel is not None and cancel.cancelled:
                                raise ApiError("cancelled", "cancelled")
                            written += len(chunk)
                            if max_bytes and written > max_bytes:
                                raise ApiError("invalid", "file too large")
                            fh.write(chunk)
                            if on_progress:
                                on_progress(written, total)
                    return written
            except httpx.TimeoutException:
                raise ApiError("timeout", "download timed out") from None
            except httpx.HTTPError as exc:
                raise ApiError("network", type(exc).__name__) from None
        raise ApiError("invalid", "too many redirects")


class ApiClient:
    def __init__(self, name: str, base_url: str, *, backend: HttpBackend | None = None,
                 default_headers: dict[str, str] | None = None, timeout: float = 15.0,
                 min_interval: float = 0.0, max_retries: int = 2, allow_private: bool = False,
                 sleep: Callable[[float], Any] = asyncio.sleep):
        from utils.validators import validate_url
        self.name, self.timeout, self.max_retries = name, timeout, max_retries
        self.default_headers = dict(default_headers or {})
        self.backend: HttpBackend = backend or HttpxBackend(allow_private=allow_private)
        self.min_interval = min_interval
        self._last = 0.0
        self._lock = asyncio.Lock()
        self._sleep = sleep
        if allow_private:
            self.base_url = base_url.rstrip("/")
        else:
            try:
                self.base_url = validate_url(base_url).rstrip("/")
            except InvalidUrl as exc:
                raise ApiError("config", f"unsafe API base URL for {name}: {exc}") from None
        self.last_ok: float | None = None
        self.last_error: str | None = None

    async def _throttle(self) -> None:
        if self.min_interval <= 0:
            return
        async with self._lock:
            wait = self._last + self.min_interval - time.monotonic()
            if wait > 0:
                await self._sleep(wait)
            self._last = time.monotonic()

    async def request(self, method: str, path: str = "", *, params: dict | None = None, json_body: Any = None,
                      headers: dict[str, str] | None = None, validator: Callable[[Any], bool] | None = None,
                      expect_json: bool = True) -> Any:
        url = self.base_url + path if path.startswith("/") or not path else urljoin(self.base_url + "/", path)
        hdrs = {**self.default_headers, **(headers or {})}
        attempt = 0
        while True:
            await self._throttle()
            try:
                resp = await self.backend.request(method, url, headers=hdrs, params=params,
                                                  json_body=json_body, timeout=self.timeout)
                self._raise_for_status(resp)
                data = resp.json() if expect_json else resp.body
                if validator is not None and not validator(data):
                    raise ApiError("invalid", "response failed validation", resp.status)
                self.last_ok, self.last_error = time.time(), None
                return data
            except ApiError as exc:
                self.last_error = f"{exc.kind}: {exc}"
                transient = exc.kind in {"network", "timeout", "server"}
                if transient and attempt < self.max_retries:
                    attempt += 1
                    await self._sleep(min(0.5 * 2 ** attempt, 4.0))
                    continue
                raise

    @staticmethod
    def _raise_for_status(resp: HttpResponse) -> None:
        s = resp.status
        if s < 400:
            return
        retry_after = None
        try:
            retry_after = int(resp.headers.get("retry-after", ""))
        except ValueError:
            pass
        if s == 429:
            raise ApiError("rate_limit", "rate limited", s, retry_after)
        if s in (401, 403):
            raise ApiError("auth", f"authorization failed (HTTP {s})", s)
        if s == 404:
            raise ApiError("not_found", "not found", s)
        if s >= 500:
            raise ApiError("server", f"server error (HTTP {s})", s)
        raise ApiError("invalid", f"HTTP {s}", s)
