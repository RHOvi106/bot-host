"""Registry of external API providers (verified, documented interfaces only)."""
from __future__ import annotations

from typing import Any, Protocol


class Provider(Protocol):
    name: str
    service: str            # key-bank service name

    def configured(self) -> bool: ...


class ApiRegistry:
    def __init__(self):
        self._providers: dict[str, Any] = {}

    def register(self, provider: Any) -> None:
        self._providers[provider.name] = provider

    def get(self, name: str) -> Any | None:
        return self._providers.get(name)

    def all(self) -> list[Any]:
        return list(self._providers.values())
