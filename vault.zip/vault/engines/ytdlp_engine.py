"""yt-dlp engine (primary). Runs in worker threads so the event loop never blocks."""
from __future__ import annotations

import asyncio
import importlib.util
import logging
import shutil
from pathlib import Path
from typing import Any

from services import metadata_service
from services.media_service import pick_output_file
from .base import (BaseEngine, CancelToken, DownloadRequest, DownloadResult, EngineError, ErrorCategory,
                   MediaInfo, ProgressCallback, ProgressEvent, classify_message)

log = logging.getLogger(__name__)


class _Cancelled(Exception):
    pass


class _QuietLogger:
    def debug(self, msg): pass
    def info(self, msg): pass
    def warning(self, msg): log.debug("yt-dlp: %s", msg)
    def error(self, msg): log.debug("yt-dlp error: %s", msg)


def build_format_selector(kind: str, height: int | None) -> str:
    if kind == "audio":
        return "bestaudio/best"
    if height:
        return f"bv*[height<={height}]+ba/b[height<={height}]"
    return "bv*+ba/b"


def build_audio_postprocessors(audio_format: str) -> list[dict]:
    if audio_format in ("best", "original", ""):
        return []
    quality = "192" if audio_format == "mp3" else "0"
    return [{"key": "FFmpegExtractAudio", "preferredcodec": audio_format, "preferredquality": quality}]


class YtDlpEngine(BaseEngine):
    name = "ytdlp"
    display_name = "yt-dlp"
    default_priority = 10

    def __init__(self, settings: dict[str, Any] | None = None):
        super().__init__(settings)
        self._yt = None

    def is_available(self) -> bool:
        return importlib.util.find_spec("yt_dlp") is not None

    def version(self) -> str:
        try:
            from yt_dlp.version import __version__  # type: ignore
            return __version__
        except Exception:  # noqa: BLE001
            return "n/a"

    def can_handle(self, url: str) -> bool:
        # yt-dlp's generic extractor can attempt any http(s) page; failures fall through.
        return url.lower().startswith(("http://", "https://"))

    def _base_opts(self, cookies_file: str | None) -> dict[str, Any]:
        opts: dict[str, Any] = {
            "quiet": True, "no_warnings": True, "noplaylist": True, "logger": _QuietLogger(),
            "socket_timeout": 30, "retries": 3, "fragment_retries": 3,
            "concurrent_fragment_downloads": int(self.settings.get("fragments", 4)),
            "ignoreerrors": False, "noprogress": True,
        }
        if cookies_file and Path(cookies_file).is_file():
            opts["cookiefile"] = cookies_file
        return opts

    @staticmethod
    def _wrap(exc: BaseException) -> EngineError:
        if isinstance(exc, EngineError):
            return exc
        text = str(exc)
        return EngineError(classify_message(text), text[:400], "ytdlp")

    def _extract_sync(self, url: str, cookies_file: str | None) -> MediaInfo:
        import yt_dlp  # type: ignore
        opts = self._base_opts(cookies_file)
        opts["skip_download"] = True
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False)
            if not info:
                raise EngineError(ErrorCategory.UNSUPPORTED, "no information returned", "ytdlp")
            return metadata_service.from_ytdlp(info, url, "ytdlp")
        except EngineError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise self._wrap(exc) from None

    async def extract_info(self, url: str, *, cookies_file: str | None = None) -> MediaInfo:
        return await asyncio.to_thread(self._extract_sync, url, cookies_file)

    def _download_sync(self, req: DownloadRequest, progress: ProgressCallback, cancel: CancelToken) -> DownloadResult:
        import yt_dlp  # type: ignore
        needs_ffmpeg = req.kind == "video" or req.audio_format not in ("best", "original", "")
        have_ffmpeg = bool(shutil.which("ffmpeg"))
        if req.audio_format not in ("best", "original", "") and req.kind == "audio" and not have_ffmpeg:
            raise EngineError(ErrorCategory.FFMPEG_MISSING, "FFmpeg is required to convert audio", "ytdlp")

        def hook(d: dict) -> None:
            if cancel.cancelled:
                raise _Cancelled()
            status = d.get("status")
            if status == "downloading":
                total = d.get("total_bytes") or d.get("total_bytes_estimate")
                done = d.get("downloaded_bytes")
                pct = (done / total * 100.0) if total and done is not None else None
                progress(ProgressEvent("downloading", pct, done, total, d.get("speed"), d.get("eta")))
            elif status == "finished":
                progress(ProgressEvent("downloading", 100.0, d.get("downloaded_bytes"), d.get("total_bytes")))

        def pp_hook(d: dict) -> None:
            if cancel.cancelled:
                raise _Cancelled()
            if d.get("status") == "started":
                name = str(d.get("postprocessor", ""))
                stage = "merging" if "Merger" in name else "converting"
                progress(ProgressEvent(stage))

        opts = self._base_opts(req.cookies_file)
        out_dir = Path(req.out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        opts.update({
            "format": build_format_selector(req.kind, req.height),
            "outtmpl": str(out_dir / "%(id).60B.%(ext)s"),
            "progress_hooks": [hook], "postprocessor_hooks": [pp_hook],
            "restrictfilenames": True, "windowsfilenames": True,
        })
        if req.max_filesize:
            opts["max_filesize"] = req.max_filesize
        pps: list[dict] = []
        if req.kind == "video":
            opts["format_sort"] = ["res", "ext:mp4:m4a"]
            if have_ffmpeg:
                opts["merge_output_format"] = req.container if req.container in ("mp4", "mkv", "webm") else "mp4"
        else:
            pps += build_audio_postprocessors(req.audio_format)
        if have_ffmpeg and needs_ffmpeg or pps:
            pps.append({"key": "FFmpegMetadata", "add_metadata": True})
        if pps:
            opts["postprocessors"] = pps
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(req.url, download=True)
        except _Cancelled:
            raise EngineError(ErrorCategory.CANCELLED, "cancelled", "ytdlp") from None
        except Exception as exc:  # noqa: BLE001
            if cancel.cancelled or "_Cancelled" in repr(exc):
                raise EngineError(ErrorCategory.CANCELLED, "cancelled", "ytdlp") from None
            raise self._wrap(exc) from None
        path = pick_output_file(out_dir, req.kind)
        if path is None:
            raise EngineError(ErrorCategory.UNKNOWN, "download finished but no file was produced", "ytdlp")
        size = path.stat().st_size
        if req.max_filesize and size > req.max_filesize:
            path.unlink(missing_ok=True)
            raise EngineError(ErrorCategory.TOO_LARGE, f"file is {size} bytes", "ytdlp")
        media = None
        try:
            media = metadata_service.from_ytdlp(info, req.url, "ytdlp") if info else None
        except Exception:  # noqa: BLE001 - metadata is best effort after a successful download
            pass
        return DownloadResult(path, path.suffix.lstrip("."), size, "ytdlp", media)

    async def download(self, req: DownloadRequest, progress: ProgressCallback, cancel: CancelToken) -> DownloadResult:
        return await asyncio.to_thread(self._download_sync, req, progress, cancel)


async def search_youtube_flat(query: str, limit: int, cookies_file: str | None = None) -> list[dict]:
    """Key-less YouTube search through yt-dlp ('ytsearchN:'). Returns light dicts."""
    def run() -> list[dict]:
        import yt_dlp  # type: ignore
        opts = {"quiet": True, "no_warnings": True, "extract_flat": True, "skip_download": True,
                "logger": _QuietLogger()}
        if cookies_file and Path(cookies_file).is_file():
            opts["cookiefile"] = cookies_file
        with yt_dlp.YoutubeDL(opts) as ydl:
            data = ydl.extract_info(f"ytsearch{int(limit)}:{query}", download=False)
        out = []
        for e in (data or {}).get("entries", []) or []:
            if not e:
                continue
            vid = e.get("id")
            out.append({"id": vid, "title": e.get("title") or "Untitled",
                        "channel": e.get("channel") or e.get("uploader"),
                        "duration": e.get("duration"),
                        "url": e.get("url") if str(e.get("url", "")).startswith("http")
                        else f"https://www.youtube.com/watch?v={vid}"})
        return out
    try:
        return await asyncio.to_thread(run)
    except Exception as exc:  # noqa: BLE001
        raise EngineError(classify_message(str(exc)), str(exc)[:300], "ytdlp") from None
