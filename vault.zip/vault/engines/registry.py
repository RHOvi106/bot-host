"""Engine registry: priority, enable/disable, capability filtering and health."""
from __future__ import annotations

import logging
from typing import Any

from .base import BaseEngine

log = logging.getLogger(__name__)


class EngineRegistry:
    def __init__(self, repo: Any | None = None):
        self._engines: dict[str, BaseEngine] = {}
        self._state: dict[str, dict] = {}
        self.repo = repo

    def register(self, engine: BaseEngine) -> None:
        self._engines[engine.name] = engine
        state = {"enabled": True, "priority": engine.default_priority}
        if self.repo is not None:
            row = self.repo.ensure_engine(engine.name, engine.default_priority)
            state = {"enabled": bool(row["enabled"]), "priority": row["priority"]}
        self._state[engine.name] = state

    def get(self, name: str) -> BaseEngine | None:
        return self._engines.get(name)

    def names(self) -> list[str]:
        return list(self._engines)

    def is_enabled(self, name: str) -> bool:
        return self._state.get(name, {}).get("enabled", False)

    def priority(self, name: str) -> int:
        return self._state.get(name, {}).get("priority", 999)

    def set_enabled(self, name: str, enabled: bool) -> None:
        if name not in self._engines:
            raise KeyError(name)
        self._state[name]["enabled"] = enabled
        if self.repo is not None:
            self.repo.set_engine_enabled(name, enabled)

    def set_priority(self, name: str, priority: int) -> None:
        if name not in self._engines:
            raise KeyError(name)
        self._state[name]["priority"] = priority
        if self.repo is not None:
            self.repo.set_engine_priority(name, priority)

    def usable(self) -> list[BaseEngine]:
        """Enabled + installed engines, best priority first."""
        engines = []
        for e in self._engines.values():
            try:
                ok = self.is_enabled(e.name) and e.is_available()
            except Exception:  # noqa: BLE001 - a broken optional dependency must not crash the bot
                log.exception("Availability check failed for engine %s", e.name)
                ok = False
            if ok:
                engines.append(e)
        return sorted(engines, key=lambda e: (self.priority(e.name), e.name))

    def compatible(self, url: str, kind: str) -> list[BaseEngine]:
        result = []
        for e in self.usable():
            try:
                if e.supports_kind(kind) and e.can_handle(url):
                    result.append(e)
            except Exception:  # noqa: BLE001
                log.exception("can_handle failed for engine %s", e.name)
        return result

    def record(self, name: str, ok: bool, error: str | None = None) -> None:
        if self.repo is not None:
            self.repo.record_engine_result(name, ok, error)

    def describe(self) -> list[dict]:
        rows = {r["engine"]: r for r in self.repo.list_engines()} if self.repo is not None else {}
        out = []
        for e in self._engines.values():
            try:
                available, version = e.is_available(), (e.version() if e.is_available() else "n/a")
            except Exception:  # noqa: BLE001
                available, version = False, "error"
            r = rows.get(e.name, {})
            out.append({
                "name": e.name, "display_name": e.display_name, "available": available,
                "version": version, "enabled": self.is_enabled(e.name),
                "priority": self.priority(e.name), "video": e.supports_video, "audio": e.supports_audio,
                "success": r.get("success_count", 0), "failures": r.get("failure_count", 0),
                "last_success": r.get("last_success"), "last_error": r.get("last_error"),
            })
        return sorted(out, key=lambda d: (d["priority"], d["name"]))
