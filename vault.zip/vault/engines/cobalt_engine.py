"""Cobalt fallback engine: asks a configured Cobalt instance for a direct media URL, then downloads it."""
from __future__ import annotations

import mimetypes
from pathlib import Path
from urllib.parse import urlsplit

from api.base_client import ApiError
from api.providers.cobalt import CobaltError, CobaltProvider
from utils.filenames import safe_filename
from utils.validators import platform_of
from .base import (BaseEngine, CancelToken, DownloadRequest, DownloadResult, EngineError, ErrorCategory,
                   MediaInfo, ProgressCallback, ProgressEvent)
import asyncio


class CobaltEngine(BaseEngine):
    name = "cobalt"
    display_name = "Cobalt"
    default_priority = 20
    supports_metadata = False

    def __init__(self, provider: CobaltProvider, settings: dict | None = None):
        super().__init__(settings)
        self.provider = provider

    def is_available(self) -> bool:
        return self.provider.configured()

    def version(self) -> str:
        return "API" if self.provider.configured() else "n/a"

    def can_handle(self, url: str) -> bool:
        return self.provider.configured() and url.lower().startswith(("http://", "https://"))

    async def extract_info(self, url: str, *, cookies_file: str | None = None) -> MediaInfo:
        # Cobalt has no metadata endpoint; the download call is the real capability test.
        return MediaInfo(url=url, title=platform_of(url).title() + " media", webpage_url=url,
                         platform=platform_of(url), engine=self.name)

    async def download(self, req: DownloadRequest, progress: ProgressCallback, cancel: CancelToken) -> DownloadResult:
        try:
            res = await self.provider.resolve(req.url, req.kind, req.height, req.audio_format)
        except CobaltError as exc:
            raise EngineError(exc.category, exc.message, self.name) from None
        cancel.raise_if_cancelled(self.name)
        out_dir = Path(req.out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        name = safe_filename(res.filename or Path(urlsplit(res.url).path).name or "media", default="media")
        if "." not in name:
            name += ".mp3" if req.kind == "audio" else ".mp4"
        target = out_dir / name
        loop = asyncio.get_running_loop()

        def on_progress(done: int, total: int | None) -> None:
            pct = done / total * 100 if total else None
            loop.call_soon(progress, ProgressEvent("downloading", pct, done, total))

        try:
            size = await self.provider.client.backend.download(
                res.url, target, headers=None, timeout=60.0, max_bytes=req.max_filesize,
                on_progress=on_progress, cancel=cancel)
        except ApiError as exc:
            if exc.kind == "cancelled":
                raise EngineError(ErrorCategory.CANCELLED, "cancelled", self.name) from None
            cat = {"timeout": ErrorCategory.TIMEOUT, "network": ErrorCategory.NETWORK,
                   "server": ErrorCategory.NETWORK}.get(exc.kind, ErrorCategory.TOO_LARGE if "large" in str(exc) else ErrorCategory.UNKNOWN)
            target.unlink(missing_ok=True)
            raise EngineError(cat, str(exc), self.name) from None
        return DownloadResult(target, target.suffix.lstrip("."), size, self.name)
