"""gallery-dl engine (optional): images and galleries. Capability-checked."""
from __future__ import annotations

import importlib.util
import shutil
from pathlib import Path

from services.media_service import pick_output_file
from utils.proc import run_process
from .base import (BaseEngine, CancelToken, DownloadRequest, DownloadResult, EngineError, ErrorCategory,
                   MediaInfo, ProgressCallback, ProgressEvent, classify_message)
from utils.validators import platform_of


class GalleryDlEngine(BaseEngine):
    name = "gallerydl"
    display_name = "gallery-dl"
    default_priority = 40
    supports_audio = False

    def _exe(self) -> str | None:
        return shutil.which("gallery-dl")

    def is_available(self) -> bool:
        return self._exe() is not None

    def version(self) -> str:
        try:
            if importlib.util.find_spec("gallery_dl"):
                from gallery_dl import version  # type: ignore
                return version.__version__
        except Exception:  # noqa: BLE001
            pass
        return "installed" if self._exe() else "n/a"

    def can_handle(self, url: str) -> bool:
        return url.lower().startswith(("http://", "https://"))

    async def extract_info(self, url: str, *, cookies_file: str | None = None) -> MediaInfo:
        exe = self._exe()
        if not exe:
            raise EngineError(ErrorCategory.UNSUPPORTED, "gallery-dl not installed", self.name)
        args = [exe, "--simulate", "-q", url]
        if cookies_file and Path(cookies_file).is_file():
            args[1:1] = ["--cookies", cookies_file]
        rc, out, err = await run_process(args, timeout=60, engine=self.name)
        if rc != 0:
            msg = (err or out)[-300:]
            cat = classify_message(msg)
            raise EngineError(ErrorCategory.UNSUPPORTED if cat == ErrorCategory.UNKNOWN else cat, msg, self.name)
        return MediaInfo(url=url, title=platform_of(url).title() + " media", webpage_url=url,
                         platform=platform_of(url), engine=self.name)

    async def download(self, req: DownloadRequest, progress: ProgressCallback, cancel: CancelToken) -> DownloadResult:
        exe = self._exe()
        if not exe:
            raise EngineError(ErrorCategory.UNSUPPORTED, "gallery-dl not installed", self.name)
        out_dir = Path(req.out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        args = [exe, "--no-mtime", "-q", "-D", str(out_dir)]
        if req.max_filesize:
            args += ["--filesize-max", str(req.max_filesize)]
        if req.cookies_file and Path(req.cookies_file).is_file():
            args += ["--cookies", req.cookies_file]
        args.append(req.url)
        progress(ProgressEvent("downloading"))   # no reliable percentage from gallery-dl
        rc, out, err = await run_process(args, timeout=self.timeout, cancel=cancel, engine=self.name)
        path = pick_output_file(out_dir, "video")
        if rc != 0 and path is None:
            msg = (err or out)[-300:] or "gallery-dl failed"
            raise EngineError(classify_message(msg), msg, self.name)
        if path is None:
            raise EngineError(ErrorCategory.UNSUPPORTED, "no media found", self.name)
        return DownloadResult(path, path.suffix.lstrip("."), path.stat().st_size, self.name)
