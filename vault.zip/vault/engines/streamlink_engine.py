"""streamlink engine (optional): live/HLS streams, with a hard duration cap."""
from __future__ import annotations

import importlib.util
import shutil
from pathlib import Path

from services.media_service import pick_output_file
from utils.proc import run_process
from utils.validators import platform_of
from .base import (BaseEngine, CancelToken, DownloadRequest, DownloadResult, EngineError, ErrorCategory,
                   MediaInfo, ProgressCallback, ProgressEvent, classify_message)


class StreamlinkEngine(BaseEngine):
    name = "streamlink"
    display_name = "streamlink"
    default_priority = 30
    supports_audio = False

    def _exe(self) -> str | None:
        return shutil.which("streamlink")

    def is_available(self) -> bool:
        return self._exe() is not None

    def version(self) -> str:
        try:
            if importlib.util.find_spec("streamlink"):
                import streamlink  # type: ignore
                return getattr(streamlink, "__version__", "installed")
        except Exception:  # noqa: BLE001
            pass
        return "installed" if self._exe() else "n/a"

    @property
    def max_seconds(self) -> int:
        return int(self.settings.get("max_seconds", 600))

    def can_handle(self, url: str) -> bool:
        # Real capability check: streamlink answers whether a plugin matches the URL.
        # (Synchronous & fast; it does not touch the network.)
        import subprocess
        exe = self._exe()
        if not exe or not url.lower().startswith(("http://", "https://")):
            return False
        try:
            r = subprocess.run([exe, "--can-handle-url", url], capture_output=True, timeout=10)
            return r.returncode == 0
        except (OSError, subprocess.TimeoutExpired):
            return False

    async def extract_info(self, url: str, *, cookies_file: str | None = None) -> MediaInfo:
        exe = self._exe()
        if not exe:
            raise EngineError(ErrorCategory.UNSUPPORTED, "streamlink not installed", self.name)
        rc, out, err = await run_process([exe, "--json", url], timeout=60, engine=self.name)
        if rc != 0 or '"error"' in out[:200]:
            raise EngineError(classify_message(out + err), (out + err)[-300:], self.name)
        return MediaInfo(url=url, title=platform_of(url).title() + " stream", webpage_url=url,
                         platform=platform_of(url), is_live=True, engine=self.name)

    async def download(self, req: DownloadRequest, progress: ProgressCallback, cancel: CancelToken) -> DownloadResult:
        exe = self._exe()
        if not exe:
            raise EngineError(ErrorCategory.UNSUPPORTED, "streamlink not installed", self.name)
        out_dir = Path(req.out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        target = out_dir / "stream.ts"
        h, rem = divmod(self.max_seconds, 3600)
        dur = f"{h:02d}:{rem // 60:02d}:{rem % 60:02d}"
        args = [exe, "--force", "--hls-duration", dur, "-o", str(target), req.url, "best"]
        progress(ProgressEvent("downloading"))
        rc, out, err = await run_process(args, timeout=self.max_seconds + 120, cancel=cancel, engine=self.name)
        path = pick_output_file(out_dir, "video")
        if path is None or path.stat().st_size == 0:
            msg = (err or out)[-300:] or "streamlink produced no data"
            raise EngineError(classify_message(msg), msg, self.name)
        return DownloadResult(path, path.suffix.lstrip("."), path.stat().st_size, self.name)
