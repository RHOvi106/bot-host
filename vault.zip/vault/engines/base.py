"""Engine adapter interface, shared data types and error classification.

To add a new downloader: subclass BaseEngine, implement the abstract methods and
register an instance in engines/registry.py (see README "Adding an engine").
"""
from __future__ import annotations

import re
import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable


class ErrorCategory(str, Enum):
    INVALID_URL = "invalid_url"
    UNSUPPORTED = "unsupported"
    AUTH_REQUIRED = "auth_required"
    PRIVATE = "private"
    DRM = "drm"
    GEO = "geo_blocked"
    UNAVAILABLE = "unavailable"
    FORMAT_UNAVAILABLE = "format_unavailable"
    RATE_LIMIT = "rate_limit"
    NETWORK = "network"
    TIMEOUT = "timeout"
    TOO_LARGE = "too_large"
    DISK_FULL = "disk_full"
    FFMPEG_MISSING = "ffmpeg_missing"
    CANCELLED = "cancelled"
    UNKNOWN = "unknown"

    @property
    def retryable(self) -> bool:
        """Worth retrying on the SAME engine after a short delay."""
        return self in {ErrorCategory.NETWORK, ErrorCategory.TIMEOUT, ErrorCategory.RATE_LIMIT}

    @property
    def fallbackable(self) -> bool:
        """Another compatible engine might succeed."""
        return self in {ErrorCategory.NETWORK, ErrorCategory.TIMEOUT, ErrorCategory.RATE_LIMIT,
                        ErrorCategory.UNSUPPORTED, ErrorCategory.UNKNOWN,
                        ErrorCategory.AUTH_REQUIRED, ErrorCategory.FORMAT_UNAVAILABLE}


_CLASSIFY: list[tuple[re.Pattern, ErrorCategory]] = [(re.compile(p, re.I), c) for p, c in [
    (r"drm", ErrorCategory.DRM),
    (r"unsupported url|no suitable extractor|unable to extract|no video formats? found|no media found", ErrorCategory.UNSUPPORTED),
    (r"sign in to confirm|confirm you.?re not a bot|login required|log in|authentication|cookies|"
     r"members[- ]only|age[- ]restricted|requires? (a )?(login|sign)", ErrorCategory.AUTH_REQUIRED),
    (r"private video|this video is private|private account|is private", ErrorCategory.PRIVATE),
    (r"not available in your country|geo|blocked in your", ErrorCategory.GEO),
    (r"video unavailable|has been removed|no longer available|deleted|does not exist|404", ErrorCategory.UNAVAILABLE),
    (r"requested format is not available|format .* not available", ErrorCategory.FORMAT_UNAVAILABLE),
    (r"429|too many requests|rate.?limit", ErrorCategory.RATE_LIMIT),
    (r"timed? ?out|timeout", ErrorCategory.TIMEOUT),
    (r"no space left|disk full|not enough space", ErrorCategory.DISK_FULL),
    (r"ffmpeg|ffprobe", ErrorCategory.FFMPEG_MISSING),
    (r"connection|network|temporary failure|name resolution|reset by peer|ssl|http error 5\d\d|"
     r"unable to download|incomplete read|getaddrinfo", ErrorCategory.NETWORK),
    (r"larger than max-filesize|file is larger|too large|exceeds", ErrorCategory.TOO_LARGE),
]]


def classify_message(message: str) -> ErrorCategory:
    for pattern, category in _CLASSIFY:
        if pattern.search(message or ""):
            return category
    return ErrorCategory.UNKNOWN


class EngineError(Exception):
    def __init__(self, category: ErrorCategory, message: str = "", engine: str = ""):
        super().__init__(message or category.value)
        self.category = category
        self.message = message or category.value
        self.engine = engine


class CancelToken:
    """Thread-safe cancellation flag; can be chained to a parent token."""

    def __init__(self, parent: "CancelToken | None" = None):
        self._event = threading.Event()
        self._parent = parent

    def cancel(self) -> None:
        self._event.set()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set() or (self._parent is not None and self._parent.cancelled)

    def raise_if_cancelled(self, engine: str = "") -> None:
        if self.cancelled:
            raise EngineError(ErrorCategory.CANCELLED, "cancelled", engine)


@dataclass
class ProgressEvent:
    stage: str                      # downloading | merging | converting
    percent: float | None = None    # None when the engine cannot tell
    downloaded: int | None = None
    total: int | None = None
    speed: float | None = None
    eta: float | None = None


ProgressCallback = Callable[[ProgressEvent], None]


@dataclass
class FormatOption:
    format_id: str
    kind: str                       # video | audio
    ext: str = ""
    height: int | None = None
    abr: float | None = None
    filesize: int | None = None
    has_audio: bool = True


@dataclass
class MediaInfo:
    url: str
    title: str = "Untitled"
    uploader: str | None = None
    duration: float | None = None
    thumbnail: str | None = None
    description: str | None = None
    upload_date: str | None = None
    webpage_url: str | None = None
    platform: str = "unknown"
    is_live: bool = False
    formats: list[FormatOption] = field(default_factory=list)
    filesize_by_height: dict[int, int] = field(default_factory=dict)
    audio_filesize: int | None = None
    engine: str = ""
    media_id: str | None = None

    def heights(self) -> list[int]:
        return sorted({f.height for f in self.formats if f.kind == "video" and f.height}, reverse=True)

    @property
    def has_video(self) -> bool:
        return any(f.kind == "video" for f in self.formats)

    @property
    def has_audio(self) -> bool:
        return any(f.kind == "audio" or f.has_audio for f in self.formats)


@dataclass
class DownloadRequest:
    job_id: str
    url: str
    kind: str                       # video | audio
    out_dir: Path
    height: int | None = None       # None = best available
    audio_format: str = "best"      # best | mp3 | m4a | opus
    container: str = "mp4"
    cookies_file: str | None = None
    max_filesize: int | None = None

    def quality_label(self) -> str:
        if self.kind == "audio":
            return self.audio_format
        return f"{self.height}p" if self.height else "best"


@dataclass
class DownloadResult:
    path: Path
    ext: str
    size: int
    engine: str
    info: MediaInfo | None = None


class BaseEngine(ABC):
    name: str = "base"
    display_name: str = "Base"
    default_priority: int = 100
    supports_video = True
    supports_audio = True
    supports_metadata = True

    def __init__(self, settings: dict[str, Any] | None = None):
        self.settings: dict[str, Any] = dict(settings or {})

    @property
    def timeout(self) -> int:
        return int(self.settings.get("timeout", 1800))

    @abstractmethod
    def is_available(self) -> bool:
        """True when the underlying tool/library is installed and usable."""

    @abstractmethod
    def version(self) -> str:
        """Version string, or 'n/a'."""

    @abstractmethod
    def can_handle(self, url: str) -> bool:
        """Cheap capability check; must not download anything."""

    def supports_kind(self, kind: str) -> bool:
        return self.supports_audio if kind == "audio" else self.supports_video

    @abstractmethod
    async def extract_info(self, url: str, *, cookies_file: str | None = None) -> MediaInfo:
        """Return metadata and available formats or raise EngineError."""

    @abstractmethod
    async def download(self, req: DownloadRequest, progress: ProgressCallback,
                       cancel: CancelToken) -> DownloadResult:
        """Download to req.out_dir or raise EngineError."""
