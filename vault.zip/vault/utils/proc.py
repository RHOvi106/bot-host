"""Run external tools safely: argument lists only, timeouts, cancellation."""
from __future__ import annotations

import asyncio
import time
from typing import Callable

from engines.base import CancelToken, EngineError, ErrorCategory


async def run_process(args: list[str], *, timeout: float, cancel: CancelToken | None = None,
                      engine: str = "", cwd: str | None = None) -> tuple[int, str, str]:
    """Run `args` (never a shell string). Kills the process on timeout or cancel."""
    proc = await asyncio.create_subprocess_exec(
        *args, stdin=asyncio.subprocess.DEVNULL, stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE, cwd=cwd)
    comm = asyncio.ensure_future(proc.communicate())
    deadline = time.monotonic() + timeout
    try:
        while True:
            done, _ = await asyncio.wait({comm}, timeout=0.4)
            if done:
                out, err = comm.result()
                return proc.returncode or 0, out.decode("utf-8", "replace"), err.decode("utf-8", "replace")
            if cancel is not None and cancel.cancelled:
                raise EngineError(ErrorCategory.CANCELLED, "cancelled", engine)
            if time.monotonic() > deadline:
                raise EngineError(ErrorCategory.TIMEOUT, f"process timed out after {int(timeout)}s", engine)
    except BaseException:
        if proc.returncode is None:
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            try:
                await asyncio.wait_for(proc.wait(), 5)
            except Exception:  # noqa: BLE001
                pass
        comm.cancel()
        raise
