"""Small in-memory sliding-window rate limiter."""
from __future__ import annotations

import time
from collections import defaultdict, deque
from typing import Callable


class RateLimiter:
    def __init__(self, limit: int, window_s: float = 60.0, clock: Callable[[], float] = time.monotonic):
        self.limit, self.window, self._clock = limit, window_s, clock
        self._hits: dict[object, deque[float]] = defaultdict(deque)

    def allow(self, key: object) -> bool:
        now = self._clock()
        q = self._hits[key]
        while q and now - q[0] >= self.window:
            q.popleft()
        if len(q) >= self.limit:
            return False
        q.append(now)
        return True

    def retry_after(self, key: object) -> float:
        q = self._hits.get(key)
        if not q or len(q) < self.limit:
            return 0.0
        return max(0.0, self.window - (self._clock() - q[0]))
