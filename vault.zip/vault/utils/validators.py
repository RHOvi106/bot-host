"""URL validation with SSRF protection."""
from __future__ import annotations

import asyncio
import ipaddress
import re
import socket
from urllib.parse import urlsplit, urlunsplit

MAX_URL_LENGTH = 2048
URL_RE = re.compile(r"https?://[^\s<>\"']+", re.IGNORECASE)
BLOCKED_HOSTS = {"localhost", "localhost.localdomain", "ip6-localhost", "ip6-loopback",
                 "metadata.google.internal", "metadata"}
BLOCKED_SUFFIXES = (".local", ".localhost", ".internal", ".lan", ".home.arpa", ".intranet")


class InvalidUrl(ValueError):
    """The URL is malformed or points somewhere we refuse to fetch."""


def extract_urls(text: str) -> list[str]:
    found = []
    for m in URL_RE.findall(text or ""):
        found.append(m.rstrip(".,;:!?)]}>'\""))
    return found


def _public_ip(ip: ipaddress._BaseAddress) -> bool:
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return ip.is_global and not (ip.is_multicast or ip.is_loopback or ip.is_link_local
                                 or ip.is_private or ip.is_reserved or ip.is_unspecified)


def _legacy_ipv4(host: str) -> ipaddress.IPv4Address | None:
    """Catch forms like 2130706433, 0x7f.1, 017700000001."""
    if not re.fullmatch(r"[0-9a-fA-Fx.]+", host):
        return None
    try:
        packed = socket.inet_aton(host)
    except OSError:
        return None
    return ipaddress.IPv4Address(packed)


def validate_url(url: str, *, resolve: bool = False) -> str:
    """Return a normalized http(s) URL or raise InvalidUrl."""
    url = (url or "").strip()
    if not url:
        raise InvalidUrl("empty URL")
    if len(url) > MAX_URL_LENGTH:
        raise InvalidUrl("URL too long")
    if any(ord(c) < 32 for c in url) or " " in url:
        raise InvalidUrl("URL contains whitespace or control characters")
    try:
        parts = urlsplit(url)
        host = parts.hostname
        _ = parts.port
    except ValueError:
        raise InvalidUrl("malformed URL") from None
    if parts.scheme.lower() not in ("http", "https"):
        raise InvalidUrl("only http and https URLs are allowed")
    if not host:
        raise InvalidUrl("URL has no hostname")
    if parts.username or parts.password:
        raise InvalidUrl("URLs with embedded credentials are not allowed")
    host = host.lower().rstrip(".")

    literal = None
    try:
        literal = ipaddress.ip_address(host)
    except ValueError:
        literal = _legacy_ipv4(host)
    if literal is not None:
        if not _public_ip(literal):
            raise InvalidUrl("private or reserved addresses are not allowed")
    else:
        if host in BLOCKED_HOSTS or host.endswith(BLOCKED_SUFFIXES):
            raise InvalidUrl("local hostnames are not allowed")
        if "." not in host:
            raise InvalidUrl("hostname must contain a dot")
        try:
            host.encode("idna")
        except UnicodeError:
            raise InvalidUrl("invalid hostname") from None
        if resolve:
            try:
                infos = socket.getaddrinfo(host, None)
            except socket.gaierror:
                raise InvalidUrl("hostname could not be resolved") from None
            for info in infos:
                if not _public_ip(ipaddress.ip_address(info[4][0])):
                    raise InvalidUrl("hostname resolves to a private address")

    return urlunsplit((parts.scheme.lower(), parts.netloc, parts.path, parts.query, ""))


async def validate_url_async(url: str) -> str:
    return await asyncio.to_thread(validate_url, url, resolve=True)


def host_of(url: str) -> str:
    try:
        h = (urlsplit(url).hostname or "").lower()
    except ValueError:
        return ""
    return h[4:] if h.startswith("www.") else h


def platform_of(url: str) -> str:
    """Short platform label from the hostname (e.g. youtube.com -> youtube)."""
    h = host_of(url)
    if not h:
        return "unknown"
    parts = h.split(".")
    if len(parts) >= 3 and parts[-2] in {"co", "com", "org", "net", "ac"} and len(parts[-1]) == 2:
        return parts[-3]
    return parts[-2] if len(parts) >= 2 else h
