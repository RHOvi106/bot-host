"""Protect stored API keys. Uses Fernet when `cryptography` + SECRET_KEY are available,
otherwise stores a clearly-marked plain value (still never shown to normal users)."""
from __future__ import annotations

import base64
import hashlib
import logging

log = logging.getLogger(__name__)


def fingerprint(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()[:16]


def mask(value: str) -> str:
    if len(value) <= 8:
        return "****"
    return f"{value[:4]}…{value[-3:]}"


class SecretBox:
    def __init__(self, secret_key: str = ""):
        self._fernet = None
        if secret_key:
            try:
                from cryptography.fernet import Fernet  # type: ignore

                digest = hashlib.sha256(secret_key.encode()).digest()
                self._fernet = Fernet(base64.urlsafe_b64encode(digest))
            except ImportError:
                log.warning("SECRET_KEY set but 'cryptography' not installed; keys stored unencrypted")

    @property
    def encrypted(self) -> bool:
        return self._fernet is not None

    def encrypt(self, value: str) -> str:
        if self._fernet:
            return "enc:" + self._fernet.encrypt(value.encode()).decode()
        return "plain:" + value

    def decrypt(self, stored: str) -> str:
        if stored.startswith("plain:"):
            return stored[6:]
        if stored.startswith("enc:"):
            if not self._fernet:
                raise ValueError("stored key is encrypted but SECRET_KEY/cryptography is unavailable")
            return self._fernet.decrypt(stored[4:].encode()).decode()
        return stored
