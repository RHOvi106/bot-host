"""Telegram error classes (real ones when python-telegram-bot is installed, light stand-ins otherwise)."""
from __future__ import annotations

try:
    from telegram.error import BadRequest, Forbidden, NetworkError, RetryAfter, TelegramError, TimedOut
    PTB_AVAILABLE = True
except ImportError:                                   # pragma: no cover - only without PTB installed
    PTB_AVAILABLE = False

    class TelegramError(Exception):
        pass

    class NetworkError(TelegramError):
        pass

    class TimedOut(NetworkError):
        pass

    class BadRequest(TelegramError):
        pass

    class Forbidden(TelegramError):
        pass

    class RetryAfter(TelegramError):
        def __init__(self, retry_after):
            super().__init__(f"Flood control, retry in {retry_after}s")
            self.retry_after = retry_after


def retry_seconds(exc: BaseException) -> float:
    """RetryAfter.retry_after is int in old PTB and timedelta in newer ones."""
    value = getattr(exc, "retry_after", 1)
    total = getattr(value, "total_seconds", None)
    return float(total() if callable(total) else value)


__all__ = ["BadRequest", "Forbidden", "NetworkError", "RetryAfter", "TelegramError", "TimedOut",
           "PTB_AVAILABLE", "retry_seconds"]
