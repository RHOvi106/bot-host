"""Admin authorization. Every admin command AND callback is checked independently."""
from __future__ import annotations

import functools
import logging
from typing import Any, Awaitable, Callable

log = logging.getLogger(__name__)


def user_id_of(update: Any) -> int | None:
    user = getattr(update, "effective_user", None)
    return getattr(user, "id", None)


def is_admin_update(update: Any, admin_ids: frozenset[int]) -> bool:
    uid = user_id_of(update)
    return isinstance(uid, int) and uid in admin_ids


def admin_only(func: Callable[..., Awaitable[Any]]):
    """Decorator for PTB handlers: (update, context). Silently refuses non-admins."""

    @functools.wraps(func)
    async def wrapper(update, context, *args, **kwargs):
        settings = context.application.bot_data["settings"]
        if not is_admin_update(update, settings.admin_ids):
            uid = user_id_of(update)
            log.warning("Blocked unauthorized admin access by user %s", uid)
            query = getattr(update, "callback_query", None)
            if query is not None:
                try:
                    await query.answer("Not allowed.", show_alert=True)
                except Exception:  # noqa: BLE001
                    pass
            return None
        return await func(update, context, *args, **kwargs)

    return wrapper
