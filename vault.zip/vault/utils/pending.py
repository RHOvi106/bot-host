"""Short-lived server-side store so callback_data stays under Telegram's 64-byte limit."""
from __future__ import annotations

import secrets
import time
from typing import Any, Callable


class PendingStore:
    def __init__(self, ttl: float = 1800, max_items: int = 2000, clock: Callable[[], float] = time.monotonic):
        self.ttl, self.max_items, self._clock = ttl, max_items, clock
        self._d: dict[str, tuple[float, Any]] = {}

    def put(self, value: Any) -> str:
        self._purge()
        token = secrets.token_hex(4)
        while token in self._d:
            token = secrets.token_hex(4)
        self._d[token] = (self._clock(), value)
        return token

    def get(self, token: str) -> Any | None:
        item = self._d.get(token)
        if not item or self._clock() - item[0] > self.ttl:
            self._d.pop(token, None)
            return None
        return item[1]

    def pop(self, token: str) -> Any | None:
        v = self.get(token)
        self._d.pop(token, None)
        return v

    def _purge(self) -> None:
        now = self._clock()
        for k in [k for k, (t, _) in self._d.items() if now - t > self.ttl]:
            del self._d[k]
        while len(self._d) >= self.max_items:
            self._d.pop(next(iter(self._d)))
