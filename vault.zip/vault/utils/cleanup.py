"""Temporary-file cleanup and disk-space checks."""
from __future__ import annotations

import logging
import shutil
import time
from pathlib import Path

from engines.base import EngineError, ErrorCategory

log = logging.getLogger(__name__)


def remove_dir(path: Path) -> None:
    shutil.rmtree(path, ignore_errors=True)


def sweep_old(directory: Path, max_age_hours: float, *, now: float | None = None) -> int:
    """Delete direct children of `directory` older than max_age_hours. Returns count removed."""
    directory = Path(directory)
    if not directory.is_dir():
        return 0
    now = now or time.time()
    cutoff = now - max_age_hours * 3600
    removed = 0
    for child in directory.iterdir():
        try:
            if child.stat().st_mtime < cutoff:
                shutil.rmtree(child, ignore_errors=True) if child.is_dir() else child.unlink(missing_ok=True)
                removed += 1
        except OSError:
            log.warning("could not remove %s", child)
    return removed


def clear_directory(directory: Path) -> int:
    """Remove everything inside `directory` (startup cleanup of abandoned jobs)."""
    return sweep_old(directory, -1)


def ensure_free_space(directory: Path, needed_bytes: int, reserve_bytes: int = 300 * 1024 * 1024) -> None:
    Path(directory).mkdir(parents=True, exist_ok=True)
    free = shutil.disk_usage(directory).free
    if free < needed_bytes + reserve_bytes:
        raise EngineError(ErrorCategory.DISK_FULL,
                          f"only {free // (1024 * 1024)} MB free, need ~{needed_bytes // (1024 * 1024)} MB")


def dir_size(directory: Path) -> int:
    total = 0
    for p in Path(directory).rglob("*"):
        try:
            if p.is_file():
                total += p.stat().st_size
        except OSError:
            pass
    return total
