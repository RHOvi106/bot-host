"""Filename safety and path-traversal protection."""
from __future__ import annotations

import os
import re
import unicodedata
from pathlib import Path

_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)),
             *(f"LPT{i}" for i in range(1, 10))}
_BAD = re.compile(r'[<>:"/\\|?*\x00-\x1f\x7f]')


def safe_filename(name: str, *, max_len: int = 100, default: str = "media") -> str:
    """Make `name` safe on Windows/Linux. Keeps the extension when truncating."""
    name = unicodedata.normalize("NFKC", name or "")
    name = _BAD.sub("_", name)
    name = re.sub(r"\s+", " ", name).strip(" .")
    stem, ext = os.path.splitext(name)
    if len(ext) > 10:
        stem, ext = name, ""
    stem = stem.strip(" .")
    if stem.upper() in _RESERVED:
        stem = f"_{stem}"
    if not stem:
        stem = default
    room = max(1, max_len - len(ext))
    return stem[:room].rstrip(" .") + ext


def ensure_within(base: Path, candidate: Path) -> Path:
    """Return resolved candidate, or raise ValueError if it escapes `base`."""
    base_r = Path(base).resolve()
    cand_r = Path(candidate).resolve()
    try:
        cand_r.relative_to(base_r)
    except ValueError:
        raise ValueError(f"path escapes base directory: {candidate}") from None
    return cand_r


def unique_path(directory: Path, filename: str) -> Path:
    directory = Path(directory)
    stem, ext = os.path.splitext(safe_filename(filename))
    path = directory / f"{stem}{ext}"
    n = 1
    while path.exists():
        path = directory / f"{stem} ({n}){ext}"
        n += 1
    return path
