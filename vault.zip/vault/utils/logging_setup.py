"""Structured, rotating logging with secret redaction."""
from __future__ import annotations

import logging
import re
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

_PATTERNS = [
    re.compile(r"bot\d{5,}:[A-Za-z0-9_-]{20,}"),
    re.compile(r"\b\d{6,}:[A-Za-z0-9_-]{30,}\b"),
    re.compile(r"(?i)(api[_-]?key|key|token|authorization|client_id|access_token)=([^&\s'\"]+)"),
    re.compile(r"(?i)(Bearer|Api-Key|Client-ID)\s+[A-Za-z0-9._~+/=-]{8,}"),
    re.compile(r"\bAIza[0-9A-Za-z_-]{20,}\b"),
    re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b"),
]


class SecretFilter(logging.Filter):
    """Redacts known secrets and token-like strings from every log record."""

    def __init__(self, secrets: list[str] | None = None):
        super().__init__()
        self._secrets = [s for s in (secrets or []) if s and len(s) >= 6]

    def add_secret(self, s: str) -> None:
        if s and len(s) >= 6 and s not in self._secrets:
            self._secrets.append(s)

    def redact(self, text: str) -> str:
        for s in self._secrets:
            text = text.replace(s, "[REDACTED]")
        for p in _PATTERNS:
            if p.groups >= 2 and p.pattern.startswith("(?i)(api"):
                text = p.sub(lambda m: f"{m.group(1)}=[REDACTED]", text)
            else:
                text = p.sub("[REDACTED]", text)
        return text

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:  # noqa: BLE001
            return True
        record.msg = self.redact(msg)
        record.args = ()
        if record.exc_info:
            record.exc_text = self.redact(logging.Formatter().formatException(record.exc_info))
            record.exc_info = None
        return True


def setup_logging(log_dir: Path, level: str = "INFO", secrets: list[str] | None = None) -> SecretFilter:
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    flt = SecretFilter(secrets)
    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    root = logging.getLogger()
    root.setLevel(level)
    for h in list(root.handlers):
        root.removeHandler(h)
    file_h = RotatingFileHandler(log_dir / "bot.log", maxBytes=5_000_000, backupCount=5, encoding="utf-8")
    console = logging.StreamHandler(sys.stdout)
    for h in (file_h, console):
        h.setFormatter(fmt)
        h.addFilter(flt)
        root.addHandler(h)
    # httpx logs full URLs (including bot tokens) at INFO.
    for noisy in ("httpx", "httpcore", "telegram.ext", "apscheduler"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    return flt
