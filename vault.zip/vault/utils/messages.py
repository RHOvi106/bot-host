"""User-facing messages. Never expose engine names, tracebacks or raw library errors."""
from __future__ import annotations

from engines.base import ErrorCategory

_FRIENDLY = {
    ErrorCategory.INVALID_URL: "That doesn't look like a valid public link. Please send a full http(s) link.",
    ErrorCategory.UNSUPPORTED: "I couldn't find downloadable media at this link, or the site isn't supported.",
    ErrorCategory.AUTH_REQUIRED: "The site is asking for sign-in or verification for this link, so I can't fetch it right now. "
                                 "Please try again later or send a different link.",
    ErrorCategory.PRIVATE: "This content is private, so I can't download it.",
    ErrorCategory.DRM: "This content is DRM-protected and can't be downloaded.",
    ErrorCategory.GEO: "This content isn't available in the server's region.",
    ErrorCategory.UNAVAILABLE: "This content is unavailable or has been removed.",
    ErrorCategory.FORMAT_UNAVAILABLE: "That quality isn't available for this media. Please pick another option.",
    ErrorCategory.RATE_LIMIT: "The source is busy right now. Please try again in a few minutes.",
    ErrorCategory.NETWORK: "Network problem while fetching the media. Please try again shortly.",
    ErrorCategory.TIMEOUT: "The download took too long and was stopped. Try a lower quality.",
    ErrorCategory.TOO_LARGE: "This file is larger than the limit I can handle. Try a lower quality or audio only.",
    ErrorCategory.DISK_FULL: "The server is low on storage right now. The admin has been notified; please try later.",
    ErrorCategory.FFMPEG_MISSING: "Media conversion tools aren't available on the server for this option. "
                                  "Try 'Original audio' or another quality.",
    ErrorCategory.CANCELLED: "Download cancelled.",
    ErrorCategory.UNKNOWN: "I couldn't complete this download. The details were saved for the admin. "
                           "Please try again or use another quality.",
}


def friendly(category: ErrorCategory | str) -> str:
    if not isinstance(category, ErrorCategory):
        try:
            category = ErrorCategory(category)
        except ValueError:
            category = ErrorCategory.UNKNOWN
    return _FRIENDLY[category]
