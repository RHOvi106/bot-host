"""Access gate (registration, blocks, maintenance, rate limit, force-subscribe) and onboarding."""
from __future__ import annotations

import logging

from telegram import Update
from telegram.ext import ApplicationHandlerStop, ContextTypes

from keyboards.menus import join_keyboard, main_menu
from services.referral_service import parse_start_payload
from .common import deps, esc, notify_admins

log = logging.getLogger(__name__)

PRIVACY = ("🔒 <b>Privacy</b>\nTo run this bot I store your Telegram ID, name, the links you send and download "
           "history/statistics. The owner may review activity for support and abuse prevention. "
           "I never ask for passwords, and I only help with content you are allowed to access. "
           "AI chats are stored briefly (last messages) to keep context; use ⚙️ Settings → Clear AI chat to erase them.")


def welcome_text(settings, first_name: str) -> str:
    return (f"👋 Hello <b>{esc(first_name)}</b>!\n\nI'm the official assistant of <b>{esc(settings.owner_name)}</b>.\n"
            f"📥 Send me a link and choose the quality, or use the menu below.\n"
            f"🔎 Search YouTube • 🖼 free stock photos/videos • 🤖 ask the AI assistant.\n\n"
            f"<i>Only download content you have the right to access. Type /privacy for data info.</i>")


async def gate(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Runs before every handler (group -1)."""
    user, chat = update.effective_user, update.effective_chat
    if user is None or chat is None or user.is_bot:
        raise ApplicationHandlerStop
    if chat.type != "private":
        raise ApplicationHandlerStop
    d = deps(context)
    s, repo = d["settings"], d["repo"]
    row, is_new = await repo.upsert_user(user.id, user.username, user.first_name)
    admin = s.is_admin(user.id)
    query = update.callback_query

    if is_new and update.message and (update.message.text or "").startswith("/start"):
        payload = parse_start_payload((update.message.text or "").split()[1:])
        await d["referrals"].register(user.id, payload)
    if is_new:
        await d["activity"].record({"user_id": user.id, "first_name": user.first_name, "username": user.username},
                                   "new user", "")

    async def tell(text: str, **kw):
        if query:
            await query.answer(text[:190], show_alert=True)
        elif update.effective_message:
            await update.effective_message.reply_text(text, parse_mode="HTML", **kw)

    if row["is_blocked"] and not admin:
        await tell("🚫 You are blocked from using this bot.")
        raise ApplicationHandlerStop
    if not admin and await repo.get_bool_setting("maintenance", False):
        await tell("🛠 The bot is under maintenance. Please try again soon.")
        raise ApplicationHandlerStop
    if admin:
        return
    if not d["rate_limiter"].allow(user.id):
        wait = int(d["rate_limiter"].retry_after(user.id)) + 1
        await tell(f"⏳ Too many requests. Please wait {wait}s.")
        raise ApplicationHandlerStop

    is_check = bool(query and query.data == "fs:check")
    missing = await d["force_sub"].missing(context.bot, user.id, use_cache=not is_check)
    if missing:
        if is_check:
            await query.answer("You haven't joined all channels yet.", show_alert=True)
        else:
            await update.effective_message.reply_text(
                "📢 Please join our channel(s) to use the bot, then tap <b>I've joined</b>.",
                parse_mode="HTML", reply_markup=join_keyboard(missing))
        raise ApplicationHandlerStop
    if not row["fs_verified"]:
        await repo.set_fs_verified(user.id, True)
        result = await d["referrals"].confirm(user.id)
        if result:
            referrer, granted = result
            msg = ("🎉 A friend joined with your link!" + (" You earned <b>Premium</b>! 💎" if granted else ""))
            try:
                await context.bot.send_message(referrer, msg, parse_mode="HTML")
            except Exception:  # noqa: BLE001
                pass
    if is_check:
        await query.answer("✅ Thanks for joining!")
        await context.bot.send_message(chat.id, welcome_text(s, user.first_name), parse_mode="HTML",
                                       reply_markup=main_menu())
        raise ApplicationHandlerStop


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    s = deps(context)["settings"]
    context.user_data.pop("mode", None)
    await update.message.reply_text(welcome_text(s, update.effective_user.first_name), parse_mode="HTML",
                                    reply_markup=main_menu())


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "ℹ️ <b>How to use</b>\n1️⃣ Paste a link\n2️⃣ Pick video quality or audio format\n3️⃣ Wait for the file\n\n"
        "• /cancel – stop the current input mode\n• /privacy – what data is stored\n"
        "• Large files are split into parts automatically.", parse_mode="HTML", reply_markup=main_menu())


async def privacy(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(PRIVACY, parse_mode="HTML")


async def cancel_mode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.pop("mode", None)
    context.user_data.pop("admin_wait", None)
    await update.message.reply_text("OK, cancelled.", reply_markup=main_menu())
