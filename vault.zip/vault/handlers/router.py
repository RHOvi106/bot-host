"""Routes plain text: admin input -> menu buttons -> links -> active modes."""
from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes

from keyboards import menus as m
from utils.validators import extract_urls
from . import admin, features, user
from .common import deps
from .download import process_url

_BUTTONS = {
    m.B_AI: features.enter_ai, m.B_YOUTUBE: features.enter_youtube, m.B_STOCK: features.enter_stock,
    m.B_HISTORY: user.history, m.B_STATS: user.stats, m.B_PROFILE: user.profile, m.B_REFER: user.refer,
    m.B_SETTINGS: user.settings, m.B_SUPPORT: user.support,
}


async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = (update.message.text or "").strip()
    d = deps(context)
    uid = update.effective_user.id

    if d["settings"].is_admin(uid) and context.user_data.get("admin_wait"):
        if await admin.handle_admin_input(update, context, text):
            return

    if text == m.B_DOWNLOAD:
        context.user_data["mode"] = "video"
        await update.message.reply_text("📥 Paste the link of the video/media you want.")
        return
    if text == m.B_AUDIO:
        context.user_data["mode"] = "audio"
        await update.message.reply_text("🎵 Paste a link and I'll offer audio formats.")
        return
    handler = _BUTTONS.get(text)
    if handler:
        context.user_data.pop("mode", None)
        await handler(update, context)
        return

    urls = extract_urls(text)
    if urls:
        await process_url(update.message, context, update.effective_user, urls[0])
        return

    mode = context.user_data.get("mode")
    if mode == "ai":
        await features.ai_message(update, context, text)
    elif mode == "yt":
        await features.youtube_query(update, context, text)
    elif isinstance(mode, str) and mode.startswith("stock:"):
        await features.stock_search(update.message, context, update.effective_user, mode.split(":", 1)[1], text[:100])
    else:
        await update.message.reply_text("Send me a link 🔗 or choose an option from the menu below.", reply_markup=m.main_menu())
