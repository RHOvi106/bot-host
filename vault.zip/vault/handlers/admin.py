"""Admin panel. Every entry point is wrapped in @admin_only; sensitive actions need confirmation."""
from __future__ import annotations

import asyncio
import csv
import io
import logging
import platform
import shutil
import sys
import time
from pathlib import Path

from telegram import InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from ai.ai_manager import PROVIDERS
from keyboards.menus import ibtn
from services import media_service
from services.metadata_service import human_size
from utils import cleanup
from utils.auth import admin_only
from utils.secrets_box import mask
from utils.tg_compat import Forbidden, RetryAfter, TelegramError, retry_seconds
from .common import deps, esc, fmt_date, safe_edit

log = logging.getLogger(__name__)

KEY_SERVICES = ["pixabay", "unsplash", "youtube", "gemini", "groq", "openai", "openrouter"]
FEATURES = ["ai", "stock", "youtube", "referral", "watermark"]
LIMITS = {  # key: (label, min, max, step, default-getter)
    "limit.per_user": ("Parallel jobs per user", 1, 5, 1),
    "limit.queue": ("Max waiting jobs", 5, 500, 5),
    "limit.retries": ("Retries per engine", 0, 5, 1),
    "limit.engine_timeout": ("Engine timeout (s)", 60, 7200, 60),
    "limit.free_daily": ("Free downloads / day", 1, 200, 1),
}


def kb(rows: list[list]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(rows)


BACK = [ibtn("⬅️ Admin menu", "adm:home")]


def home_keyboard() -> InlineKeyboardMarkup:
    b = lambda t, d, st=None: ibtn(t, d, style=st)  # noqa: E731
    return kb([
        [b("📊 Dashboard", "adm:dash", "primary"), b("⚙️ Engines", "adm:eng", "primary")],
        [b("🧮 Limits", "adm:lim", "primary"), b("🏃 Jobs", "adm:jobs", "primary")],
        [b("🐞 Errors", "adm:err"), b("👥 Users", "adm:users")],
        [b("📣 Broadcast", "adm:bc", "success"), b("🔑 API keys", "adm:keys", "primary")],
        [b("🤖 AI", "adm:ai", "primary"), b("📢 Channels", "adm:ch")],
        [b("🎛 Features", "adm:ft"), b("📤 Export", "adm:exp")],
        [b("🧹 Cleanup", "adm:cl"), b("🧾 Audit log", "adm:audit")],
        [b("🧩 Versions", "adm:ver"), b("📑 Sheets sync", "adm:sheets")],
        [b("🍪 Cookies", "adm:cookies"), b("🛠 Maintenance", "adm:maint", "danger")],
    ])


async def apply_runtime(app) -> None:
    """Apply admin-tuned limits to live components (also called at startup)."""
    d, repo = app.bot_data, app.bot_data["repo"]
    s = d["settings"]
    d["queue"].per_user = await repo.get_int_setting("limit.per_user", s.per_user_concurrency)
    d["queue"].max_size = await repo.get_int_setting("limit.queue", s.max_queue_size)
    d["fallback"].max_retries = await repo.get_int_setting("limit.retries", s.max_retries)
    d["fallback"].engine_timeout = await repo.get_int_setting("limit.engine_timeout", s.engine_timeout_s)


@admin_only
async def admin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("🛡 <b>Admin panel</b>", parse_mode="HTML", reply_markup=home_keyboard())


async def _show(query, text: str, rows: list[list] | None = None) -> None:
    rows = (rows or []) + [BACK]
    await safe_edit(query.message, text, reply_markup=kb(rows), disable_web_page_preview=True)


@admin_only
async def on_admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    d = deps(context)
    uid = update.effective_user.id
    if not d["admin_limiter"].allow(uid):
        await query.answer("Slow down a little.", show_alert=True)
        return
    parts = query.data.split(":")
    section = parts[1] if len(parts) > 1 else "home"
    args = parts[2:]
    handler = _SECTIONS.get(section)
    await query.answer()
    if handler is None:
        return
    try:
        await handler(query, context, uid, args)
    except TelegramError as exc:
        log.warning("admin UI error: %s", exc)


# ---------------- sections ----------------
async def s_home(query, context, uid, args):
    context.user_data.pop("admin_wait", None)
    await safe_edit(query.message, "🛡 <b>Admin panel</b>", reply_markup=home_keyboard())


async def s_dash(query, context, uid, args):
    d = deps(context); repo = d["repo"]
    st = await repo.global_stats()
    now = int(time.time())
    a24, a7 = await repo.count_active_users(now - 86400), await repo.count_active_users(now - 7 * 86400)
    q = d["queue"].snapshot()
    free = shutil.disk_usage(d["settings"].temp_dir).free
    plat = ", ".join(f"{r['name']} {r['n']}" for r in (await repo.counts_by("platform"))[:5]) or "—"
    text = (f"📊 <b>Dashboard</b>\n👥 Users: {st['users']} (24h: {a24}, 7d: {a7})\n"
            f"⬇️ Downloads: {st['total']} — ✅ {st['done']} ❌ {st['failed']} 🛑 {st['cancelled']}\n"
            f"🎬 {st['video']}  🎵 {st['audio']}  💾 {human_size(st['bytes'])}\n"
            f"⏱ Avg time: {st['avg_seconds'] or 0:.1f}s\n🏃 Running {q['running']} · queued {q['queued']}\n"
            f"💽 Free disk: {human_size(free)}\n🌐 Top platforms: {esc(plat)}\n"
            f"🛠 Maintenance: {'ON' if await repo.get_bool_setting('maintenance', False) else 'off'}")
    await _show(query, text)


async def s_eng(query, context, uid, args):
    d = deps(context); reg = d["registry"]
    if args and args[0] in ("t", "up") and len(args) > 1:
        name = args[1]
        if args[0] == "t":
            reg.set_enabled(name, not reg.is_enabled(name))
        else:
            order = [r["name"] for r in reg.describe()]
            if name in order and order.index(name) > 0:
                above = order[order.index(name) - 1]
                pa, pb = reg.priority(above), reg.priority(name)
                if pa == pb:
                    pb = pa + 1
                reg.set_priority(name, pa); reg.set_priority(above, pb)
        await d["repo"].audit(uid, "engine", " ".join(args))
    lines, rows = ["⚙️ <b>Engines</b> (top = tried first)"], []
    for e in reg.describe():
        state = "✅" if e["enabled"] else "⛔"
        avail = "installed" if e["available"] else "not installed"
        lines.append(f"{state} <b>{esc(e['display_name'])}</b> v{esc(e['version'])} · {avail} · prio {e['priority']}\n"
                     f"    ok {e['success']} / fail {e['failures']}" + (f" · last: {esc((e['last_error'] or '')[:60])}" if e['last_error'] else ""))
        rows.append([ibtn(f"{'Disable' if e['enabled'] else 'Enable'} {e['name']}", f"adm:eng:t:{e['name']}"),
                     ibtn("⬆️", f"adm:eng:up:{e['name']}")])
    await _show(query, "\n".join(lines), rows)


async def s_lim(query, context, uid, args):
    d = deps(context); repo = d["repo"]; s = d["settings"]
    if len(args) == 2 and args[0] in LIMITS and args[1] in ("+", "-"):
        _, lo, hi, step = LIMITS[args[0]]
        cur = await repo.get_int_setting(args[0], _default_limit(s, args[0]))
        new = max(lo, min(hi, cur + step if args[1] == "+" else cur - step))
        await repo.set_setting(args[0], new)
        await repo.audit(uid, "limit", f"{args[0]}={new}")
        await apply_runtime(context.application)
    lines, rows = ["🧮 <b>Limits</b> (applied instantly)"], []
    for key, (label, *_rest) in LIMITS.items():
        cur = await repo.get_int_setting(key, _default_limit(s, key))
        lines.append(f"• {label}: <b>{cur}</b>")
        rows.append([ibtn(f"➖ {label}", f"adm:lim:{key}:-"), ibtn("➕", f"adm:lim:{key}:+")])
    lines.append(f"\n<i>Set in .env (restart needed): max file {s.max_file_size_mb} MB, upload limit {s.upload_limit_mb} MB, "
                 f"workers {s.max_concurrent_downloads}</i>")
    await _show(query, "\n".join(lines), rows)


def _default_limit(s, key: str) -> int:
    return {"limit.per_user": s.per_user_concurrency, "limit.queue": s.max_queue_size, "limit.retries": s.max_retries,
            "limit.engine_timeout": s.engine_timeout_s, "limit.free_daily": s.free_daily_downloads}[key]


async def s_jobs(query, context, uid, args):
    d = deps(context)
    if len(args) == 2 and args[0] == "c":
        ok = d["queue"].cancel(args[1], is_admin=True)
        await d["repo"].audit(uid, "cancel job", args[1])
    jobs = [j for j in d["queue"]._jobs.values() if j.status in ("queued", "running")]
    if not jobs:
        await _show(query, "🏃 No active jobs.")
        return
    lines, rows = ["🏃 <b>Active jobs</b>"], []
    for j in jobs[:15]:
        lines.append(f"{'▶️' if j.status == 'running' else '⏳'} <code>{j.job_id}</code> u{j.user_id} {j.kind} {esc(j.quality)} "
                     f"[{esc(j.engine or '-')}]\n    {esc(j.url[:60])}")
        rows.append([ibtn(f"🛑 Cancel {j.job_id}", f"adm:jobs:c:{j.job_id}", style="danger")])
    await _show(query, "\n".join(lines), rows)


async def s_err(query, context, uid, args):
    repo = deps(context)["repo"]
    errs = await repo.recent_errors(10)
    cats = await repo.counts_by("error_category")
    lines = ["🐞 <b>Recent errors</b>"]
    for e in errs:
        lines.append(f"• {time.strftime('%m-%d %H:%M', time.gmtime(e['ts']))} u{e['user_id'] or '-'} <b>{esc(e['category'])}</b>: "
                     f"{esc((e['message'] or '')[:90])}")
    if cats:
        lines.append("\n<b>By category</b>: " + ", ".join(f"{esc(r['name'])} {r['n']}" for r in cats[:8]))
    await _show(query, "\n".join(lines) if errs else "🐞 No errors recorded 🎉")


async def s_users(query, context, uid, args):
    context.user_data["admin_wait"] = None
    repo = deps(context)["repo"]
    text = f"👥 <b>Users</b>: {await repo.count_users()}\nChoose an action, then send the numeric user ID."
    await _show(query, text, [[ibtn("🚫 Block", "adm:uw:block", style="danger"), ibtn("✅ Unblock", "adm:uw:unblock")],
                              [ibtn("🔍 User info", "adm:uw:uinfo"), ibtn("💎 Grant premium", "adm:uw:grant")]])


async def s_uw(query, context, uid, args):
    context.user_data["admin_wait"] = (args[0], None)
    await safe_edit(query.message, f"Send the numeric user ID for <b>{esc(args[0])}</b> (or /cancel).", reply_markup=kb([BACK]))


async def s_cf(query, context, uid, args):
    action, arg = args[0], ":".join(args[1:])
    await safe_edit(query.message, f"⚠️ Confirm <b>{esc(action)}</b> → <code>{esc(arg)}</code>?",
                    reply_markup=kb([[ibtn("✅ Yes", f"adm:do:{action}:{arg}", style="danger"), ibtn("❌ No", "adm:home")]]))


async def s_do(query, context, uid, args):
    d = deps(context); repo = d["repo"]
    action, arg = args[0], ":".join(args[1:])
    if action == "block":
        target = int(arg)
        if target in d["settings"].admin_ids:
            await _show(query, "Admins can't be blocked.")
            return
        await repo.set_blocked(target, True)
        msg = f"🚫 Blocked {target}"
    elif action == "delkey":
        await repo.delete_api_key(int(arg)); msg = "🗑 Key deleted"
    elif action == "rmch":
        await repo.remove_channel(arg); msg = f"🗑 Removed {arg}"
    elif action == "cleannow":
        removed = await asyncio.to_thread(cleanup.sweep_old, d["settings"].temp_dir, 1)
        msg = f"🧹 Removed {removed} stale temp item(s)"
    else:
        return
    await repo.audit(uid, action, arg)
    await _show(query, msg)


async def s_bc(query, context, uid, args):
    d = deps(context)
    if args and args[0] == "go":
        data = d["pending"].pop(args[1])
        if not data:
            await _show(query, "Broadcast expired.")
            return
        await repo_audit(d, uid, "broadcast", data["text"][:100])
        task = asyncio.create_task(_run_broadcast(context.application, query.message, data["text"]))
        d.setdefault("_tasks", set()).add(task)
        task.add_done_callback(d["_tasks"].discard)
        return
    context.user_data["admin_wait"] = ("bc", None)
    await safe_edit(query.message, "📣 Send the broadcast text (HTML allowed). You'll see a preview first. /cancel to abort.",
                    reply_markup=kb([BACK]))


async def repo_audit(d, uid, action, detail=""):
    await d["repo"].audit(uid, action, detail)


async def _run_broadcast(app, status_msg, text: str) -> None:
    d = app.bot_data
    ids = await d["repo"].all_user_ids()
    sent = failed = 0
    for i, uid in enumerate(ids, 1):
        try:
            await app.bot.send_message(uid, text, parse_mode="HTML")
            sent += 1
        except RetryAfter as exc:
            await asyncio.sleep(retry_seconds(exc) + 1)
            try:
                await app.bot.send_message(uid, text, parse_mode="HTML"); sent += 1
            except TelegramError:
                failed += 1
        except (Forbidden, TelegramError):
            failed += 1
        await asyncio.sleep(0.05)       # ~20 msg/s, below Telegram's broadcast limit
        if i % 50 == 0:
            await safe_edit(status_msg, f"📣 Sending… {i}/{len(ids)}")
    await safe_edit(status_msg, f"📣 Broadcast finished. ✅ {sent} sent, ❌ {failed} failed.", reply_markup=kb([BACK]))


async def s_keys(query, context, uid, args):
    d = deps(context); repo = d["repo"]; box = d["key_bank"].box
    if not args:
        rows, lines = [], ["🔑 <b>API key bank</b>" + ("" if box.encrypted else "\n<i>Keys stored unencrypted (set SECRET_KEY + install cryptography).</i>")]
        for svc in KEY_SERVICES:
            n = len(await repo.list_api_keys(svc)); usable = len(await repo.available_api_keys(svc))
            lines.append(f"• {svc}: {n} key(s), {usable} usable")
            rows.append([ibtn(f"{svc} ({n})", f"adm:keys:svc:{svc}")])
        await _show(query, "\n".join(lines), rows)
        return
    if args[0] == "svc":
        svc = args[1]; keys = await repo.list_api_keys(svc)
        lines, rows = [f"🔑 <b>{esc(svc)}</b>"], []
        for k in keys:
            try:
                shown = mask(box.decrypt(k["key_enc"]))
            except Exception:  # noqa: BLE001
                shown = "(unreadable)"
            cool = f" ⏳ until {time.strftime('%H:%M', time.gmtime(k['cooldown_until']))}Z" if k["cooldown_until"] > time.time() else ""
            lines.append(f"#{k['id']} <code>{esc(shown)}</code> {'✅' if k['enabled'] else '⛔'}{cool} calls {k['calls']} fails {k['failures']}"
                         + (f"\n    {esc(k['last_error'])}" if k["last_error"] else ""))
            rows.append([ibtn(f"{'Disable' if k['enabled'] else 'Enable'} #{k['id']}", f"adm:keys:t:{k['id']}:{svc}"),
                         ibtn(f"🗑 #{k['id']}", f"adm:cf:delkey:{k['id']}", style="danger")])
        rows.append([ibtn("➕ Add key", f"adm:keys:add:{svc}", style="success")])
        rows.append([ibtn("⬅️ Keys", "adm:keys")])
        await _show(query, "\n".join(lines), rows)
    elif args[0] == "t":
        key = next((k for k in await repo.list_api_keys(args[2]) if k["id"] == int(args[1])), None)
        if key:
            await repo.set_key_enabled(key["id"], not key["enabled"])
            await repo.audit(uid, "key toggle", f"{args[2]}#{key['id']}")
        await s_keys(query, context, uid, ["svc", args[2]])
    elif args[0] == "add":
        context.user_data["admin_wait"] = ("addkey", args[1])
        await safe_edit(query.message, f"Send the API key for <b>{esc(args[1])}</b>. I'll delete your message right away. /cancel to abort.",
                        reply_markup=kb([BACK]))


async def s_ai(query, context, uid, args):
    d = deps(context); ai = d["ai"]
    if args and args[0] == "p" and args[1] in PROVIDERS:
        await ai.set_provider(args[1]); await d["repo"].audit(uid, "ai provider", args[1])
    if args and args[0] == "m":
        context.user_data["admin_wait"] = ("model", args[1])
        await safe_edit(query.message, f"Send the model name for <b>{esc(args[1])}</b> (e.g. {esc(PROVIDERS[args[1]].default_model)}).",
                        reply_markup=kb([BACK]))
        return
    if args and args[0] == "persona":
        context.user_data["admin_wait"] = ("persona", None)
        await safe_edit(query.message, "Send extra persona/branding instructions for the AI (or '-' to clear).", reply_markup=kb([BACK]))
        return
    active = await ai.active_provider()
    lines, rows = ["🤖 <b>AI settings</b>"], []
    for k, spec in PROVIDERS.items():
        n = await d["key_bank"].count(k)
        lines.append(f"{'👉' if k == active else '•'} {spec.label}: {await ai.model_for(k)} — {n} key(s)")
        rows.append([ibtn(f"Use {spec.label}", f"adm:ai:p:{k}", style="primary" if k == active else None),
                     ibtn("Model", f"adm:ai:m:{k}")])
    rows.append([ibtn("📝 Persona text", "adm:ai:persona")])
    await _show(query, "\n".join(lines), rows)


async def s_ch(query, context, uid, args):
    d = deps(context)
    if args and args[0] == "add":
        context.user_data["admin_wait"] = ("addch", None)
        await safe_edit(query.message, "Send the channel as <code>@username</code> or numeric id. The bot must be an admin there. /cancel to abort.",
                        reply_markup=kb([BACK]))
        return
    chans = await d["repo"].list_channels(False)
    lines, rows = ["📢 <b>Force-subscribe channels</b>" + ("" if chans else "\nNone configured — everyone can use the bot.")], []
    for c in chans:
        lines.append(f"• {esc(c['chat_ref'])} {esc(c['title'] or '')}")
        rows.append([ibtn(f"🗑 {c['chat_ref']}", f"adm:cf:rmch:{c['chat_ref']}", style="danger")])
    rows.append([ibtn("➕ Add channel", "adm:ch:add", style="success")])
    await _show(query, "\n".join(lines), rows)


async def s_ft(query, context, uid, args):
    repo = deps(context)["repo"]
    if args and args[0] in FEATURES + ["activity"]:
        key = "activity.paused" if args[0] == "activity" else f"feature.{args[0]}"
        cur = await repo.get_bool_setting(key, key != "activity.paused")
        await repo.set_setting(key, "0" if cur else "1")
        await repo.audit(uid, "feature", f"{key}={'off' if cur else 'on'}")
    rows, lines = [], ["🎛 <b>Features</b>"]
    for f in FEATURES:
        on = await repo.get_bool_setting(f"feature.{f}", True)
        lines.append(f"{'✅' if on else '⛔'} {f}")
        rows.append([ibtn(f"{'Disable' if on else 'Enable'} {f}", f"adm:ft:{f}")])
    paused = await repo.get_bool_setting("activity.paused", False)
    rows.append([ibtn(f"Activity forwarding: {'PAUSED' if paused else 'on'}", "adm:ft:activity")])
    ytl = await repo.get_int_setting("yt.limit", 5)
    rows.append([ibtn(f"YouTube results: {n}{' ✔' if n == ytl else ''}", f"adm:ytl:{n}") for n in (3, 5, 10)])
    await _show(query, "\n".join(lines), rows)


async def s_ytl(query, context, uid, args):
    if args and args[0] in ("3", "5", "10"):
        await deps(context)["repo"].set_setting("yt.limit", args[0])
        await deps(context)["repo"].audit(uid, "yt.limit", args[0])
    await s_ft(query, context, uid, [])


async def s_exp(query, context, uid, args):
    d = deps(context); repo = d["repo"]
    if not args:
        await _show(query, "📤 Export CSV", [[ibtn("Users", "adm:exp:users"), ibtn("Downloads", "adm:exp:downloads"),
                                            ibtn("Errors", "adm:exp:errors")]])
        return
    rows = {"users": repo.export_users, "downloads": repo.export_downloads,
            "errors": lambda: repo.recent_errors(1000)}.get(args[0])
    if rows is None:
        return
    data = await asyncio.to_thread(rows)
    buf = io.StringIO()
    if data:
        w = csv.DictWriter(buf, fieldnames=list(data[0].keys()))
        w.writeheader()
        for r in data:      # neutralise spreadsheet formula injection
            w.writerow({k: ("'" + v if isinstance(v, str) and v[:1] in "=+-@" else v) for k, v in r.items()})
    await repo.audit(uid, "export", args[0])
    await query.message.reply_document(io.BytesIO(buf.getvalue().encode("utf-8-sig")), filename=f"{args[0]}_{int(time.time())}.csv")


async def s_cl(query, context, uid, args):
    d = deps(context); repo = d["repo"]
    if args and args[0] == "keep":
        cur = await repo.get_bool_setting("storage.keep_files", False)
        await repo.set_setting("storage.keep_files", "0" if cur else "1")
        await repo.audit(uid, "keep_files", str(not cur))
    keep = await repo.get_bool_setting("storage.keep_files", False)
    s = d["settings"]
    size = await asyncio.to_thread(cleanup.dir_size, s.temp_dir)
    dl = await asyncio.to_thread(cleanup.dir_size, s.download_dir)
    await _show(query, f"🧹 <b>Cleanup</b>\nTemp: {human_size(size)} (auto-swept every {s.cleanup_hours}h)\n"
                       f"Saved files: {human_size(dl)}\nKeep a copy of delivered files: <b>{'ON' if keep else 'off'}</b>",
                [[ibtn("Clean stale temp now", "adm:cf:cleannow:x")],
                 [ibtn(f"Keep copies: {'turn off' if keep else 'turn on'}", "adm:cl:keep")]])


async def s_audit(query, context, uid, args):
    rows = await deps(context)["repo"].recent_audit(15)
    lines = ["🧾 <b>Admin audit log</b>"] + [f"• {time.strftime('%m-%d %H:%M', time.gmtime(r['ts']))} a{r['admin_id']} {esc(r['action'])} {esc((r['detail'] or '')[:60])}" for r in rows]
    await _show(query, "\n".join(lines) if rows else "No admin actions logged yet.")


async def s_ver(query, context, uid, args):
    import telegram
    reg = deps(context)["registry"]
    lines = ["🧩 <b>Versions</b>", f"Python {platform.python_version()} · {platform.system()}",
             f"python-telegram-bot {telegram.__version__}", await media_service.tool_version("ffmpeg")]
    lines += [f"{esc(e['display_name'])}: {esc(e['version'])} ({'on' if e['enabled'] else 'off'})" for e in reg.describe()]
    lines.append("<i>Keep yt-dlp updated: pip install -U yt-dlp</i>")
    await _show(query, "\n".join(lines))


async def s_sheets(query, context, uid, args):
    res = await deps(context)["sheets"].sync_now()
    await deps(context)["repo"].audit(uid, "sheets sync", res[:80])
    await _show(query, f"📑 {esc(res)}")


async def s_cookies(query, context, uid, args):
    d = deps(context)
    path: Path = d["cookies_file"]
    if args and args[0] == "del":
        path.unlink(missing_ok=True); await d["repo"].audit(uid, "cookies deleted")
    if args and args[0] == "up":
        context.user_data["admin_wait"] = ("cookies", None)
        await safe_edit(query.message, "Send your <b>cookies.txt</b> (Netscape format) as a file. It is used only for sites that need a sign-in "
                        "for content <i>your own account</i> may access. /cancel to abort.", reply_markup=kb([BACK]))
        return
    state = f"present ({human_size(path.stat().st_size)})" if path.exists() else "not set"
    await _show(query, f"🍪 <b>Cookies file</b>: {state}\n<i>Exported cookies grant access to your account — never share the file. "
                       f"Using them may violate a site's terms; use only your own account.</i>",
                [[ibtn("⬆️ Upload", "adm:cookies:up", style="primary"), ibtn("🗑 Delete", "adm:cookies:del", style="danger")]])


async def s_maint(query, context, uid, args):
    repo = deps(context)["repo"]
    cur = await repo.get_bool_setting("maintenance", False)
    await repo.set_setting("maintenance", "0" if cur else "1")
    await repo.audit(uid, "maintenance", "off" if cur else "on")
    await _show(query, f"🛠 Maintenance is now <b>{'OFF' if cur else 'ON'}</b>.")


_SECTIONS = {"home": s_home, "dash": s_dash, "eng": s_eng, "lim": s_lim, "jobs": s_jobs, "err": s_err, "users": s_users,
             "uw": s_uw, "cf": s_cf, "do": s_do, "bc": s_bc, "keys": s_keys, "ai": s_ai, "ch": s_ch, "ft": s_ft,
             "ytl": s_ytl, "exp": s_exp, "cl": s_cl, "audit": s_audit, "ver": s_ver, "sheets": s_sheets,
             "cookies": s_cookies, "maint": s_maint}


# ---------------- text / file input ----------------
async def handle_admin_input(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    """Called by the router for admin text while an input is pending. Returns True if consumed."""
    d = deps(context); repo = d["repo"]
    wait = context.user_data.get("admin_wait")
    if not wait or not d["settings"].is_admin(update.effective_user.id):
        return False
    kind, extra = wait
    context.user_data.pop("admin_wait", None)
    uid = update.effective_user.id
    reply = update.message.reply_text
    if kind in ("block", "unblock", "uinfo", "grant"):
        if not text.isdigit():
            await reply("Please send a numeric user ID."); return True
        target = int(text)
        row = await repo.get_user(target)
        if not row:
            await reply("Unknown user."); return True
        if kind == "block":
            await reply(f"Block {target}?", reply_markup=kb([[ibtn("✅ Yes", f"adm:do:block:{target}", style="danger"), ibtn("❌ No", "adm:home")]]))
        elif kind == "unblock":
            await repo.set_blocked(target, False); await repo.audit(uid, "unblock", str(target)); await reply(f"✅ Unblocked {target}")
        elif kind == "grant":
            until = await repo.extend_premium(target, d["settings"].premium_days)
            await repo.audit(uid, "grant premium", str(target)); await reply(f"💎 Premium for {target} until {fmt_date(until)}")
        else:
            st = await repo.user_stats(target)
            await reply(f"👤 {esc(row['first_name'])} (@{esc(row['username'] or '-')}) <code>{target}</code>\nJoined {fmt_date(row['joined_at'])} · "
                        f"blocked: {bool(row['is_blocked'])} · premium: {await repo.is_premium(target)}\nDownloads {st['done']}/{st['total']}", parse_mode="HTML")
    elif kind == "bc":
        token = d["pending"].put({"text": text, "user": uid})
        await reply(f"📣 <b>Preview</b>\n\n{text}", parse_mode="HTML",
                    reply_markup=kb([[ibtn("🚀 Send to all", f"adm:bc:go:{token}", style="success"), ibtn("❌ Cancel", "adm:home")]]))
    elif kind == "addkey":
        ok = await d["key_bank"].add(extra, text, "admin")
        try:
            await update.message.delete()
        except TelegramError:
            pass
        await repo.audit(uid, "add key", extra)
        await context.bot.send_message(update.effective_chat.id, "✅ Key saved." if ok else "That key already exists (or was empty).")
    elif kind == "model":
        try:
            await d["ai"].set_model(extra, text); await repo.audit(uid, "ai model", f"{extra}={text}"); await reply("✅ Model saved.")
        except ValueError:
            await reply("Invalid model name.")
    elif kind == "persona":
        await repo.set_setting("ai.persona_extra", "" if text == "-" else text[:800]); await repo.audit(uid, "ai persona"); await reply("✅ Saved.")
    elif kind == "addch":
        try:
            ref = text if text.startswith("@") or text.lstrip("-").isdigit() else f"@{text}"
            chat = await context.bot.get_chat(int(ref) if ref.lstrip("-").isdigit() else ref)
            url = f"https://t.me/{chat.username}" if chat.username else (chat.invite_link or "")
            await repo.add_channel(ref, chat.title or "", url); await repo.audit(uid, "add channel", ref)
            await reply(f"✅ Added {esc(chat.title or ref)}. Make sure the bot is an administrator there.", parse_mode="HTML")
        except TelegramError as exc:
            await reply(f"Couldn't find that chat ({esc(str(exc)[:80])}). Add the bot to the channel first.", parse_mode="HTML")
    else:
        return False
    return True


@admin_only
async def on_document(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    d = deps(context)
    wait = context.user_data.get("admin_wait")
    if not wait or wait[0] != "cookies":
        return
    context.user_data.pop("admin_wait", None)
    doc = update.message.document
    if doc.file_size and doc.file_size > 2 * 1024 * 1024:
        await update.message.reply_text("File too large for a cookies file."); return
    path: Path = d["cookies_file"]
    path.parent.mkdir(parents=True, exist_ok=True)
    tf = await doc.get_file()
    await tf.download_to_drive(str(path))
    head = path.read_text(errors="ignore")[:2000]
    if "\t" not in head and "Netscape" not in head:
        path.unlink(missing_ok=True)
        await update.message.reply_text("That doesn't look like a Netscape cookies.txt file."); return
    try:
        path.chmod(0o600)
    except OSError:
        pass
    try:
        await update.message.delete()
    except TelegramError:
        pass
    await d["repo"].audit(update.effective_user.id, "cookies uploaded")
    await context.bot.send_message(update.effective_chat.id, "✅ Cookies saved.")
