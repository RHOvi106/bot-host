"""AI assistant, YouTube search and stock photos/videos."""
from __future__ import annotations

import asyncio
import logging
import tempfile
from pathlib import Path

from telegram import InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from ai.ai_manager import AIUnavailable
from api.base_client import ApiError
from keyboards.menus import ibtn, main_menu
from services.key_bank import NoKeyAvailable
from services.metadata_service import human_duration
from services.upload_service import upload_file
from utils.tg_compat import TelegramError
from utils.validators import validate_url_async, InvalidUrl
from .common import deps, esc, is_feature_on
from .download import process_url

log = logging.getLogger(__name__)
MAX_STOCK_BYTES = 40 * 1024 * 1024


# ---------------- AI ----------------
async def enter_ai(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await is_feature_on(context, "ai"):
        await update.message.reply_text("The AI assistant is switched off right now.")
        return
    context.user_data["mode"] = "ai"
    s = deps(context)["settings"]
    await update.message.reply_text(
        f"🤖 <b>AI Assistant</b> — I'm {esc(s.owner_name)}'s official bot assistant. Ask me anything (বাংলায়ও লিখতে পারেন)!\n"
        f"Send /cancel to leave this mode.", parse_mode="HTML")


async def ai_message(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    d = deps(context)
    if not d["ai_limiter"].allow(update.effective_user.id):
        await update.message.reply_text("⏳ You're asking too fast. Please wait a few seconds.")
        return
    await context.bot.send_chat_action(update.effective_chat.id, "typing")
    try:
        answer = await asyncio.wait_for(d["ai"].chat(update.effective_user.id, text), 60)
    except (AIUnavailable, asyncio.TimeoutError):
        await update.message.reply_text("🤖 The assistant is unavailable right now. Please try again later.")
        return
    await d["activity"].record({"user_id": update.effective_user.id, "first_name": update.effective_user.first_name,
                                "username": update.effective_user.username}, "ai chat", text[:200])
    for i in range(0, len(answer), 3900):
        await update.message.reply_text(answer[i:i + 3900])


async def on_ai_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if query.data == "ai:clear":
        await deps(context)["repo"].clear_chat(update.effective_user.id)
        await query.answer("AI chat history cleared ✅", show_alert=True)
    else:
        await query.answer()


# ---------------- YouTube search ----------------
async def enter_youtube(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await is_feature_on(context, "youtube"):
        await update.message.reply_text("YouTube search is switched off right now.")
        return
    context.user_data["mode"] = "yt"
    await update.message.reply_text("🔎 Send me what to search on YouTube. (/cancel to stop)")


async def youtube_query(update: Update, context: ContextTypes.DEFAULT_TYPE, query_text: str) -> None:
    d = deps(context)
    limit = await d["repo"].get_int_setting("yt.limit", 5)
    status = await update.message.reply_text("🔎 Searching…")
    try:
        results = await asyncio.wait_for(d["youtube"].search(query_text[:150], limit), 45)
    except Exception as exc:  # noqa: BLE001
        log.warning("youtube search failed: %s", exc)
        await status.edit_text("Search is unavailable right now. You can paste a YouTube link instead.")
        return
    if not results:
        await status.edit_text("No results found. Try different words.")
        return
    token = d["pending"].put({"results": results, "user": update.effective_user.id})
    lines, rows = [f"🔎 <b>Results for</b> “{esc(query_text[:60])}”\n"], []
    for i, r in enumerate(results):
        dur = f" · {human_duration(r['duration'])}" if r.get("duration") else ""
        lines.append(f"<b>{i + 1}.</b> {esc(r['title'][:90])}\n    <i>{esc(r.get('channel') or '')}</i>{dur}")
        rows.append([ibtn(f"🎬 {i + 1}", f"yt:{token}:{i}:v", style="success"), ibtn(f"🎵 {i + 1}", f"yt:{token}:{i}:a", style="primary")])
    text = "\n".join(lines)
    if await is_feature_on(context, "ai") and await d["key_bank"].count("gemini") + await d["key_bank"].count("groq") + \
            await d["key_bank"].count("openai") + await d["key_bank"].count("openrouter") > 0:
        try:
            tip = await asyncio.wait_for(d["ai"].guide_search(query_text, results), 20)
            text += f"\n\n🤖 {esc(tip[:300])}"
        except Exception:  # noqa: BLE001 - guidance is optional
            pass
    await status.edit_text(text[:4000], parse_mode="HTML", reply_markup=InlineKeyboardMarkup(rows))
    context.user_data.pop("mode", None)


async def on_youtube_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    _, token, idx, kind = query.data.split(":")
    data = deps(context)["pending"].get(token)
    if not data or data["user"] != update.effective_user.id:
        await query.answer("Results expired. Search again.", show_alert=True)
        return
    try:
        item = data["results"][int(idx)]
    except (ValueError, IndexError):
        await query.answer()
        return
    await query.answer("Reading media info…")
    await process_url(query.message, context, update.effective_user, item["url"], force_kind="audio" if kind == "a" else "video")


# ---------------- Stock ----------------
SOURCES = {"unsplash": "📷 Unsplash photos", "pixabay": "🖼 Pixabay images", "pixabay_video": "🎞 Pixabay videos",
           "random": "🎲 Random photo"}


async def enter_stock(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await is_feature_on(context, "stock"):
        await update.message.reply_text("Stock search is switched off right now.")
        return
    rows = [[ibtn(label, f"st:{key}", style="primary")] for key, label in SOURCES.items()]
    await update.message.reply_text("🖼 <b>Free photos & videos</b>\nChoose a source:", parse_mode="HTML",
                                    reply_markup=InlineKeyboardMarkup(rows))


async def on_stock_source(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    source = query.data.split(":", 1)[1]
    await query.answer()
    if source == "random":
        await stock_search(query.message, context, update.effective_user, "random", None)
        return
    context.user_data["mode"] = f"stock:{source}"
    await query.message.reply_text(f"{SOURCES.get(source, source)} — send a search word (e.g. “sunset beach”). /cancel to stop.")


async def stock_search(message, context, user, source: str, text: str | None) -> None:
    d = deps(context)
    status = await message.reply_text("🔎 Searching…")
    try:
        if source == "unsplash":
            items = await d["unsplash"].search(text, 5)
        elif source == "random":
            items = await d["unsplash"].random(None, 1)
        elif source == "pixabay":
            items = await d["pixabay"].search_images(text, 5)
        else:
            items = await d["pixabay"].search_videos(text, 4)
    except NoKeyAvailable as exc:
        msg = ("All API keys for this source are rate-limited right now. Please try again later."
               if exc.configured else "This source isn't configured yet (the admin needs to add an API key).")
        await status.edit_text(msg)
        return
    except ApiError as exc:
        log.warning("stock API error: %s", exc)
        await status.edit_text("The photo service is having trouble right now. Please try again later.")
        return
    if not items:
        await status.edit_text("No results. Try another word.")
        return
    await status.delete()
    token = d["pending"].put({"items": items, "user": user.id})
    for i, it in enumerate(items):
        credit = f"{it.source.title()} · {esc(it.author)}" + (f" · {it.width}×{it.height}" if it.width else "")
        caption = f"{esc((it.description or '')[:150])}\n<i>{credit}</i>"
        kb = InlineKeyboardMarkup([[ibtn("⬇️ Download HD", f"sk:{token}:{i}", style="success")]])
        try:
            if it.kind == "video" or not it.preview_url:
                await message.reply_text(f"🎞 {caption}", parse_mode="HTML", reply_markup=kb)
            else:
                await message.reply_photo(it.preview_url, caption=caption[:1000], parse_mode="HTML", reply_markup=kb)
        except TelegramError:
            await message.reply_text(caption, parse_mode="HTML", reply_markup=kb)


async def on_stock_download(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    _, token, idx = query.data.split(":")
    d = deps(context)
    data = d["pending"].get(token)
    if not data or data["user"] != update.effective_user.id:
        await query.answer("Expired. Search again.", show_alert=True)
        return
    try:
        item = data["items"][int(idx)]
        await validate_url_async(item.download_url)
    except (ValueError, IndexError, InvalidUrl):
        await query.answer("Not available.", show_alert=True)
        return
    await query.answer("Downloading…")
    with tempfile.TemporaryDirectory(dir=d["settings"].temp_dir) as tmp:
        ext = ".mp4" if item.kind == "video" else ".jpg"
        path = Path(tmp) / f"{item.source}_{item.id}{ext}"
        try:
            await d["http"].download(item.download_url, path, headers=None, timeout=60.0, max_bytes=MAX_STOCK_BYTES,
                                     on_progress=None, cancel=None)
            if item.source == "unsplash":
                await d["unsplash"].track_download(item)
            if item.kind == "video":
                await upload_file(context.bot, query.message.chat_id, path, kind="video",
                                  caption=f"{item.source.title()} · {esc(item.author)}")
            else:   # original quality, uncompressed, as a document
                from services.upload_service import send_with_retry

                async def send_doc():
                    with open(path, "rb") as fh:
                        return await context.bot.send_document(query.message.chat_id, fh, filename=path.name,
                                                               caption=f"{item.source.title()} · {item.author}"[:1000],
                                                               write_timeout=300)
                await send_with_retry(send_doc)
        except (ApiError, TelegramError, OSError) as exc:
            log.warning("stock download failed: %s", exc)
            await query.message.reply_text("Couldn't fetch that file. Please try another result.")
