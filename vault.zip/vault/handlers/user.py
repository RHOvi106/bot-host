"""History, profile/statistics, settings, referrals and support."""
from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes

from keyboards.menus import ibtn, main_menu, settings_keyboard
from services import media_service
from services.metadata_service import human_size
from services.referral_service import referral_link
from .common import deps, esc, fmt_date, safe_edit

_STATUS_ICON = {"done": "✅", "failed": "❌", "cancelled": "🛑", "running": "⏳", "queued": "⏳", "abandoned": "⚪"}


async def history(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    rows = await deps(context)["repo"].recent_downloads(update.effective_user.id, 10)
    if not rows:
        await update.message.reply_text("📚 No downloads yet. Send me a link to start!")
        return
    lines = ["📚 <b>Your last downloads</b>"]
    for r in rows:
        lines.append(f"{_STATUS_ICON.get(r['status'], '•')} {esc((r['title'] or r['url'])[:55])} — "
                     f"{esc(r['quality'] or '')} {esc((r['platform'] or ''))} · {fmt_date(r['created_at'])}")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML", disable_web_page_preview=True)


async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    d = deps(context)
    uid = update.effective_user.id
    st = await d["repo"].user_stats(uid)
    await update.message.reply_text(
        f"📊 <b>Your statistics</b>\nTotal requests: {st['total']}\n✅ Completed: {st['done']}   ❌ Failed: {st['failed']}\n"
        f"🎬 Videos: {st['video']}   🎵 Audio: {st['audio']}\n💾 Data delivered: {human_size(st['bytes'])}", parse_mode="HTML")


async def profile(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    d = deps(context)
    s, repo, u = d["settings"], d["repo"], update.effective_user
    row = await repo.get_user(u.id)
    premium = await repo.is_premium(u.id)
    refs = await repo.confirmed_referrals(u.id)
    plan = "👑 Admin" if s.is_admin(u.id) else (f"💎 Premium until {fmt_date(row['premium_until'])}" if premium else "🆓 Free")
    await update.message.reply_text(
        f"👤 <b>{esc(u.first_name)}</b>\n🆔 <code>{u.id}</code>\n📅 Joined: {fmt_date(row['joined_at'])}\n"
        f"Plan: {plan}\n👥 Friends invited: {refs}\n⭐ Points: {row['points']}", parse_mode="HTML")


async def refer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    d = deps(context)
    s, repo, u = d["settings"], d["repo"], update.effective_user
    me = await context.bot.get_me()
    refs = await repo.confirmed_referrals(u.id)
    threshold = await repo.get_int_setting("referral.threshold", s.referral_threshold)
    days = await repo.get_int_setting("referral.days", s.premium_days)
    if not await repo.get_bool_setting("feature.referral", True):
        await update.message.reply_text("The referral programme is paused right now.")
        return
    await update.message.reply_text(
        f"👥 <b>Invite friends, get Premium</b>\nEvery {threshold} friends who join (and subscribe to the channel) "
        f"give you <b>{days} days of Premium</b> (unlimited daily downloads).\n\n"
        f"Your link:\n<code>{esc(referral_link(me.username, u.id))}</code>\n\nConfirmed so far: <b>{refs}</b>",
        parse_mode="HTML")


async def support(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    from telegram import InlineKeyboardMarkup
    s = deps(context)["settings"]
    kb = InlineKeyboardMarkup([[ibtn(f"💬 Contact {s.owner_name}", url=f"https://t.me/{s.owner_username}", style="primary")]])
    await update.message.reply_text(f"☎️ Need help or found a problem? Message {esc(s.owner_name)} directly.",
                                    parse_mode="HTML", reply_markup=kb)


async def _settings_view(context, user_id: int):
    d = deps(context)
    prefs = await d["repo"].all_prefs(user_id)
    wm_possible = bool(d["settings"].watermark_text or d["settings"].watermark_image) and media_service.ffmpeg_available() \
        and await d["repo"].get_bool_setting("feature.watermark", True)
    return settings_keyboard(prefs, show_watermark=wm_possible)


async def settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("⚙️ <b>Settings</b>", parse_mode="HTML",
                                    reply_markup=await _settings_view(context, update.effective_user.id))


async def on_settings_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query, repo, uid = update.callback_query, deps(context)["repo"], update.effective_user.id
    key = query.data.split(":", 1)[1]
    prefs = await repo.all_prefs(uid)
    if key == "audio_fmt":
        order = ["best", "m4a", "mp3", "opus"]
        cur = prefs.get("audio_fmt", "best")
        await repo.set_pref(uid, "audio_fmt", order[(order.index(cur) + 1) % 4 if cur in order else 0])
    elif key in ("quick", "send_thumbnail", "watermark"):
        default = "1" if key == "send_thumbnail" else "0"
        await repo.set_pref(uid, key, "0" if prefs.get(key, default) == "1" else "1")
    await query.answer("Saved")
    await query.edit_message_reply_markup(await _settings_view(context, uid))
