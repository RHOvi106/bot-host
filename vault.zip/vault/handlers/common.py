"""Shared helpers for handlers."""
from __future__ import annotations

import html
import logging
import time
from typing import Any

from telegram import Update
from telegram.ext import ContextTypes

from utils.tg_compat import TelegramError

log = logging.getLogger(__name__)


def deps(context: ContextTypes.DEFAULT_TYPE) -> dict[str, Any]:
    return context.application.bot_data


def esc(text: Any) -> str:
    return html.escape(str(text if text is not None else ""), quote=False)


def fmt_date(ts: int | float | None) -> str:
    return time.strftime("%Y-%m-%d", time.gmtime(ts)) if ts else "—"


async def safe_edit(message: Any, text: str, **kwargs) -> None:
    """Edit a message, ignoring 'message is not modified' and deleted-message errors."""
    try:
        if getattr(message, "caption", None) is not None and not getattr(message, "text", None):
            await message.edit_caption(caption=text[:1024], parse_mode="HTML", **kwargs)
        else:
            await message.edit_text(text[:4096], parse_mode="HTML", **kwargs)
    except TelegramError as exc:
        if "not modified" not in str(exc).lower():
            log.debug("edit failed: %s", exc)


async def is_feature_on(context: ContextTypes.DEFAULT_TYPE, name: str, default: bool = True) -> bool:
    return await deps(context)["repo"].get_bool_setting(f"feature.{name}", default)


async def notify_admins(application: Any, text: str) -> None:
    settings = application.bot_data["settings"]
    for admin_id in settings.admin_ids:
        try:
            await application.bot.send_message(admin_id, text[:4000], parse_mode="HTML")
        except TelegramError:
            log.warning("could not notify admin %s", admin_id)


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Global safety net: log, store, tell the user something kind, alert admins (throttled)."""
    err = context.error
    log.error("Unhandled exception", exc_info=err)
    d = context.application.bot_data
    uid = getattr(getattr(update, "effective_user", None), "id", None) if isinstance(update, Update) else None
    try:
        await d["repo"].log_error(uid, "unhandled", f"{type(err).__name__}: {err}", "")
    except Exception:  # noqa: BLE001
        pass
    last = d.get("_last_alert", 0)
    if time.time() - last > 300:
        d["_last_alert"] = time.time()
        await notify_admins(context.application, f"🚨 <b>Unhandled error</b>\n<code>{esc(type(err).__name__)}: {esc(str(err)[:300])}</code>")
    if isinstance(update, Update) and update.effective_chat:
        try:
            await context.bot.send_message(update.effective_chat.id,
                                           "⚠️ Something went wrong on my side. The admin has been informed — please try again in a moment.")
        except TelegramError:
            pass
