"""Link handling, quality selection, queueing and the Telegram uploader."""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any

from telegram import Update
from telegram.ext import ContextTypes

from engines.base import ErrorCategory
from keyboards.menus import cancel_keyboard, main_menu, quality_keyboard
from services import upload_service
from services.download_service import Outcome
from services.fallback_service import AllEnginesFailed
from services.metadata_service import human_duration, escape
from services.progress_service import ProgressReporter, render_progress, ProgressState
from services.queue_service import Job, QueueRejected
from utils.messages import friendly
from utils.tg_compat import TelegramError
from utils.validators import InvalidUrl, platform_of, validate_url_async
from .common import deps, esc, safe_edit

log = logging.getLogger(__name__)


class TelegramUploader:
    def __init__(self, bot: Any, chat_id: int):
        self.bot, self.chat_id = bot, chat_id

    async def upload(self, path: Path, *, kind, caption, duration, width, height, thumb, title, performer):
        return await upload_service.upload_file(self.bot, self.chat_id, path, kind=kind, caption=caption,
                                                duration=duration, width=width, height=height, thumb=thumb,
                                                title=title, performer=performer)

    async def resend(self, file_id, method, caption):
        return await upload_service.resend_cached(self.bot, self.chat_id, file_id, method, caption)


def info_card(info, platform: str) -> str:
    lines = [f"<b>{esc(info.title[:200])}</b>"]
    if info.uploader:
        lines.append(f"👤 {esc(info.uploader[:80])}")
    meta = [platform.title()]
    if info.duration:
        meta.append(human_duration(info.duration))
    if info.upload_date and len(info.upload_date) == 8:
        meta.append(f"{info.upload_date[:4]}-{info.upload_date[4:6]}-{info.upload_date[6:]}")
    lines.append("📌 " + " · ".join(esc(m) for m in meta))
    if info.is_live:
        lines.append("🔴 Live stream (a limited segment will be recorded)")
    lines.append("\n👇 Choose a format:")
    return "\n".join(lines)


async def daily_quota_ok(context: ContextTypes.DEFAULT_TYPE, user_id: int) -> tuple[bool, str]:
    d = deps(context)
    s, repo = d["settings"], d["repo"]
    if s.is_admin(user_id) or await repo.is_premium(user_id):
        return True, ""
    limit = await repo.get_int_setting("limit.free_daily", s.free_daily_downloads)
    used = await repo.count_downloads_since(user_id, int(time.time()) - 86400)
    if used >= limit:
        return False, (f"📅 You've reached today's free limit ({limit} downloads). "
                       f"Invite friends via “👥 Refer & Premium” to unlock Premium, or try again tomorrow.")
    return True, ""


async def process_url(message: Any, context: ContextTypes.DEFAULT_TYPE, user, url: str, force_kind: str | None = None) -> None:
    """Validate -> read metadata -> show quality menu (or auto-start in quick mode)."""
    d = deps(context)
    s, repo = d["settings"], d["repo"]
    ok, why = await daily_quota_ok(context, user.id)
    if not ok:
        await message.reply_text(why)
        return
    status = await message.reply_text("🔎 Validating link…")
    try:
        safe = await validate_url_async(url)
    except InvalidUrl:
        await safe_edit(status, friendly(ErrorCategory.INVALID_URL))
        return
    await safe_edit(status, "📋 Reading media info…")
    try:
        info = await d["fallback"].get_info(safe, d["cookies_path"]())
    except AllEnginesFailed as exc:
        await repo.log_error(user.id, exc.category.value, str(exc)[:300], safe)
        await safe_edit(status, friendly(exc.category))
        return
    await d["activity"].record({"user_id": user.id, "first_name": user.first_name, "username": user.username},
                               "link", safe)
    mode = force_kind or context.user_data.pop("mode", None)
    audio_only = mode in ("audio", "a")
    prefs = await repo.all_prefs(user.id)
    token = d["pending"].put({"url": safe, "info": info, "user": user.id, "chat": message.chat_id})
    platform = info.platform if info.platform != "unknown" else platform_of(safe)
    if prefs.get("quick") == "1":
        await safe_edit(status, "⚡ Quick mode: starting…")
        kind, opt = ("a", prefs.get("audio_fmt", "best")) if audio_only else ("v", "best")
        await start_job(status, context, user, token, kind, opt)
        return
    kb = quality_keyboard(token, info, audio_only=audio_only)
    text = info_card(info, platform)
    try:
        await status.delete()
    except TelegramError:
        pass
    sent = False
    if info.thumbnail:
        try:
            await validate_url_async(info.thumbnail)
            await message.reply_photo(info.thumbnail, caption=text[:1024], parse_mode="HTML", reply_markup=kb)
            sent = True
        except (InvalidUrl, TelegramError):
            pass
    if not sent:
        await message.reply_text(text, parse_mode="HTML", reply_markup=kb)


async def start_job(anchor: Any, context: ContextTypes.DEFAULT_TYPE, user, token: str, kind_code: str, option: str) -> None:
    d = deps(context)
    s, repo, queue = d["settings"], d["repo"], d["queue"]
    data = d["pending"].get(token)
    if not data or data["user"] != user.id:
        await anchor.reply_text("This menu expired. Please send the link again.")
        return
    ok, why = await daily_quota_ok(context, user.id)
    if not ok:
        await anchor.reply_text(why)
        return
    info = data["info"]
    kind = "audio" if kind_code == "a" else "video"
    height = None if (kind == "audio" or option == "best") else int(option)
    audio_format = option if kind == "audio" else "best"
    quality = audio_format if kind == "audio" else (f"{height}p" if height else "best")
    prefs = await repo.all_prefs(user.id)
    features_wm = await repo.get_bool_setting("feature.watermark", True)
    job = Job(user.id, data["url"], kind, quality, payload={
        "info": info, "height": height, "audio_format": audio_format, "chat_id": data["chat"],
        "prefs": {"watermark": prefs.get("watermark") == "1" and features_wm,
                  "send_thumbnail": prefs.get("send_thumbnail", "1") == "1"}})
    progress_msg = await anchor.reply_text("⏳ Waiting in queue…", reply_markup=cancel_keyboard(job.job_id))
    try:
        await queue.submit(job)
    except QueueRejected as exc:
        await safe_edit(progress_msg, f"⚠️ {esc(exc.message)}")
        return
    job.payload["progress_message"] = progress_msg
    await repo.create_download(job.job_id, user.id, job.url, platform=info.platform, title=info.title,
                               uploader=info.uploader, duration=info.duration, upload_date=info.upload_date,
                               webpage_url=info.webpage_url, kind=kind, quality=quality,
                               thumbnail_url=info.thumbnail, engine=info.engine)
    pos = queue.position(job.job_id)
    if pos:
        await safe_edit(progress_msg, render_progress(ProgressState(stage="queued", queue_position=pos, title=info.title)),
                        reply_markup=cancel_keyboard(job.job_id))


async def on_download_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    parts = query.data.split(":")
    if len(parts) < 3:
        await query.answer()
        return
    _, token, action, *rest = parts
    d = deps(context)
    data = d["pending"].get(token)
    if not data or data["user"] != update.effective_user.id:
        await query.answer("This menu expired. Send the link again.", show_alert=True)
        return
    if action == "x":
        d["pending"].pop(token)
        await query.answer("Closed")
        try:
            await query.message.delete()
        except TelegramError:
            pass
        return
    if action == "thumb":
        await query.answer()
        thumb = data["info"].thumbnail
        try:
            await validate_url_async(thumb)
            await query.message.reply_photo(thumb, caption=f"<b>{esc(data['info'].title[:200])}</b>", parse_mode="HTML")
        except (InvalidUrl, TelegramError, TypeError):
            await query.message.reply_text("Couldn't fetch the thumbnail.")
        return
    if action in ("v", "a") and rest:
        await query.answer("Added ✅")
        try:
            await query.edit_message_reply_markup(None)
        except TelegramError:
            pass
        await start_job(query.message, context, update.effective_user, token, action, rest[0])
        return
    await query.answer()


async def on_cancel_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    job_id = query.data.split(":", 1)[1]
    d = deps(context)
    ok = d["queue"].cancel(job_id, by_user=update.effective_user.id, is_admin=d["settings"].is_admin(update.effective_user.id))
    await query.answer("Cancelling…" if ok else "Nothing to cancel.", show_alert=not ok)


def make_runner(application):
    """Queue runner: builds the progress reporter, runs the pipeline, writes the final message."""
    async def runner(job: Job) -> None:
        d = application.bot_data
        msg = job.payload["progress_message"]
        bot = application.bot
        info = job.payload["info"]
        kb = cancel_keyboard(job.job_id)

        async def edit(text: str) -> None:
            await msg.edit_text(text, parse_mode="HTML", reply_markup=kb)

        reporter = ProgressReporter(edit, interval=2.5)
        reporter.state.title = info.title
        await reporter.update(force=True, stage="downloading")
        outcome: Outcome = await d["download_service"].run_job(job, reporter, TelegramUploader(bot, job.payload["chat_id"]))
        try:
            if outcome.status == "done":
                await msg.edit_text("✅ <b>Done!</b> Enjoy.", parse_mode="HTML")
            else:
                prefix = "🛑" if outcome.status == "cancelled" else "❌"
                await msg.edit_text(f"{prefix} {esc(outcome.message)}", parse_mode="HTML")
        except TelegramError:
            pass
        user = await d["repo"].get_user(job.user_id) or {"user_id": job.user_id}
        await d["activity"].record(user, f"download {outcome.status}", f"{job.kind} {job.quality} {job.url}")
    return runner
