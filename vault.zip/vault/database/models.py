"""SQLite schema (plain SQL, versioned in migrations.py)."""

SCHEMA_V1: list[str] = [
    """CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT, first_name TEXT,
        joined_at INTEGER NOT NULL, last_seen INTEGER NOT NULL,
        is_blocked INTEGER NOT NULL DEFAULT 0,
        premium_until INTEGER NOT NULL DEFAULT 0,
        referred_by INTEGER,
        points INTEGER NOT NULL DEFAULT 0,
        fs_verified INTEGER NOT NULL DEFAULT 0
    )""",
    """CREATE TABLE IF NOT EXISTS user_prefs (
        user_id INTEGER NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL,
        PRIMARY KEY (user_id, key)
    )""",
    """CREATE TABLE IF NOT EXISTS admin_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS downloads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id TEXT NOT NULL UNIQUE,
        user_id INTEGER NOT NULL,
        url TEXT NOT NULL, platform TEXT,
        title TEXT, description TEXT, uploader TEXT, duration REAL, upload_date TEXT,
        webpage_url TEXT, kind TEXT, quality TEXT, ext TEXT, file_size INTEGER,
        thumbnail_url TEXT, engine TEXT,
        status TEXT NOT NULL DEFAULT 'queued',
        error_category TEXT, error_message TEXT,
        cache_key TEXT, tg_file_id TEXT, tg_file_kind TEXT,
        created_at INTEGER NOT NULL, finished_at INTEGER, processing_seconds REAL
    )""",
    "CREATE INDEX IF NOT EXISTS idx_dl_user ON downloads(user_id, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_dl_cache ON downloads(cache_key, status)",
    """CREATE TABLE IF NOT EXISTS download_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id TEXT NOT NULL, engine TEXT NOT NULL,
        started_at INTEGER NOT NULL, ended_at INTEGER,
        success INTEGER NOT NULL DEFAULT 0,
        error_category TEXT, error_message TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS engine_health (
        engine TEXT PRIMARY KEY,
        enabled INTEGER NOT NULL DEFAULT 1,
        priority INTEGER NOT NULL DEFAULT 100,
        last_success INTEGER, last_failure INTEGER,
        success_count INTEGER NOT NULL DEFAULT 0,
        failure_count INTEGER NOT NULL DEFAULT 0,
        last_error TEXT, settings_json TEXT NOT NULL DEFAULT '{}'
    )""",
    """CREATE TABLE IF NOT EXISTS api_keys (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        service TEXT NOT NULL, label TEXT,
        key_enc TEXT NOT NULL, fingerprint TEXT NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 1,
        cooldown_until INTEGER NOT NULL DEFAULT 0,
        calls INTEGER NOT NULL DEFAULT 0, failures INTEGER NOT NULL DEFAULT 0,
        last_used INTEGER NOT NULL DEFAULT 0, last_error TEXT,
        added_at INTEGER NOT NULL,
        UNIQUE(service, fingerprint)
    )""",
    """CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts INTEGER NOT NULL, admin_id INTEGER NOT NULL, action TEXT NOT NULL, detail TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS error_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts INTEGER NOT NULL, user_id INTEGER, category TEXT, message TEXT, context TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS chat_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL, role TEXT NOT NULL, content TEXT NOT NULL, ts INTEGER NOT NULL
    )""",
    "CREATE INDEX IF NOT EXISTS idx_chat_user ON chat_history(user_id, id)",
    """CREATE TABLE IF NOT EXISTS activity_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts INTEGER NOT NULL, user_id INTEGER NOT NULL, event TEXT NOT NULL, detail TEXT
    )""",
    """CREATE TABLE IF NOT EXISTS activity_topics (user_id INTEGER PRIMARY KEY, thread_id INTEGER NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS force_channels (
        chat_ref TEXT PRIMARY KEY, title TEXT, url TEXT, enabled INTEGER NOT NULL DEFAULT 1
    )""",
    """CREATE TABLE IF NOT EXISTS referrals (
        referred_id INTEGER PRIMARY KEY, referrer_id INTEGER NOT NULL,
        confirmed INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
    )""",
]
