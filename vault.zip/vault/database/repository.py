"""Data access layer. Sync methods; use AsyncProxy to call them off the event loop."""
from __future__ import annotations

import asyncio
import json
import time
from typing import Any, Callable

from .db import Database

_DOWNLOAD_FIELDS = {
    "platform", "title", "description", "uploader", "duration", "upload_date", "webpage_url",
    "kind", "quality", "ext", "file_size", "thumbnail_url", "engine", "status",
    "error_category", "error_message", "cache_key", "tg_file_id", "tg_file_kind",
    "finished_at", "processing_seconds",
}


class Repository:
    def __init__(self, db: Database, clock: Callable[[], float] = time.time):
        self.db = db
        self._clock = clock

    def now(self) -> int:
        return int(self._clock())

    # ---------------- users ----------------
    def upsert_user(self, user_id: int, username: str | None, first_name: str | None) -> tuple[dict, bool]:
        now = self.now()
        existing = self.get_user(user_id)
        if existing:
            self.db.execute(
                "UPDATE users SET username=?, first_name=?, last_seen=? WHERE user_id=?",
                (username, first_name, now, user_id))
            return self.get_user(user_id), False
        self.db.execute(
            "INSERT INTO users(user_id, username, first_name, joined_at, last_seen) VALUES(?,?,?,?,?)",
            (user_id, username, first_name, now, now))
        return self.get_user(user_id), True

    def get_user(self, user_id: int) -> dict | None:
        return self.db.query_one("SELECT * FROM users WHERE user_id=?", (user_id,))

    def set_blocked(self, user_id: int, blocked: bool) -> bool:
        _, n = self.db.execute("UPDATE users SET is_blocked=? WHERE user_id=?", (int(blocked), user_id))
        return n > 0

    def is_blocked(self, user_id: int) -> bool:
        return bool(self.db.scalar("SELECT is_blocked FROM users WHERE user_id=?", (user_id,), 0))

    def all_user_ids(self, *, include_blocked: bool = False) -> list[int]:
        sql = "SELECT user_id FROM users" + ("" if include_blocked else " WHERE is_blocked=0")
        return [r["user_id"] for r in self.db.query_all(sql)]

    def count_users(self) -> int:
        return self.db.scalar("SELECT COUNT(*) FROM users")

    def count_active_users(self, since: int) -> int:
        return self.db.scalar("SELECT COUNT(*) FROM users WHERE last_seen>=?", (since,))

    def set_fs_verified(self, user_id: int, value: bool = True) -> None:
        self.db.execute("UPDATE users SET fs_verified=? WHERE user_id=?", (int(value), user_id))

    def extend_premium(self, user_id: int, days: int) -> int:
        now = self.now()
        cur = self.db.scalar("SELECT premium_until FROM users WHERE user_id=?", (user_id,), 0)
        until = max(cur, now) + days * 86400
        self.db.execute("UPDATE users SET premium_until=? WHERE user_id=?", (until, user_id))
        return until

    def is_premium(self, user_id: int) -> bool:
        return self.db.scalar("SELECT premium_until FROM users WHERE user_id=?", (user_id,), 0) > self.now()

    def add_points(self, user_id: int, points: int) -> None:
        self.db.execute("UPDATE users SET points=points+? WHERE user_id=?", (points, user_id))

    def set_referred_by(self, user_id: int, referrer_id: int) -> None:
        self.db.execute("UPDATE users SET referred_by=? WHERE user_id=? AND referred_by IS NULL",
                        (referrer_id, user_id))

    # ---------------- preferences / settings ----------------
    def get_pref(self, user_id: int, key: str, default: str | None = None) -> str | None:
        row = self.db.query_one("SELECT value FROM user_prefs WHERE user_id=? AND key=?", (user_id, key))
        return row["value"] if row else default

    def set_pref(self, user_id: int, key: str, value: str) -> None:
        self.db.execute(
            "INSERT INTO user_prefs(user_id,key,value) VALUES(?,?,?) "
            "ON CONFLICT(user_id,key) DO UPDATE SET value=excluded.value", (user_id, key, str(value)))

    def all_prefs(self, user_id: int) -> dict[str, str]:
        return {r["key"]: r["value"] for r in
                self.db.query_all("SELECT key,value FROM user_prefs WHERE user_id=?", (user_id,))}

    def get_setting(self, key: str, default: str | None = None) -> str | None:
        row = self.db.query_one("SELECT value FROM admin_settings WHERE key=?", (key,))
        return row["value"] if row else default

    def set_setting(self, key: str, value: Any) -> None:
        self.db.execute(
            "INSERT INTO admin_settings(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))

    def get_int_setting(self, key: str, default: int) -> int:
        try:
            return int(self.get_setting(key, str(default)))
        except (TypeError, ValueError):
            return default

    def get_bool_setting(self, key: str, default: bool) -> bool:
        v = self.get_setting(key)
        return default if v is None else v.lower() in {"1", "true", "yes", "on"}

    # ---------------- downloads ----------------
    def create_download(self, job_id: str, user_id: int, url: str, **fields: Any) -> int:
        cols = {"job_id": job_id, "user_id": user_id, "url": url, "created_at": self.now()}
        for k, v in fields.items():
            if k in _DOWNLOAD_FIELDS:
                cols[k] = v
        names = ",".join(cols)
        marks = ",".join("?" for _ in cols)
        rowid, _ = self.db.execute(f"INSERT INTO downloads({names}) VALUES({marks})", tuple(cols.values()))
        return rowid

    def update_download(self, job_id: str, **fields: Any) -> None:
        cols = {k: v for k, v in fields.items() if k in _DOWNLOAD_FIELDS}
        if not cols:
            return
        sets = ",".join(f"{k}=?" for k in cols)
        self.db.execute(f"UPDATE downloads SET {sets} WHERE job_id=?", (*cols.values(), job_id))

    def get_download(self, job_id: str) -> dict | None:
        return self.db.query_one("SELECT * FROM downloads WHERE job_id=?", (job_id,))

    def add_attempt(self, job_id: str, engine: str, started_at: int, ended_at: int | None,
                    success: bool, category: str | None = None, message: str | None = None) -> None:
        self.db.execute(
            "INSERT INTO download_attempts(job_id,engine,started_at,ended_at,success,error_category,error_message)"
            " VALUES(?,?,?,?,?,?,?)",
            (job_id, engine, started_at, ended_at, int(success), category, (message or "")[:500]))

    def attempts_for(self, job_id: str) -> list[dict]:
        return self.db.query_all("SELECT * FROM download_attempts WHERE job_id=? ORDER BY id", (job_id,))

    def recent_downloads(self, user_id: int | None = None, limit: int = 10) -> list[dict]:
        if user_id is None:
            return self.db.query_all("SELECT * FROM downloads ORDER BY id DESC LIMIT ?", (limit,))
        return self.db.query_all(
            "SELECT * FROM downloads WHERE user_id=? ORDER BY id DESC LIMIT ?", (user_id, limit))

    def count_downloads_since(self, user_id: int, since: int) -> int:
        return self.db.scalar(
            "SELECT COUNT(*) FROM downloads WHERE user_id=? AND created_at>=? AND status IN ('done','running','queued')",
            (user_id, since))

    def global_stats(self) -> dict:
        q = self.db.scalar
        return {
            "users": self.count_users(),
            "total": q("SELECT COUNT(*) FROM downloads"),
            "done": q("SELECT COUNT(*) FROM downloads WHERE status='done'"),
            "failed": q("SELECT COUNT(*) FROM downloads WHERE status='failed'"),
            "cancelled": q("SELECT COUNT(*) FROM downloads WHERE status='cancelled'"),
            "video": q("SELECT COUNT(*) FROM downloads WHERE status='done' AND kind='video'"),
            "audio": q("SELECT COUNT(*) FROM downloads WHERE status='done' AND kind='audio'"),
            "bytes": q("SELECT COALESCE(SUM(file_size),0) FROM downloads WHERE status='done'"),
            "avg_seconds": q("SELECT AVG(processing_seconds) FROM downloads WHERE status='done'", default=0),
        }

    def user_stats(self, user_id: int) -> dict:
        q = self.db.scalar
        return {
            "total": q("SELECT COUNT(*) FROM downloads WHERE user_id=?", (user_id,)),
            "done": q("SELECT COUNT(*) FROM downloads WHERE user_id=? AND status='done'", (user_id,)),
            "failed": q("SELECT COUNT(*) FROM downloads WHERE user_id=? AND status='failed'", (user_id,)),
            "video": q("SELECT COUNT(*) FROM downloads WHERE user_id=? AND status='done' AND kind='video'", (user_id,)),
            "audio": q("SELECT COUNT(*) FROM downloads WHERE user_id=? AND status='done' AND kind='audio'", (user_id,)),
            "bytes": q("SELECT COALESCE(SUM(file_size),0) FROM downloads WHERE user_id=? AND status='done'", (user_id,)),
        }

    def counts_by(self, column: str) -> list[dict]:
        if column not in {"platform", "engine", "error_category", "kind"}:
            raise ValueError("unsupported group column")
        return self.db.query_all(
            f"SELECT COALESCE({column},'unknown') AS name, COUNT(*) AS n FROM downloads "
            f"GROUP BY {column} ORDER BY n DESC LIMIT 15")

    def find_cached_upload(self, cache_key: str) -> dict | None:
        return self.db.query_one(
            "SELECT * FROM downloads WHERE cache_key=? AND status='done' AND tg_file_id IS NOT NULL "
            "ORDER BY id DESC LIMIT 1", (cache_key,))

    def mark_abandoned(self) -> int:
        _, n = self.db.execute(
            "UPDATE downloads SET status='abandoned', finished_at=? WHERE status IN ('queued','running')",
            (self.now(),))
        return n

    # ---------------- engine health ----------------
    def ensure_engine(self, name: str, default_priority: int) -> dict:
        self.db.execute("INSERT OR IGNORE INTO engine_health(engine, priority) VALUES(?,?)",
                        (name, default_priority))
        return self.get_engine(name)

    def get_engine(self, name: str) -> dict | None:
        return self.db.query_one("SELECT * FROM engine_health WHERE engine=?", (name,))

    def list_engines(self) -> list[dict]:
        return self.db.query_all("SELECT * FROM engine_health ORDER BY priority, engine")

    def set_engine_enabled(self, name: str, enabled: bool) -> None:
        self.db.execute("UPDATE engine_health SET enabled=? WHERE engine=?", (int(enabled), name))

    def set_engine_priority(self, name: str, priority: int) -> None:
        self.db.execute("UPDATE engine_health SET priority=? WHERE engine=?", (priority, name))

    def set_engine_settings(self, name: str, settings: dict) -> None:
        self.db.execute("UPDATE engine_health SET settings_json=? WHERE engine=?",
                        (json.dumps(settings), name))

    def record_engine_result(self, name: str, ok: bool, error: str | None = None) -> None:
        now = self.now()
        if ok:
            self.db.execute("UPDATE engine_health SET last_success=?, success_count=success_count+1 WHERE engine=?",
                            (now, name))
        else:
            self.db.execute(
                "UPDATE engine_health SET last_failure=?, failure_count=failure_count+1, last_error=? WHERE engine=?",
                (now, (error or "")[:300], name))

    # ---------------- API key bank ----------------
    def add_api_key(self, service: str, key_enc: str, fingerprint: str, label: str | None = None) -> int | None:
        rowid, n = self.db.execute(
            "INSERT OR IGNORE INTO api_keys(service,label,key_enc,fingerprint,added_at) VALUES(?,?,?,?,?)",
            (service, label, key_enc, fingerprint, self.now()))
        return rowid if n else None

    def list_api_keys(self, service: str | None = None) -> list[dict]:
        if service:
            return self.db.query_all("SELECT * FROM api_keys WHERE service=? ORDER BY id", (service,))
        return self.db.query_all("SELECT * FROM api_keys ORDER BY service, id")

    def available_api_keys(self, service: str) -> list[dict]:
        """Enabled, not cooling down; least-recently-used first (round robin)."""
        return self.db.query_all(
            "SELECT * FROM api_keys WHERE service=? AND enabled=1 AND cooldown_until<=? "
            "ORDER BY last_used, id", (service, self.now()))

    def mark_key_used(self, key_id: int) -> None:
        self.db.execute("UPDATE api_keys SET calls=calls+1, last_used=?, last_error=NULL WHERE id=?",
                        (self.now(), key_id))

    def mark_key_cooldown(self, key_id: int, seconds: int, error: str) -> None:
        self.db.execute(
            "UPDATE api_keys SET cooldown_until=?, failures=failures+1, last_error=?, last_used=? WHERE id=?",
            (self.now() + seconds, error[:200], self.now(), key_id))

    def set_key_enabled(self, key_id: int, enabled: bool) -> None:
        self.db.execute("UPDATE api_keys SET enabled=?, cooldown_until=0 WHERE id=?", (int(enabled), key_id))

    def delete_api_key(self, key_id: int) -> bool:
        _, n = self.db.execute("DELETE FROM api_keys WHERE id=?", (key_id,))
        return n > 0

    # ---------------- logs ----------------
    def log_error(self, user_id: int | None, category: str, message: str, context: str = "") -> None:
        self.db.execute("INSERT INTO error_records(ts,user_id,category,message,context) VALUES(?,?,?,?,?)",
                        (self.now(), user_id, category, message[:1000], context[:1000]))

    def recent_errors(self, limit: int = 10) -> list[dict]:
        return self.db.query_all("SELECT * FROM error_records ORDER BY id DESC LIMIT ?", (limit,))

    def audit(self, admin_id: int, action: str, detail: str = "") -> None:
        self.db.execute("INSERT INTO audit_logs(ts,admin_id,action,detail) VALUES(?,?,?,?)",
                        (self.now(), admin_id, action, detail[:500]))

    def recent_audit(self, limit: int = 15) -> list[dict]:
        return self.db.query_all("SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?", (limit,))

    def log_activity(self, user_id: int, event: str, detail: str = "") -> None:
        self.db.execute("INSERT INTO activity_log(ts,user_id,event,detail) VALUES(?,?,?,?)",
                        (self.now(), user_id, event, detail[:500]))

    def get_topic(self, user_id: int) -> int | None:
        row = self.db.query_one("SELECT thread_id FROM activity_topics WHERE user_id=?", (user_id,))
        return row["thread_id"] if row else None

    def set_topic(self, user_id: int, thread_id: int) -> None:
        self.db.execute("INSERT OR REPLACE INTO activity_topics(user_id,thread_id) VALUES(?,?)",
                        (user_id, thread_id))

    # ---------------- chat history ----------------
    def add_chat(self, user_id: int, role: str, content: str) -> None:
        self.db.execute("INSERT INTO chat_history(user_id,role,content,ts) VALUES(?,?,?,?)",
                        (user_id, role, content[:4000], self.now()))

    def recent_chat(self, user_id: int, limit: int = 10) -> list[dict]:
        rows = self.db.query_all(
            "SELECT role,content FROM chat_history WHERE user_id=? ORDER BY id DESC LIMIT ?", (user_id, limit))
        return list(reversed(rows))

    def clear_chat(self, user_id: int) -> None:
        self.db.execute("DELETE FROM chat_history WHERE user_id=?", (user_id,))

    # ---------------- force-sub channels ----------------
    def add_channel(self, chat_ref: str, title: str = "", url: str = "") -> None:
        self.db.execute(
            "INSERT INTO force_channels(chat_ref,title,url,enabled) VALUES(?,?,?,1) "
            "ON CONFLICT(chat_ref) DO UPDATE SET title=excluded.title, url=excluded.url, enabled=1",
            (chat_ref, title, url))

    def remove_channel(self, chat_ref: str) -> bool:
        _, n = self.db.execute("DELETE FROM force_channels WHERE chat_ref=?", (chat_ref,))
        return n > 0

    def list_channels(self, enabled_only: bool = True) -> list[dict]:
        sql = "SELECT * FROM force_channels" + (" WHERE enabled=1" if enabled_only else "") + " ORDER BY chat_ref"
        return self.db.query_all(sql)

    # ---------------- referrals ----------------
    def add_referral(self, referrer_id: int, referred_id: int) -> bool:
        if referrer_id == referred_id:
            return False
        _, n = self.db.execute(
            "INSERT OR IGNORE INTO referrals(referred_id,referrer_id,confirmed,created_at) VALUES(?,?,0,?)",
            (referred_id, referrer_id, self.now()))
        return n > 0

    def confirm_referral(self, referred_id: int) -> int | None:
        """Mark confirmed; returns the referrer id only the first time."""
        row = self.db.query_one("SELECT * FROM referrals WHERE referred_id=? AND confirmed=0", (referred_id,))
        if not row:
            return None
        self.db.execute("UPDATE referrals SET confirmed=1 WHERE referred_id=?", (referred_id,))
        return row["referrer_id"]

    def confirmed_referrals(self, referrer_id: int) -> int:
        return self.db.scalar("SELECT COUNT(*) FROM referrals WHERE referrer_id=? AND confirmed=1", (referrer_id,))

    # ---------------- exports ----------------
    def export_downloads(self, limit: int = 5000) -> list[dict]:
        return self.db.query_all(
            "SELECT job_id,user_id,platform,title,kind,quality,ext,file_size,engine,status,error_category,"
            "created_at,processing_seconds FROM downloads ORDER BY id DESC LIMIT ?", (limit,))

    def export_users(self, limit: int = 20000) -> list[dict]:
        return self.db.query_all(
            "SELECT user_id,username,first_name,joined_at,last_seen,is_blocked,premium_until,points "
            "FROM users ORDER BY joined_at DESC LIMIT ?", (limit,))


class AsyncProxy:
    """Wraps a sync object so every method call runs in a worker thread."""

    def __init__(self, target: Any):
        self._target = target

    def __getattr__(self, name: str):
        attr = getattr(self._target, name)
        if not callable(attr):
            return attr

        async def runner(*args, **kwargs):
            return await asyncio.to_thread(attr, *args, **kwargs)

        runner.__name__ = name
        return runner
