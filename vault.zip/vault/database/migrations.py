"""Versioned migrations using PRAGMA user_version."""
from __future__ import annotations

from .db import Database
from .models import SCHEMA_V1

MIGRATIONS: list[tuple[int, list[str]]] = [
    (1, SCHEMA_V1),
    # Add future migrations here: (2, ["ALTER TABLE ..."]),
]


def migrate(db: Database) -> int:
    """Apply pending migrations; returns the schema version afterwards."""
    current = db.query_one("PRAGMA user_version")["user_version"]
    for version, statements in MIGRATIONS:
        if version <= current:
            continue
        with db.transaction() as conn:
            for stmt in statements:
                conn.execute(stmt)
            conn.execute(f"PRAGMA user_version = {int(version)}")
        current = version
    return current
